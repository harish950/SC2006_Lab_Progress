import React, { createContext, useContext, useState, useCallback, useRef, useEffect } from 'react';
import * as authService from '../services/authService';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('eduhome_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [loading, setLoading] = useState(true);

  const isAuthenticated = !!user;
  const checkedRef = useRef(false);

  // Restore session on mount
  useEffect(() => {
    if (checkedRef.current) {
      setLoading(false);
      return;
    }
    checkedRef.current = true;
    authService.getCurrentUser()
      .then((userData) => {
        setUser(userData);
        localStorage.setItem('eduhome_user', JSON.stringify(userData));
      })
      .catch(() => {
        setUser(null);
        localStorage.removeItem('eduhome_user');
      })
      .finally(() => setLoading(false));
  }, []);

  const login = useCallback(async (email, password) => {
    try {
      const userData = await authService.login(email, password);
      setUser(userData);
      localStorage.setItem('eduhome_user', JSON.stringify(userData));
      return { success: true };
    } catch (err) {
      const message = err.response?.data?.error || 'Login failed';
      return { success: false, error: message };
    }
  }, []);

  const register = useCallback(async (email, password, contactNo) => {
    try {
      const userData = await authService.register(email, password, contactNo);
      setUser(userData);
      localStorage.setItem('eduhome_user', JSON.stringify(userData));
      return { success: true };
    } catch (err) {
      const message = err.response?.data?.error || 'Registration failed';
      return { success: false, error: message };
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await authService.logout();
    } catch {
      // Ignore logout errors
    }
    setUser(null);
    localStorage.removeItem('eduhome_user');
  }, []);

  const resendVerification = useCallback(async () => {
    try {
      await authService.resendVerification();
      return { success: true };
    } catch (err) {
      const message = err.response?.data?.error || 'Failed to resend verification email';
      return { success: false, error: message };
    }
  }, []);

  const deleteAccount = useCallback(async (password) => {
    try {
      await authService.deleteAccount(password);
      setUser(null);
      localStorage.removeItem('eduhome_user');
      return { success: true };
    } catch (err) {
      const message = err.response?.data?.error || 'Failed to delete account';
      return { success: false, error: message };
    }
  }, []);

  const refreshUser = useCallback(async () => {
    try {
      const userData = await authService.getCurrentUser();
      setUser(userData);
      localStorage.setItem('eduhome_user', JSON.stringify(userData));
      return { success: true };
    } catch (err) {
      return { success: false };
    }
  }, []);

  return (
    <AuthContext.Provider value={{
      user, isAuthenticated, loading,
      login, register, logout,
      resendVerification, deleteAccount, refreshUser,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
