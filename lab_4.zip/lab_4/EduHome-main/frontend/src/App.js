import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import NavBar from './components/NavBar';
import HomePage from './pages/HomePage';
import ProfilePage from './pages/ProfilePage';
import HowItWorksPage from './pages/HowItWorksPage';
import VerifyEmailHandler from './components/VerifyEmailHandler';
import ResetPasswordHandler from './components/ResetPasswordHandler';

function App() {
  return (
    <div className="app">
      <NavBar />
      <main className="app-main">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/search" element={<Navigate to="/" replace />} />
          <Route path="/watchlist" element={<Navigate to="/profile" replace />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/how-it-works" element={<HowItWorksPage />} />
          <Route path="/verify-email" element={<VerifyEmailHandler />} />
          <Route path="/reset-password" element={<ResetPasswordHandler />} />
        </Routes>
      </main>
    </div>
  );
}

export default App;
