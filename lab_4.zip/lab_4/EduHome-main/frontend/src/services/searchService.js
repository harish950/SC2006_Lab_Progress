import api from './api';

/**
 * Fetch all primary schools for autocomplete and map display.
 * GET /api/schools
 */
export async function getSchools() {
  const { data } = await api.get('/schools');
  return data.map(s => ({
    ...s,
    lat: s.latitude,
    lng: s.longitude,
  }));
}

/**
 * Transform a backend block (latitude/longitude) to frontend shape (lat/lng).
 */
export function transformBlock(block) {
  if (!block) return block;
  const { latitude, longitude, ...rest } = block;
  return {
    ...rest,
    lat: latitude ?? block.lat,
    lng: longitude ?? block.lng,
  };
}

/**
 * Search for a school and return merged Gold + Silver blocks.
 * POST /api/search  { school_name }
 * Response: { school: {..., latitude, longitude}, gold: [...], silver: [...] }
 * Returns: { school: {..., lat, lng}, blocks: [...with lat/lng and zone] }
 */
export async function searchSchoolZone(schoolName) {
  const { data } = await api.post('/search', { school_name: schoolName });

  const school = {
    ...data.school,
    lat: data.school.latitude,
    lng: data.school.longitude,
  };

  const goldBlocks = (data.gold || []).map(transformBlock);
  const silverBlocks = (data.silver || []).map(transformBlock);
  const blocks = [...goldBlocks, ...silverBlocks];

  return { school, blocks };
}

/**
 * Fetch categorised search suggestions (schools, blocks, areas).
 * GET /api/search/suggestions?q=...
 */
export async function getSuggestions(query) {
  const { data } = await api.get('/search/suggestions', { params: { q: query } });
  return data; // { schools: [...], blocks: [...], areas: [...] }
}

/**
 * Search by HDB block — finds nearest school and returns priority zone.
 * POST /api/search/by-block  { block_id }
 */
export async function searchByBlock(blockId) {
  const { data } = await api.post('/search/by-block', { block_id: blockId });

  const school = {
    ...data.school,
    lat: data.school.latitude,
    lng: data.school.longitude,
  };

  const goldBlocks = (data.gold || []).map(transformBlock);
  const silverBlocks = (data.silver || []).map(transformBlock);
  const blocks = [...goldBlocks, ...silverBlocks];

  return { school, blocks, focusBlockId: data.focus_block_id ?? null };
}

/**
 * Search by area/street — finds nearest school and returns priority zone.
 * POST /api/search/by-area  { street_name }
 */
export async function searchByArea(streetName) {
  const { data } = await api.post('/search/by-area', { street_name: streetName });

  const school = {
    ...data.school,
    lat: data.school.latitude,
    lng: data.school.longitude,
  };

  const goldBlocks = (data.gold || []).map(transformBlock);
  const silverBlocks = (data.silver || []).map(transformBlock);
  const blocks = [...goldBlocks, ...silverBlocks];

  const areaCenter = data.area_center
    ? { lat: data.area_center.latitude, lng: data.area_center.longitude }
    : null;

  return { school, blocks, focusStreet: data.focus_street ?? null, areaCenter };
}

/**
 * Get hidden gem blocks for a school.
 * POST /api/search/hidden-gems  { blocks }
 */
export async function getHiddenGems(blocks) {
  const { data } = await api.post('/search/hidden-gems', { blocks });
  return data;
}

/**
 * Get heatmap data for blocks.
 * POST /api/search/heatmap  { blocks }
 */
export async function getHeatmapData(blocks) {
  const { data } = await api.post('/search/heatmap', { blocks });
  return data;
}
