import api from './api';

export async function getMarketTrend(blockId) {
  const { data } = await api.get(`/trend/${blockId}`);
  return {
    labels: data.labels,
    prices: data.prices,
    movingAvg: data.moving_avg,
    momentum: data.momentum,
  };
}
