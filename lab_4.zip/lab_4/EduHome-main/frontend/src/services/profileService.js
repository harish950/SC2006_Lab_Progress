import api from './api';

export async function getEmailLogs() {
  const { data } = await api.get('/profile/emails');
  return data.emails;
}
