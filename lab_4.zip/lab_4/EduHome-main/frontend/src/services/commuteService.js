import api from './api';

export async function getBestAlternatives(schoolId, topN = 3) {
  const { data } = await api.post('/commute', { school_id: schoolId, top_n: topN }, { timeout: 120000 });
  return data;
}

export async function getCommuteTime(schoolId, blockId) {
  const { data } = await api.post('/commute/time', { school_id: schoolId, block_id: blockId });
  return data.travel_time_min;
}
