import api from './api';

export async function getBallotRisk(schoolId) {
  const { data } = await api.get(`/ballot-risk/${schoolId}`);
  return data;
}

export async function getBallotRiskDetail(schoolId) {
  const { data } = await api.get(`/ballot-risk/${schoolId}/detail`);
  return data;
}
