import api from './api';

export async function login(email, password) {
  const { data } = await api.post('/auth/login', { email, password });
  return data.user;
}

export async function register(email, password, contactNo) {
  const { data } = await api.post('/auth/register', {
    email,
    password,
    contact_no: contactNo,
  });
  return data.user;
}

export async function logout() {
  await api.post('/auth/logout');
}

export async function getCurrentUser() {
  const { data } = await api.get('/auth/me');
  return data.user;
}

export async function verifyEmail(token) {
  const { data } = await api.post('/auth/verify-email', { token });
  return data;
}

export async function resendVerification() {
  const { data } = await api.post('/auth/resend-verification');
  return data;
}

export async function forgotPassword(email) {
  const { data } = await api.post('/auth/forgot-password', { email });
  return data;
}

export async function resetPassword(token, password) {
  const { data } = await api.post('/auth/reset-password', { token, password });
  return data;
}

export async function deleteAccount(password) {
  const { data } = await api.delete('/auth/account', { data: { password } });
  return data;
}
