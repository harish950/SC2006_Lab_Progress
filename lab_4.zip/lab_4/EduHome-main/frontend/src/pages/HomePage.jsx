import React, { useEffect, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';
import MapView from '../components/MapView';
import HiddenGems from '../components/HiddenGems';
import TrendChart from '../components/TrendChart';
import Heatmap from '../components/Heatmap';
import BallotRisk from '../components/BallotRisk';
import LeaseGuard from '../components/LeaseGuard';
import CommuteOptimizer from '../components/CommuteOptimizer';
import useSearch from '../hooks/useSearch';
import useMapOverlays from '../hooks/useMapOverlays';
import { useNavigate } from 'react-router-dom';
import { getSchools } from '../services/searchService';
import { getRemainingLease } from '../utils/propertyUtils';

const FILTER_STORAGE_KEY = 'eduhome_active_filters';

function loadSavedFilters() {
  try {
    const raw = localStorage.getItem(FILTER_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch {
    return null;
  }
}

export default function HomePage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { selectedSchool, blocks, allBlocks, loading, error, focusBlockId, areaCenter, performSearch, performBlockSearch, performAreaSearch, applyFilters, clearFilters, clearSearch } = useSearch();
  const { heatmapActive, hiddenGemsActive, leaseGuardActive, toggleHeatmap, toggleHiddenGems, toggleLeaseGuard } = useMapOverlays();

  const [selectedBlockId, setSelectedBlockId] = useState(null);
  const [blockCardAnimClass, setBlockCardAnimClass] = useState('');
  const [sidePanel, setSidePanel] = useState('analysis');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [schools, setSchools] = useState([]);
  const [activeFilters, setActiveFilters] = useState(() => loadSavedFilters());
  const lastFilterActionTs = useRef(null);
  const previousSelectedBlockIdRef = useRef(null);

  useEffect(() => {
    getSchools()
      .then(setSchools)
      .catch(() => setSchools([]));
  }, []);

  useEffect(() => {
    if (location.state?.reset) {
      clearSearch();
      setSelectedBlockId(null);
      return;
    }
    const sel = location.state?.selection;
    if (sel) {
      setSelectedBlockId(null);
      if (sel.type === 'block') {
        performBlockSearch(sel.block_id);
      } else if (sel.type === 'area') {
        performAreaSearch(sel.street_name);
      } else {
        performSearch(sel);
      }
    } else if (location.state?.school) {
      performSearch(location.state.school);
    }
  }, [location.state, performSearch, performBlockSearch, performAreaSearch, clearSearch]);

  useEffect(() => {
    const action = location.state?.filterAction;
    const ts = location.state?._ts;
    if (!action || !ts || lastFilterActionTs.current === ts) {
      return;
    }
    lastFilterActionTs.current = ts;

    if (action.type === 'clear') {
      setActiveFilters(null);
      clearFilters();
      return;
    }

    if (action.type === 'apply') {
      setActiveFilters(action.criteria || null);
    }
  }, [location.state, clearFilters]);

  useEffect(() => {
    if (!activeFilters || allBlocks.length === 0) {
      return;
    }
    applyFilters(activeFilters);
  }, [activeFilters, allBlocks, applyFilters]);

  // Auto-select the focused block when a block search returns
  useEffect(() => {
    if (focusBlockId != null) {
      setSelectedBlockId(focusBlockId);
    }
  }, [focusBlockId]);

  useEffect(() => {
    const previous = previousSelectedBlockIdRef.current;

    if (selectedBlockId == null) {
      setBlockCardAnimClass('');
      previousSelectedBlockIdRef.current = null;
      return;
    }

    setBlockCardAnimClass(
      previous == null ? 'block-detail-animate' : 'block-detail-animate-subtle'
    );
    previousSelectedBlockIdRef.current = selectedBlockId;
  }, [selectedBlockId]);

  const handleSearch = (selection) => {
    setSelectedBlockId(null);
    if (selection.type === 'block') {
      performBlockSearch(selection.block_id);
    } else if (selection.type === 'area') {
      performAreaSearch(selection.street_name);
    } else {
      // Default: school search (also handles legacy calls without type)
      performSearch(selection);
    }
  };

  const selectedBlock = blocks.find(b => b.block_id === selectedBlockId);
  const goldCount = blocks.filter(b => b.zone === 'GOLD_1KM').length;
  const silverCount = blocks.filter(b => b.zone === 'SILVER_2KM').length;

  return (
    <div className="search-page">
      {error && (
        <div className="error-banner" style={{ background: '#fef2f2', color: '#dc2626', padding: '10px 16px', fontSize: '14px', borderBottom: '1px solid #fecaca' }}>
          {error}
        </div>
      )}

      <div className="search-layout">
        <div className="search-map" style={{ position: 'relative' }}>
          <MapView
            school={selectedSchool}
            blocks={blocks}
            schools={schools}
            onBlockSelect={setSelectedBlockId}
            onSchoolSelect={handleSearch}
            heatmapActive={heatmapActive}
            hiddenGemsActive={hiddenGemsActive}
            leaseGuardActive={leaseGuardActive}
            childStartYear={activeFilters?.childStartYear ?? null}
            selectedBlockId={selectedBlockId}
            areaCenter={areaCenter}
          />
          {loading && (
            <div className="loading-overlay">
              <div className="spinner" />
              <p>Loading zones...</p>
            </div>
          )}
        </div>

        <button
          className="sidebar-toggle-mobile"
          onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
        >
          {mobileSidebarOpen ? 'Hide panel' : 'Show panel'}
        </button>

        <div className={`search-sidebar ${mobileSidebarOpen ? 'open' : ''}`}>
          {!selectedSchool ? (
            <div className="sidebar-empty">
              <p className="sidebar-empty-title">No school selected</p>
              <p className="sidebar-empty-desc">
                Use the search bar above to find a primary school and view HDB blocks within its enrollment zones.
              </p>
            </div>
          ) : (
            <>
              <div className="sidebar-top-cards">
                {selectedBlock && (
                  <>
                    <div
                      key={selectedBlock.block_id}
                      className={`block-detail ${blockCardAnimClass} ${
                        selectedBlock.zone === 'GOLD_1KM' ? 'zone-gold' : 'zone-silver'
                      }`}
                    >
                      <div className="block-detail-header">
                        <div>
                          <p className="card-kicker card-kicker-house">Selected HDB</p>
                          <h3 className="block-detail-title">Blk {selectedBlock.block_num} {selectedBlock.street_name}</h3>
                          <span className={`stat ${selectedBlock.zone === 'GOLD_1KM' ? 'gold' : 'silver'}`}>
                            {selectedBlock.zone === 'GOLD_1KM' ? 'Gold — within 1 km' : 'Silver — 1-2 km'}
                          </span>
                        </div>
                        <button className="panel-close" onClick={() => setSelectedBlockId(null)}>&times;</button>
                      </div>
                      <div className="block-detail-stats">
                        <div className="block-detail-stat">
                          <span className="block-detail-label">Avg PSF</span>
                          <span className="block-detail-value">
                            {selectedBlock.avg_psf ? `$${Number(selectedBlock.avg_psf).toLocaleString()}` : '—'}
                          </span>
                        </div>
                        <div className="block-detail-stat">
                          <span className="block-detail-label">Lease remaining</span>
                          <span className="block-detail-value">
                            {selectedBlock.lease_start_year ? `${getRemainingLease(selectedBlock.lease_start_year)} yrs` : '—'}
                          </span>
                        </div>
                        <div className="block-detail-stat">
                          <span className="block-detail-label">Lease start</span>
                          <span className="block-detail-value">
                            {selectedBlock.lease_start_year || '—'}
                          </span>
                        </div>
                        <div className="block-detail-stat block-house-type-stat">
                          <span className="block-detail-label">House type</span>
                          {selectedBlock.flat_types && selectedBlock.flat_types.length > 0 ? (
                            <div className="block-type-chips">
                              {selectedBlock.flat_types.map((type) => (
                                <span key={type} className="block-type-chip">{type}</span>
                              ))}
                            </div>
                          ) : (
                            <span className="block-detail-value">—</span>
                          )}
                        </div>
                      </div>

                      <TrendChart
                        blockId={selectedBlockId}
                        blockInfo={selectedBlock}
                        embedded
                      />
                    </div>
                  </>
                )}

                <div className="sidebar-school-header">
                  <h2 className="sidebar-school-name">{selectedSchool.official_name}</h2>
                  <div className="search-stats">
                    <span className="stat gold">{goldCount} Gold</span>
                    <span className="stat silver">{silverCount} Silver</span>
                    <span className="stat total">{blocks.length} total</span>
                  </div>
                </div>
              </div>

              <div className="sidebar-tabs">
                <button className={`sidebar-tab ${sidePanel === 'analysis' ? 'active' : ''}`} onClick={() => setSidePanel('analysis')}>
                  Analysis
                </button>
                <button className={`sidebar-tab ${sidePanel === 'ballot' ? 'active' : ''}`} onClick={() => setSidePanel('ballot')}>
                  Ballot
                </button>
                <button className={`sidebar-tab ${sidePanel === 'commute' ? 'active' : ''}`} onClick={() => setSidePanel('commute')}>
                  Commute
                </button>
              </div>

              <div className="sidebar-content">
                {sidePanel === 'analysis' && (
                  <>
                    <div className="sidebar-section">
                      <h4 className="sidebar-section-label">Map overlays</h4>
                      <div className="sidebar-section-cards">
                        <HiddenGems
                          active={hiddenGemsActive}
                          onToggle={toggleHiddenGems}
                          schoolId={selectedSchool.school_id}
                          blocks={blocks}
                          onSelectBlock={setSelectedBlockId}
                          selectedBlockId={selectedBlockId}
                        />
                        <Heatmap active={heatmapActive} onToggle={toggleHeatmap} />
                        <LeaseGuard
                          active={leaseGuardActive}
                          onToggle={toggleLeaseGuard}
                          schoolId={selectedSchool.school_id}
                          blocks={blocks}
                          childStartYear={activeFilters?.childStartYear ?? null}
                        />
                      </div>
                    </div>
                  </>
                )}

                {sidePanel === 'ballot' && (
                  <BallotRisk schoolId={selectedSchool.school_id} schoolName={selectedSchool.official_name} />
                )}

                {sidePanel === 'commute' && (
                  <CommuteOptimizer schoolId={selectedSchool.school_id} schoolName={selectedSchool.official_name} />
                )}
              </div>

              <div className="sidebar-cta">
                <button
                  className="btn btn-primary btn-full"
                  onClick={() => navigate('/profile', { state: { school: selectedSchool } })}
                >
                  Add to watchlist
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
