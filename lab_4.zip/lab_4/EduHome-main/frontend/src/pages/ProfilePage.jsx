import React, { useState, useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getWatchlist, addWatchlistItem, removeWatchlistItem } from '../services/watchlistService';
import { getSchools } from '../services/searchService';
import { getEmailLogs } from '../services/profileService';
import { forgotPassword } from '../services/authService';
import DeleteAccountModal from '../components/DeleteAccountModal';

function AuthPage() {
  const { login, register } = useAuth();
  const [mode, setMode] = useState('signup'); // 'signup' | 'login' | 'forgot'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [contactNo, setContactNo] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  const isSignup = mode === 'signup';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    if (mode === 'forgot') {
      try {
        await forgotPassword(email);
        setSuccess('If that email is registered, a reset link has been sent. Check your inbox.');
      } catch (err) {
        setError(err.response?.data?.error || 'Something went wrong');
      }
      setLoading(false);
      return;
    }

    const result = isSignup
      ? await register(email, password, contactNo)
      : await login(email, password);

    setLoading(false);
    if (!result.success) {
      setError(result.error);
    }
  };

  const switchMode = (newMode) => {
    setMode(newMode);
    setError('');
    setSuccess('');
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        {mode !== 'forgot' && (
          <div className="auth-tabs">
            <button
              className={`auth-tab ${mode === 'signup' ? 'active' : ''}`}
              onClick={() => switchMode('signup')}
            >
              Sign up
            </button>
            <button
              className={`auth-tab ${mode === 'login' ? 'active' : ''}`}
              onClick={() => switchMode('login')}
            >
              Log in
            </button>
          </div>
        )}

        <div className="auth-card-body">
          <p className="auth-subtitle">
            {mode === 'forgot'
              ? 'Enter your email to receive a password reset link.'
              : isSignup
                ? 'Create an account to save schools to your watchlist and receive alerts.'
                : 'Welcome back. Log in to access your watchlist.'}
          </p>

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Email</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
              />
            </div>
            {mode !== 'forgot' && (
              <div className="form-group">
                <label>Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Password"
                  required
                />
              </div>
            )}
            {isSignup && (
              <div className="form-group">
                <label>Contact number (optional)</label>
                <input
                  type="tel"
                  value={contactNo}
                  onChange={e => setContactNo(e.target.value)}
                  placeholder="91234567"
                />
              </div>
            )}
            {error && <p className="form-error">{error}</p>}
            {success && <p className="form-success">{success}</p>}
            <button type="submit" className="btn btn-primary btn-full" disabled={loading}>
              {loading ? 'Please wait...' : (
                mode === 'forgot' ? 'Send reset link' :
                isSignup ? 'Create account' : 'Log in'
              )}
            </button>
          </form>

          {mode === 'login' && (
            <p className="auth-footer">
              <button type="button" className="auth-switch-btn" onClick={() => switchMode('forgot')}>
                Forgot password?
              </button>
            </p>
          )}
          <p className="auth-footer">
            {mode === 'forgot' ? (
              <button type="button" className="auth-switch-btn" onClick={() => switchMode('login')}>
                Back to login
              </button>
            ) : (
              <>
                {isSignup ? 'Already have an account?' : "Don't have an account?"}{' '}
                <button type="button" className="auth-switch-btn" onClick={() => switchMode(isSignup ? 'login' : 'signup')}>
                  {isSignup ? 'Log in' : 'Sign up'}
                </button>
              </>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}

export default function ProfilePage() {
  const { user, isAuthenticated, logout } = useAuth();
  const location = useLocation();

  const [activeTab, setActiveTab] = useState(location.state?.school ? 'watchlist' : 'info');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [watchlistItems, setWatchlistItems] = useState([]);
  const [emailLogs, setEmailLogs] = useState([]);
  const [schools, setSchools] = useState([]);
  const [loading, setLoading] = useState(true);

  // Watchlist form state
  const [showForm, setShowForm] = useState(!!location.state?.school);
  const [formSchool, setFormSchool] = useState(location.state?.school?.school_id || '');
  const [minBudget, setMinBudget] = useState('');
  const [maxBudget, setMaxBudget] = useState('');
  const [formError, setFormError] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [schoolQuery, setSchoolQuery] = useState(
    () => {
      const s = location.state?.school;
      return s ? s.official_name || '' : '';
    }
  );
  const [schoolDropdownOpen, setSchoolDropdownOpen] = useState(false);
  const schoolPickerRef = useRef(null);

  const flash = (msg) => {
    setConfirmation(msg);
    setTimeout(() => setConfirmation(''), 3000);
  };

  useEffect(() => {
    if (!isAuthenticated) return;

    Promise.all([
      getWatchlist().catch(() => []),
      getEmailLogs().catch(() => []),
    ]).then(([wl, emails]) => {
      setWatchlistItems(wl);
      setEmailLogs(emails);
    }).finally(() => setLoading(false));
  }, [isAuthenticated]);

  useEffect(() => {
    getSchools()
      .then(setSchools)
      .catch(() => setSchools([]));
  }, []);

  useEffect(() => {
    function handleClickOutside(e) {
      if (schoolPickerRef.current && !schoolPickerRef.current.contains(e.target)) {
        setSchoolDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (!isAuthenticated) {
    return <AuthPage />;
  }

  if (loading) {
    return (
      <div className="profile-page">
        <div className="empty-state"><p>Loading...</p></div>
      </div>
    );
  }

  const handleAdd = async (e) => {
    e.preventDefault();
    setFormError('');

    if (!formSchool) { setFormError('Select a school'); return; }
    if (!minBudget || !maxBudget) { setFormError('Enter budget range'); return; }
    if (Number(minBudget) >= Number(maxBudget)) { setFormError('Max must exceed min budget'); return; }

    try {
      await addWatchlistItem(Number(formSchool), Number(minBudget), Number(maxBudget));
      const refreshed = await getWatchlist();
      setWatchlistItems(refreshed);
      setShowForm(false);
      setFormSchool('');
      setSchoolQuery('');
      setMinBudget('');
      setMaxBudget('');
      flash('Item added to watchlist');
    } catch (err) {
      setFormError(err.response?.data?.error || 'Failed to add item');
    }
  };

  const handleDelete = async (watchId) => {
    try {
      await removeWatchlistItem(watchId);
      setWatchlistItems(watchlistItems.filter(i => i.watch_id !== watchId));
      flash('Item removed');
    } catch (err) {
      flash('Failed to remove item');
    }
  };

  const toggleActive = (watchId) => {
    setWatchlistItems(watchlistItems.map(i =>
      i.watch_id === watchId ? { ...i, is_active: !i.is_active } : i
    ));
  };

  const formatDate = (iso) => {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleDateString('en-SG', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const typeBadgeClass = (type) => {
    switch (type) {
      case 'verification': return 'email-badge-verification';
      case 'password_reset': return 'email-badge-reset';
      case 'watchlist_alert': return 'email-badge-alert';
      default: return '';
    }
  };

  const typeLabel = (type) => {
    switch (type) {
      case 'verification': return 'Verification';
      case 'password_reset': return 'Password Reset';
      case 'watchlist_alert': return 'Watchlist Alert';
      default: return type;
    }
  };

  return (
    <div className="profile-page">
      <h1>Profile</h1>

      {confirmation && <div className="confirmation-banner">{confirmation}</div>}

      <div className="profile-tabs">
        <button className={`profile-tab ${activeTab === 'info' ? 'active' : ''}`} onClick={() => setActiveTab('info')}>
          Account
        </button>
        <button className={`profile-tab ${activeTab === 'watchlist' ? 'active' : ''}`} onClick={() => setActiveTab('watchlist')}>
          Watchlist
        </button>
      </div>

      {/* Account Information + Email History */}
      {activeTab === 'info' && (
        <>
          <div className="panel-card">
            <h3 className="panel-title">Account Information</h3>
            <div className="profile-info-grid">
              <div className="profile-info-item">
                <span className="profile-info-label">Email</span>
                <span className="profile-info-value">{user.email}</span>
              </div>
              <div className="profile-info-item">
                <span className="profile-info-label">Contact</span>
                <span className="profile-info-value">{user.contact_no || '—'}</span>
              </div>
              <div className="profile-info-item">
                <span className="profile-info-label">Status</span>
                <span className={`profile-verified-badge ${user.is_verified ? 'verified' : 'unverified'}`}>
                  {user.is_verified ? 'Verified' : 'Unverified'}
                </span>
              </div>
            </div>

            <div className="profile-actions">
              <button className="btn btn-outline" onClick={logout}>Log out</button>
              <button className="btn btn-danger" onClick={() => setShowDeleteModal(true)}>Delete account</button>
            </div>
          </div>

          <div className="panel-card">
            <h3 className="panel-title">Email History</h3>
            {emailLogs.length === 0 ? (
              <p className="profile-empty">No emails sent yet.</p>
            ) : (
              <div className="profile-email-list">
                {emailLogs.map(log => (
                  <div key={log.log_id} className="profile-email-item">
                    <div className="profile-email-top">
                      <span className={`email-type-badge ${typeBadgeClass(log.email_type)}`}>
                        {typeLabel(log.email_type)}
                      </span>
                      <span className="profile-email-date">{formatDate(log.sent_at)}</span>
                    </div>
                    <span className="profile-email-subject">{log.subject}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}

      {/* Watchlist */}
      {activeTab === 'watchlist' && (
        <div className="panel-card">
          <div className="watchlist-header">
            <h3 className="panel-title">Watchlist</h3>
            <button className="btn btn-primary btn-sm" onClick={() => setShowForm(!showForm)}>
              {showForm ? 'Cancel' : 'Add school'}
            </button>
          </div>

          {showForm && (
            <div className="watchlist-form">
              <form onSubmit={handleAdd}>
                <div className="form-group" ref={schoolPickerRef}>
                  <label>School</label>
                  <div className="school-picker">
                    <input
                      type="text"
                      className="school-picker-input"
                      value={schoolQuery}
                      onChange={e => {
                        setSchoolQuery(e.target.value);
                        setFormSchool('');
                        setSchoolDropdownOpen(true);
                      }}
                      onFocus={() => setSchoolDropdownOpen(true)}
                      placeholder="Search for a school..."
                    />
                    {formSchool && (
                      <button
                        type="button"
                        className="school-picker-clear"
                        onClick={() => { setFormSchool(''); setSchoolQuery(''); }}
                      >&times;</button>
                    )}
                    {schoolDropdownOpen && (
                      <div className="school-picker-dropdown">
                        {schools
                          .filter(s => s.official_name.toLowerCase().includes(schoolQuery.toLowerCase()))
                          .length === 0 ? (
                          <div className="school-picker-empty">No schools found</div>
                        ) : (
                          schools
                            .filter(s => s.official_name.toLowerCase().includes(schoolQuery.toLowerCase()))
                            .map(s => (
                              <button
                                type="button"
                                key={s.school_id}
                                className={`school-picker-option ${String(formSchool) === String(s.school_id) ? 'selected' : ''}`}
                                onClick={() => {
                                  setFormSchool(s.school_id);
                                  setSchoolQuery(s.official_name);
                                  setSchoolDropdownOpen(false);
                                }}
                              >
                                {s.official_name}
                              </button>
                            ))
                        )}
                      </div>
                    )}
                  </div>
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label>Min budget ($)</label>
                    <input type="number" value={minBudget} onChange={e => setMinBudget(e.target.value)} placeholder="400000" />
                  </div>
                  <div className="form-group">
                    <label>Max budget ($)</label>
                    <input type="number" value={maxBudget} onChange={e => setMaxBudget(e.target.value)} placeholder="600000" />
                  </div>
                </div>
                {formError && <p className="form-error">{formError}</p>}
                <button type="submit" className="btn btn-primary">Save</button>
              </form>
            </div>
          )}

          <div className="watchlist-list">
            {watchlistItems.length === 0 ? (
              <div className="empty-state">
                <p>No watchlist items yet.</p>
                <p>Search for a school and add it to get started.</p>
              </div>
            ) : (
              watchlistItems.map(item => (
                <div key={item.watch_id} className={`watchlist-item ${!item.is_active ? 'inactive' : ''}`}>
                  <div className="watchlist-item-main">
                    <div className="watchlist-item-info">
                      <h3>{item.school_name || item.school?.official_name}</h3>
                      <p className="watchlist-budget">
                        ${Number(item.min_budget).toLocaleString()} &ndash; ${Number(item.max_budget).toLocaleString()}
                      </p>
                    </div>
                    <div className="watchlist-item-status">
                      <span className={`status-badge ${item.is_active ? 'active' : 'paused'}`}>
                        {item.is_active ? 'Active' : 'Paused'}
                      </span>
                    </div>
                  </div>
                  <div className="watchlist-item-actions">
                    <button className="btn btn-sm btn-outline" onClick={() => toggleActive(item.watch_id)}>
                      {item.is_active ? 'Pause' : 'Resume'}
                    </button>
                    <button className="btn btn-sm btn-danger" onClick={() => handleDelete(item.watch_id)}>
                      Remove
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {showDeleteModal && <DeleteAccountModal onClose={() => setShowDeleteModal(false)} />}
    </div>
  );
}
