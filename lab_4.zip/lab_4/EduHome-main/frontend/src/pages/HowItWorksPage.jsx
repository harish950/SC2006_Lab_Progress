import React from 'react';

export default function HowItWorksPage() {
  return (
    <div className="howitworks-page">
      <h1 className="howitworks-title">How P1 Registration Works</h1>
      <p className="howitworks-intro">
        Every year, Singapore's Ministry of Education (MOE) conducts the Primary 1
        (P1) registration exercise. Parents register their children for Primary 1
        through a structured, multi-phase process. Understanding the phases, priority
        rules, and balloting system is key to making informed decisions about where
        to live.
      </p>

      {/* Registration Phases */}
      <section className="howitworks-section">
        <h2 className="howitworks-section-title">Registration Phases</h2>
        <p className="howitworks-section-desc">
          Registration happens in phases, each with specific eligibility criteria. Earlier
          phases have higher priority. Places are only available in later phases if there
          are remaining vacancies.
        </p>

        <div className="howitworks-phases">
          <div className="phase-card">
            <div className="phase-label">Phase 1</div>
            <div className="phase-content">
              <h3>Siblings already in school</h3>
              <p>
                For children who have a sibling currently studying in the school.
                Registration is guaranteed.
              </p>
            </div>
          </div>

          <div className="phase-card">
            <div className="phase-label">Phase 2A</div>
            <div className="phase-content">
              <h3>Parent connections to school</h3>
              <p>
                For children whose parent or sibling is a former student, or whose parent
                is a staff member or member of the school advisory/management committee.
              </p>
            </div>
          </div>

          <div className="phase-card">
            <div className="phase-label">Phase 2B</div>
            <div className="phase-content">
              <h3>Volunteer or community ties</h3>
              <p>
                For children whose parent has volunteered at the school for at least 40 hours,
                or is a member of the church/clan associated with the school, or is endorsed
                by the school as an active community leader.
              </p>
            </div>
          </div>

          <div className="phase-card">
            <div className="phase-label">Phase 2C</div>
            <div className="phase-content">
              <h3>Open to all Singapore citizens and PRs</h3>
              <p>
                For any Singapore Citizen (SC) or Permanent Resident (PR) child who has not
                secured a place in earlier phases. This is the most competitive phase for
                popular schools.
              </p>
            </div>
          </div>

          <div className="phase-card">
            <div className="phase-label">Phase 3</div>
            <div className="phase-content">
              <h3>International students</h3>
              <p>
                For children who are not Singapore Citizens or Permanent Residents.
                Only if vacancies remain after Phase 2C.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Priority Zones */}
      <section className="howitworks-section">
        <h2 className="howitworks-section-title">Priority Zones (Home-School Distance)</h2>
        <p className="howitworks-section-desc">
          From Phase 2A onwards, when demand exceeds supply, priority is given based on the
          distance between the child's home and the school. MOE defines two distance bands:
        </p>

        <div className="howitworks-zones">
          <div className="zone-card zone-gold">
            <div className="zone-icon">1 km</div>
            <div className="zone-content">
              <h3>Within 1 km</h3>
              <p>
                Highest priority. Children living within 1 km of the school are given
                first priority in balloting. This is the most sought-after zone for
                popular schools.
              </p>
            </div>
          </div>

          <div className="zone-card zone-silver">
            <div className="zone-icon">1-2 km</div>
            <div className="zone-content">
              <h3>Between 1 km and 2 km</h3>
              <p>
                Second priority. If places remain after accommodating applicants within 1 km,
                children living between 1 km and 2 km are considered next.
              </p>
            </div>
          </div>

          <div className="zone-card zone-outside">
            <div className="zone-icon">&gt;2 km</div>
            <div className="zone-content">
              <h3>Outside 2 km</h3>
              <p>
                Lowest priority. Children living more than 2 km away are only considered
                if places remain after the first two distance bands.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Balloting */}
      <section className="howitworks-section">
        <h2 className="howitworks-section-title">Balloting</h2>
        <p className="howitworks-section-desc">
          When the number of applicants in a phase exceeds the available places, MOE conducts
          a computerised ballot. Here's how it works:
        </p>

        <div className="howitworks-ballot-steps">
          <div className="ballot-step">
            <span className="ballot-step-num">1</span>
            <div>
              <strong>Within 1 km applicants ballot first.</strong> If places remain,
              the process continues to the next distance band.
            </div>
          </div>
          <div className="ballot-step">
            <span className="ballot-step-num">2</span>
            <div>
              <strong>1-2 km applicants ballot next.</strong> Singapore Citizens are given
              priority over Permanent Residents within the same distance band.
            </div>
          </div>
          <div className="ballot-step">
            <span className="ballot-step-num">3</span>
            <div>
              <strong>Unsuccessful applicants</strong> can register at another school
              with remaining vacancies in a later phase.
            </div>
          </div>
        </div>
      </section>

      {/* How EduHome Helps */}
      <section className="howitworks-section">
        <h2 className="howitworks-section-title">How EduHome Helps</h2>
        <p className="howitworks-section-desc">
          EduHome gives you the data and tools to navigate this process with confidence:
        </p>

        <div className="howitworks-features">
          <div className="howitworks-feature">
            <h3>Zone Search</h3>
            <p>See which HDB blocks fall within the 1 km and 1-2 km priority zones for any primary school.</p>
          </div>
          <div className="howitworks-feature">
            <h3>Ballot Risk</h3>
            <p>Assess how competitive a school is likely to be based on historical registration data and vacancy rates.</p>
          </div>
          <div className="howitworks-feature">
            <h3>Commute Optimizer</h3>
            <p>Find blocks in your target zone with the best commute to your workplace, so you can balance school access with daily travel.</p>
          </div>
          <div className="howitworks-feature">
            <h3>Price Heatmap & Hidden Gems</h3>
            <p>Explore property prices across the zone and discover undervalued blocks that meet your budget.</p>
          </div>
          <div className="howitworks-feature">
            <h3>Lease Guard</h3>
            <p>Avoid blocks with short remaining leases that could affect your HDB loan eligibility or long-term value.</p>
          </div>
          <div className="howitworks-feature">
            <h3>Watchlist</h3>
            <p>Save schools you're interested in and track properties that match your criteria.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
