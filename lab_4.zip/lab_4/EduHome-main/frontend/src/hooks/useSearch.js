import { useState, useCallback, useRef } from 'react';
import { searchSchoolZone, searchByBlock, searchByArea } from '../services/searchService';
import { applyFilters as applyFiltersAPI } from '../services/filterService';

export default function useSearch() {
  const [selectedSchool, setSelectedSchool] = useState(null);
  const [blocks, setBlocks] = useState([]);
  const [allBlocks, setAllBlocks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [focusBlockId, setFocusBlockId] = useState(null);
  const [areaCenter, setAreaCenter] = useState(null);
  const allBlocksRef = useRef([]);

  const setSearchResults = useCallback((resultBlocks) => {
    setBlocks(resultBlocks);
    setAllBlocks(resultBlocks);
    allBlocksRef.current = resultBlocks;
  }, []);

  const performSearch = useCallback(async (school) => {
    setError(null);
    setLoading(true);
    setFocusBlockId(null);
    setAreaCenter(null);
    try {
      const { school: schoolData, blocks: resultBlocks } = await searchSchoolZone(school.official_name);
      setSelectedSchool(schoolData);
      setSearchResults(resultBlocks);
    } catch (err) {
      const message = err.response?.data?.error || err.message || 'Search failed';
      setError(message);
    } finally {
      setLoading(false);
    }
  }, [setSearchResults]);

  const performBlockSearch = useCallback(async (blockId) => {
    setError(null);
    setLoading(true);
    setFocusBlockId(null);
    setAreaCenter(null);
    try {
      const { school: schoolData, blocks: resultBlocks, focusBlockId: fid } = await searchByBlock(blockId);
      setSelectedSchool(schoolData);
      setSearchResults(resultBlocks);
      setFocusBlockId(fid);
    } catch (err) {
      const message = err.response?.data?.error || err.message || 'Search failed';
      setError(message);
    } finally {
      setLoading(false);
    }
  }, [setSearchResults]);

  const performAreaSearch = useCallback(async (streetName) => {
    setError(null);
    setLoading(true);
    setFocusBlockId(null);
    setAreaCenter(null);
    try {
      const { school: schoolData, blocks: resultBlocks, areaCenter: ac } = await searchByArea(streetName);
      setSelectedSchool(schoolData);
      setSearchResults(resultBlocks);
      setAreaCenter(ac);
    } catch (err) {
      const message = err.response?.data?.error || err.message || 'Search failed';
      setError(message);
    } finally {
      setLoading(false);
    }
  }, [setSearchResults]);

  const applyFilters = useCallback(async ({ maxBudget, minArea, childStartYear, flatTypes }) => {
    setLoading(true);
    setError(null);
    try {
      const sourceBlocks = allBlocksRef.current || [];
      let filtered = await applyFiltersAPI(sourceBlocks, { maxBudget, minArea, childStartYear });

      // Housing type filter applied client-side (data already in blocks)
      if (flatTypes && flatTypes.length > 0) {
        const types = new Set(flatTypes.map(ft => ft.toUpperCase()));
        filtered = filtered.filter(block => {
          const blockTypes = (block.flat_types || []).map(ft => ft.toUpperCase());
          return blockTypes.some(ft => types.has(ft));
        });
      }

      setBlocks(filtered);
    } catch (err) {
      const message = err.response?.data?.error || err.message || 'Filter failed';
      setError(message);
    } finally {
      setLoading(false);
    }
  }, []);

  const clearFilters = useCallback(() => {
    setBlocks([...(allBlocksRef.current || [])]);
    setError(null);
  }, []);

  const clearSearch = useCallback(() => {
    setSelectedSchool(null);
    setBlocks([]);
    setAllBlocks([]);
    allBlocksRef.current = [];
    setError(null);
  }, []);

  return {
    selectedSchool,
    blocks,
    allBlocks,
    loading,
    error,
    focusBlockId,
    areaCenter,
    performSearch,
    performBlockSearch,
    performAreaSearch,
    applyFilters,
    clearFilters,
    clearSearch,
  };
}
