// Heatmap PSF buckets
export const HEATMAP_LEGEND = [
  { label: '< $300/psf', color: '#0ea5e9', min: 0, max: 300 },
  { label: '$300-$500', color: '#22c55e', min: 300, max: 500 },
  { label: '$500-$700', color: '#facc15', min: 500, max: 700 },
  { label: '$700-$900', color: '#f97316', min: 700, max: 900 },
  { label: '> $900/psf', color: '#ef4444', min: 900, max: 9999 },
];

export function getHeatmapColor(psf) {
  const bucket = HEATMAP_LEGEND.find(b => psf >= b.min && psf < b.max);
  return bucket ? bucket.color : '#9ca3af';
}

export function getRemainingLease(leaseStartYear) {
  const currentYear = new Date().getFullYear();
  return 99 - (currentYear - leaseStartYear);
}
