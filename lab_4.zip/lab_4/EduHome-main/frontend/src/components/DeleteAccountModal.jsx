import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function DeleteAccountModal({ onClose }) {
  const { deleteAccount } = useAuth();
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const result = await deleteAccount(password);
    setLoading(false);

    if (result.success) {
      onClose();
    } else {
      setError(result.error);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Delete account</h2>
          <button className="modal-close" onClick={onClose}>&times;</button>
        </div>
        <form onSubmit={handleSubmit} className="modal-body">
          <div className="form-warning">
            This will permanently delete your account and all your watchlist data. This action cannot be undone.
          </div>
          <div className="form-group">
            <label>Enter your password to confirm</label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Password"
              required
            />
          </div>
          {error && <p className="form-error">{error}</p>}
          <button type="submit" className="btn btn-danger btn-full" disabled={loading}>
            {loading ? 'Deleting...' : 'Permanently delete account'}
          </button>
        </form>
      </div>
    </div>
  );
}
