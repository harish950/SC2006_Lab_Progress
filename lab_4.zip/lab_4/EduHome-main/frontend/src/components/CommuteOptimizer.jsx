import React, { useState } from 'react';
import { getBestAlternatives } from '../services/commuteService';

export default function CommuteOptimizer({ schoolId, schoolName }) {
  const [results, setResults] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    setError('');
    setLoading(true);
    try {
      const data = await getBestAlternatives(schoolId, 5);
      setResults(data);
    } catch (err) {
      const msg = err.response?.data?.error || 'Could not find routes';
      setError(msg);
      setResults(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="panel-card">
      <div className="panel-header">
        <h3 className="panel-title">Commute optimizer</h3>
      </div>
      <p className="panel-desc">
        Ranks Silver zone (1-2km) blocks by shortest public transport commute to {schoolName || 'school'}.
      </p>

      {error && <p className="form-error">{error}</p>}

      {!results && (
        <button className="btn btn-primary" onClick={handleSearch} disabled={loading}>
          {loading ? 'Calculating...' : 'Find best blocks'}
        </button>
      )}

      {results && results.length > 0 && (
        <div className="commute-results">
          {results.map((r, i) => (
            <div key={r.block_id} className={`commute-item ${i === 0 ? 'best' : ''}`}>
              {i === 0 && <span className="best-badge">Shortest</span>}
              <div className="commute-block">
                <strong>Blk {r.block_num}</strong> {r.street_name}
              </div>
              <div className="commute-details">
                <span className="commute-time">{r.travel_time_min} min</span>
                <span className="commute-dist">{r.distance_km} km</span>
              </div>
            </div>
          ))}
          <button className="btn btn-outline" onClick={() => setResults(null)} style={{ marginTop: '8px' }}>
            Reset
          </button>
        </div>
      )}

      {results && results.length === 0 && (
        <p className="empty-msg">No Silver zone blocks found for this school.</p>
      )}
    </div>
  );
}
