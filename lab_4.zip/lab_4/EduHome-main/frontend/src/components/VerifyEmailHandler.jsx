import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { verifyEmail } from '../services/authService';
import { useAuth } from '../context/AuthContext';

export default function VerifyEmailHandler() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { refreshUser } = useAuth();
  const [status, setStatus] = useState('verifying'); // 'verifying' | 'success' | 'error'
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    const token = searchParams.get('token');
    if (!token) {
      setStatus('error');
      setErrorMsg('No verification token provided');
      return;
    }

    verifyEmail(token)
      .then(() => {
        setStatus('success');
        refreshUser();
      })
      .catch((err) => {
        setStatus('error');
        setErrorMsg(err.response?.data?.error || 'Verification failed');
      });
  }, [searchParams, refreshUser]);

  const handleClose = () => navigate('/');

  return (
    <div className="modal-overlay" onClick={handleClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Email verification</h2>
          <button className="modal-close" onClick={handleClose}>&times;</button>
        </div>
        <div className="modal-body">
          {status === 'verifying' && (
            <p style={{ textAlign: 'center', color: 'var(--text-secondary)' }}>Verifying your email...</p>
          )}
          {status === 'success' && (
            <>
              <p className="form-success" style={{ textAlign: 'center' }}>Your email has been verified successfully.</p>
              <button className="btn btn-primary btn-full" onClick={handleClose} style={{ marginTop: 12 }}>
                Continue
              </button>
            </>
          )}
          {status === 'error' && (
            <>
              <p className="form-error" style={{ textAlign: 'center' }}>{errorMsg}</p>
              <button className="btn btn-outline btn-full" onClick={handleClose} style={{ marginTop: 12 }}>
                Go home
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
