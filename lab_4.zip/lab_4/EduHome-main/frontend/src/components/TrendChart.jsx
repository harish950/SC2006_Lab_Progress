import React, { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { getMarketTrend } from '../services/trendService';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, Filler);

export default function TrendChart({ blockId, blockInfo, onClose, embedded = false }) {
  const [trend, setTrend] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const containerClass = embedded ? 'trend-panel trend-panel-embedded' : 'panel-card trend-panel';

  useEffect(() => {
    if (!blockId) return;

    let cancelled = false;
    setLoading(true);
    setError(null);

    getMarketTrend(blockId)
      .then((data) => {
        if (!cancelled) setTrend(data);
      })
      .catch((err) => {
        if (!cancelled) setError(err.response?.data?.error || 'Failed to load trend data');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => { cancelled = true; };
  }, [blockId]);

  if (!blockId) return null;

  if (loading) {
    return (
      <div className={containerClass}>
        <div className="panel-header">
          <h3 className="panel-title">Price trend</h3>
        </div>
        <div style={{ padding: '24px', textAlign: 'center' }}>
          <div className="spinner" />
          <p>Loading trend data...</p>
        </div>
      </div>
    );
  }

  const isInsufficientDataError =
    typeof error === 'string' &&
    error.toLowerCase().includes('insufficient historical data');

  if (isInsufficientDataError) {
    return null;
  }

  if (error) {
    return (
      <div className={containerClass}>
        <div className="panel-header">
          <h3 className="panel-title">Price trend</h3>
        </div>
        <div style={{ padding: '24px', textAlign: 'center', color: '#dc2626' }}>
          <p>{error}</p>
        </div>
      </div>
    );
  }

  if (!trend) return null;

  const data = {
    labels: trend.labels,
    datasets: [
      {
        label: 'Avg PSF ($)',
        data: trend.prices,
        borderColor: embedded ? '#e2e8f0' : '#111',
        backgroundColor: embedded ? 'rgba(148,163,184,0.10)' : 'rgba(0,0,0,0.03)',
        fill: true,
        tension: 0.3,
        pointRadius: 2,
        borderWidth: 1.5,
      },
      {
        label: '3M Moving Avg',
        data: trend.movingAvg,
        borderColor: embedded ? '#94a3b8' : '#999',
        borderDash: [4, 2],
        pointRadius: 0,
        borderWidth: 1,
        tension: 0.3,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: !embedded,
        position: 'bottom',
        labels: { boxWidth: 8, padding: 12, font: { size: 11, family: 'Inter, sans-serif' } },
      },
      tooltip: { mode: 'index', intersect: false },
    },
    scales: {
      x: {
        ticks: {
          font: { size: 10, family: 'Inter, sans-serif' },
          color: embedded ? '#cbd5e1' : '#999',
        },
        grid: { display: false, color: embedded ? 'rgba(203,213,225,0.18)' : undefined },
      },
      y: {
        ticks: {
          font: { size: 10, family: 'Inter, sans-serif' },
          color: embedded ? '#cbd5e1' : '#999',
        },
        grid: { color: embedded ? 'rgba(203,213,225,0.18)' : '#f0f0f0' },
        title: {
          display: !embedded,
          text: 'PSF ($)',
          font: { size: 10, family: 'Inter, sans-serif' },
          color: '#999',
        },
        beginAtZero: false,
      },
    },
  };

  const trendLabel = trend.momentum === 'Heating Up'
    ? 'Rising'
    : trend.momentum === 'Cooling Off'
      ? 'Declining'
      : 'Stable';

  if (embedded) {
    return (
      <div className={containerClass}>
        <div className="trend-header-right">
          <span className={`momentum-badge ${trend.momentum === 'Heating Up' ? 'hot' : trend.momentum === 'Cooling Off' ? 'cool' : 'stable'}`}>
            {trendLabel}
          </span>
        </div>
        <div className="trend-chart-wrapper trend-chart-wrapper-embedded">
          <Line data={data} options={options} />
        </div>
      </div>
    );
  }

  return (
    <div className={containerClass}>
      <div className="panel-header">
        <div>
          <h3 className="panel-title">Price trend</h3>
          {blockInfo && (
            <>
              <p className="panel-subtitle">Blk {blockInfo.block_num} {blockInfo.street_name}</p>
              {blockInfo.flat_types && blockInfo.flat_types.length > 0 && (
                <p className="panel-subtitle" style={{ fontSize: 11, color: '#999' }}>
                  {blockInfo.flat_types.join(' / ')}
                </p>
              )}
            </>
          )}
        </div>
        <div className="trend-header-right">
          <span className={`momentum-badge ${trend.momentum === 'Heating Up' ? 'hot' : trend.momentum === 'Cooling Off' ? 'cool' : 'stable'}`}>
            {trendLabel}
          </span>
        </div>
      </div>
      <div className="trend-chart-wrapper">
        <Line data={data} options={options} />
      </div>
    </div>
  );
}
