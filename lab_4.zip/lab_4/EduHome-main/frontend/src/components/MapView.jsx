import React, { useRef, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapContainer, TileLayer, Circle, Marker, Tooltip, useMap, LayerGroup } from 'react-leaflet';
import L from 'leaflet';
import { getHeatmapColor } from '../utils/propertyUtils';

function getRemainingLease(leaseStart) {
  return 99 - (new Date().getFullYear() - leaseStart);
}

function dot(color, size = 10, border = '#fff', borderWidth = 2, pulse = false) {
  const pulseRing = pulse
    ? `<div style="position:absolute;top:50%;left:50%;width:${size}px;height:${size}px;transform:translate(-50%,-50%);border-radius:50%;background:${color};opacity:0.4;animation:marker-pulse 1.5s ease-out infinite;"></div>`
    : '';
  return L.divIcon({
    className: '',
    html: `<div style="position:relative;width:${size}px;height:${size}px;">${pulseRing}<div style="position:relative;width:${size}px;height:${size}px;border-radius:50%;background:${color};border:${borderWidth}px solid ${border};box-shadow:0 2px 6px rgba(0,0,0,0.35);"></div></div>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
}

function schoolPin(size = 32, color = '#4f46e5', selected = false) {
  const s = selected ? size + 6 : size;
  const capSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="${s * 0.5}" height="${s * 0.5}" fill="white"><path d="M5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82zM12 3L1 9l11 6 9-4.91V17h2V9L12 3z"/></svg>`;
  return L.divIcon({
    className: '',
    html: `<div style="width:${s}px;height:${s}px;border-radius:50%;background:${color};display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,0.35);border:2.5px solid #fff;">${capSvg}</div>`,
    iconSize: [s, s],
    iconAnchor: [s / 2, s / 2],
  });
}

function gemPin(size = 22, selected = false, borderColor = '#1d4ed8') {
  const s = selected ? size + 6 : size;
  const gemSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="${s * 0.55}" height="${s * 0.55}" fill="white"><path d="M19 3H5L2 9l10 12L22 9l-3-6zM9.62 8l1.5-3h1.76l1.5 3H9.62zM11 10v6.68L5.44 10H11zm2 0h5.56L13 16.68V10zm6.26-2h-2.65l-1.5-3h2.65l1.5 3zM6.24 5h2.65l-1.5 3H4.74l1.5-3z"/></svg>`;
  return L.divIcon({
    className: '',
    html: `<div style="width:${s}px;height:${s}px;border-radius:50%;background:#2563eb;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,0.35);border:2.5px solid ${borderColor};">${gemSvg}</div>`,
    iconSize: [s, s],
    iconAnchor: [s / 2, s / 2],
  });
}

function getHeatmapBorderColor(psf) {
  if (psf == null) return '#64748b';
  if (psf < 300) return '#0369a1';
  if (psf < 500) return '#15803d';
  if (psf < 700) return '#a16207';
  if (psf < 900) return '#c2410c';
  return '#b91c1c';
}

// Track school changes across mount/unmount cycles
let lastSeenSchoolId = null;

function ChangeView({ schoolId, center, zoom, bounds }) {
  const map = useMap();
  const prevSchoolId = useRef(schoolId);

  useEffect(() => {
    if (!map || !map._container) return;

    map.stop();

    const changed = prevSchoolId.current !== schoolId;
    prevSchoolId.current = schoolId;

    if (bounds) {
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 16, animate: false });
    } else if (changed) {
      map.setView(center, zoom, { animate: false });
    }

    lastSeenSchoolId = schoolId;
  }, [schoolId, center, zoom, bounds, map]);

  return null;
}

export default function MapView({
  school,
  blocks = [],
  schools = [],
  onBlockSelect,
  onSchoolSelect,
  heatmapActive = false,
  hiddenGemsActive = false,
  leaseGuardActive = false,
  childStartYear = null,
  selectedBlockId = null,
  areaCenter = null,
}) {
  const navigate = useNavigate();
  const center = school ? [school.lat, school.lng] : [1.3521, 103.8198];
  const zoom = school ? 15 : 12;
  const currentYear = new Date().getFullYear();
  const requiredLeaseYears = childStartYear
    ? Math.max(0, childStartYear + 6 - currentYear)
    : 30;

  // When an area search is active, compute bounds from the area center + blocks
  const areaBounds = useMemo(() => {
    if (!areaCenter || blocks.length === 0) return null;
    const points = blocks.map(b => [b.lat, b.lng]);
    points.push([areaCenter.lat, areaCenter.lng]);
    if (school) points.push([school.lat, school.lng]);
    return L.latLngBounds(points);
  }, [areaCenter, blocks, school]);

  const gemIds = useMemo(() => {
    if (!hiddenGemsActive) return new Set();
    const goldBlocks = blocks.filter(b => b.zone === 'GOLD_1KM' && b.avg_psf);
    if (goldBlocks.length === 0) return new Set();
    const avg = goldBlocks.reduce((s, b) => s + b.avg_psf, 0) / goldBlocks.length;
    const threshold = avg * 0.9;
    return new Set(blocks.filter(b => b.avg_psf && b.avg_psf < threshold).map(b => b.block_id));
  }, [blocks, hiddenGemsActive]);

  const leaseIds = useMemo(() => {
    if (!leaseGuardActive) return new Set();
    return new Set(blocks.filter(b => {
      const remaining = 99 - (currentYear - b.lease_start_year);
      return remaining < requiredLeaseYears;
    }).map(b => b.block_id));
  }, [blocks, leaseGuardActive, currentYear, requiredLeaseYears]);

  const getBlockColor = (block) => {
    if (heatmapActive) return getHeatmapColor(block.avg_psf);
    if (hiddenGemsActive && gemIds.has(block.block_id)) return '#3b82f6';
    if (leaseGuardActive && leaseIds.has(block.block_id)) return '#ef4444';
    return block.zone === 'GOLD_1KM' ? '#facc15' : '#cbd5e1';
  };

  const isSelected = (block) => selectedBlockId === block.block_id;

  const otherSchools = schools.filter(s => !school || s.school_id !== school.school_id);

  return (
    <div className="map-container">
      <MapContainer center={center} zoom={zoom} scrollWheelZoom zoomControl={false} style={{ height: '100%', width: '100%' }}>
        <ChangeView schoolId={school?.school_id} center={center} zoom={zoom} bounds={areaBounds} />
        <TileLayer
          attribution='&copy; <a href="https://carto.com/">CARTO</a>'
          url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
        />

        {otherSchools.map(s => (
          <Marker
            key={s.school_id}
            position={[s.lat, s.lng]}
            icon={schoolPin(28, '#6366f1')}
            eventHandlers={{ click: () => onSchoolSelect && onSchoolSelect(s) }}
          >
            <Tooltip direction="top" offset={[0, -10]} className="map-tooltip">
              <strong>{s.official_name}</strong><br />
              Vacancies: {s.vacancies}
            </Tooltip>
          </Marker>
        ))}

        {school && (
          <>
            <Circle
              center={[school.lat, school.lng]}
              radius={2000}
              pathOptions={{ color: '#60a5fa', fillColor: '#60a5fa', fillOpacity: 0.06, weight: 1.5, dashArray: '6 4' }}
            />
            <Circle
              center={[school.lat, school.lng]}
              radius={1000}
              pathOptions={{ color: '#eab308', fillColor: '#eab308', fillOpacity: 0.08, weight: 1.5, dashArray: '6 4' }}
            />
            <Marker position={[school.lat, school.lng]} icon={schoolPin(36, '#4f46e5', true)}>
              <Tooltip direction="top" offset={[0, -14]} className="map-tooltip">
                <strong>{school.official_name}</strong><br />
                Vacancies: {school.vacancies}
              </Tooltip>
            </Marker>
          </>
        )}

        <LayerGroup>
          {blocks.map(block => {
            const remaining = getRemainingLease(block.lease_start_year);
            const selected = isSelected(block);
            const color = getBlockColor(block);
            const isGem = hiddenGemsActive && gemIds.has(block.block_id);
            const isLeaseRisk = leaseGuardActive && leaseIds.has(block.block_id);

            let markerBorderColor = block.zone === 'GOLD_1KM' ? '#a16207' : '#475569';
            if (heatmapActive) markerBorderColor = getHeatmapBorderColor(block.avg_psf);
            if (isGem) markerBorderColor = '#1d4ed8';
            if (isLeaseRisk) markerBorderColor = '#b91c1c';

            return (
              <Marker
                key={block.block_id}
                position={[block.lat, block.lng]}
                icon={isGem
                  ? gemPin(selected ? 26 : 22, selected, markerBorderColor)
                  : dot(color, selected ? 22 : 14, markerBorderColor, selected ? 3 : 2.5, selected)}
                eventHandlers={{ click: () => onBlockSelect && onBlockSelect(block.block_id) }}
              >
                <Tooltip direction="top" offset={[0, -8]} className="map-tooltip">
                  <strong>Blk {block.block_num}</strong> {block.street_name}<br />
                  {block.avg_psf ? `$${block.avg_psf}/psf` : 'No data'} &middot; {remaining} yrs left
                </Tooltip>
              </Marker>
            );
          })}
        </LayerGroup>
      </MapContainer>

      <button className="map-help-btn" onClick={() => navigate('/how-it-works')}>
        <svg className="map-help-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10" />
          <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
          <line x1="12" y1="17" x2="12.01" y2="17" />
        </svg>
        <span>How it works</span>
      </button>

      {school && (
        <div className="map-legend">
          <div className="legend-item"><span className="legend-dot" style={{ background: '#4f46e5' }} /> School</div>
          <div className="legend-item"><span className="legend-dot" style={{ background: '#facc15', border: '1px solid #a16207' }} /> 1 km</div>
          <div className="legend-item"><span className="legend-dot" style={{ background: '#cbd5e1', border: '1px solid #475569' }} /> 1-2 km</div>
          {hiddenGemsActive && <div className="legend-item"><span className="legend-dot" style={{ background: '#2563eb', border: '1px solid #1d4ed8' }} /> Hidden Gem</div>}
          {leaseGuardActive && <div className="legend-item"><span className="legend-dot" style={{ background: '#ef4444', border: '1px solid #b91c1c' }} /> Lease risk</div>}
        </div>
      )}
    </div>
  );
}
