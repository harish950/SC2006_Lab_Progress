import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { forgotPassword } from '../services/authService';

export default function LoginModal({ onClose }) {
  const { login, register } = useAuth();
  const [mode, setMode] = useState('login'); // 'login' | 'register' | 'forgot'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [contactNo, setContactNo] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  const switchMode = (newMode) => {
    setMode(newMode);
    setError('');
    setSuccess('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    if (mode === 'forgot') {
      try {
        await forgotPassword(email);
        setSuccess('If that email is registered, a reset link has been sent. Check your inbox.');
      } catch (err) {
        setError(err.response?.data?.error || 'Something went wrong');
      }
      setLoading(false);
      return;
    }

    const result = mode === 'register'
      ? await register(email, password, contactNo)
      : await login(email, password);

    setLoading(false);

    if (result.success) {
      onClose();
    } else {
      setError(result.error);
    }
  };

  const title = mode === 'register' ? 'Create account' : mode === 'forgot' ? 'Reset password' : 'Log in';

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{title}</h2>
          <button className="modal-close" onClick={onClose}>&times;</button>
        </div>
        <form onSubmit={handleSubmit} className="modal-body">
          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="you@example.com"
              required
            />
          </div>
          {mode !== 'forgot' && (
            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Password"
                required
              />
            </div>
          )}
          {mode === 'register' && (
            <div className="form-group">
              <label>Contact number (optional)</label>
              <input
                type="tel"
                value={contactNo}
                onChange={e => setContactNo(e.target.value)}
                placeholder="91234567"
              />
            </div>
          )}
          {error && <p className="form-error">{error}</p>}
          {success && <p className="form-success">{success}</p>}
          <button type="submit" className="btn btn-primary btn-full" disabled={loading}>
            {loading ? 'Please wait...' : (
              mode === 'register' ? 'Create account' :
              mode === 'forgot' ? 'Send reset link' : 'Log in'
            )}
          </button>
          {mode === 'login' && (
            <>
              <p className="form-hint">
                <button type="button" className="link-btn" onClick={() => switchMode('forgot')}>
                  Forgot password?
                </button>
              </p>
              <p className="form-hint">
                Don't have an account?{' '}
                <button type="button" className="link-btn" onClick={() => switchMode('register')}>
                  Register
                </button>
              </p>
            </>
          )}
          {mode === 'register' && (
            <p className="form-hint">
              Already have an account?{' '}
              <button type="button" className="link-btn" onClick={() => switchMode('login')}>
                Log in
              </button>
            </p>
          )}
          {mode === 'forgot' && (
            <p className="form-hint">
              <button type="button" className="link-btn" onClick={() => switchMode('login')}>
                Back to login
              </button>
            </p>
          )}
        </form>
      </div>
    </div>
  );
}
