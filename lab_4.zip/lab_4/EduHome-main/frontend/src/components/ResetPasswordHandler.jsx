import React from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import ResetPasswordModal from './ResetPasswordModal';

export default function ResetPasswordHandler() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const token = searchParams.get('token');

  if (!token) {
    return (
      <div className="modal-overlay" onClick={() => navigate('/')}>
        <div className="modal-content" onClick={e => e.stopPropagation()}>
          <div className="modal-header">
            <h2>Reset password</h2>
            <button className="modal-close" onClick={() => navigate('/')}>&times;</button>
          </div>
          <div className="modal-body">
            <p className="form-error" style={{ textAlign: 'center' }}>No reset token provided</p>
            <button className="btn btn-outline btn-full" onClick={() => navigate('/')} style={{ marginTop: 12 }}>
              Go home
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <ResetPasswordModal
      token={token}
      onClose={() => navigate('/')}
      onSuccess={() => navigate('/')}
    />
  );
}
