import React, { useMemo } from 'react';

export default function HiddenGems({ active, onToggle, schoolId, blocks = [], onSelectBlock, selectedBlockId = null }) {
  const { gems, zoneAvgPSF } = useMemo(() => {
    const goldBlocks = blocks.filter(b => b.zone === 'GOLD_1KM' && b.avg_psf);
    if (goldBlocks.length === 0) return { gems: [], zoneAvgPSF: 0 };

    const avg = goldBlocks.reduce((s, b) => s + b.avg_psf, 0) / goldBlocks.length;
    const threshold = avg * 0.9;
    const found = blocks.filter(b => b.avg_psf && b.avg_psf < threshold);
    found.sort((a, b) => a.avg_psf - b.avg_psf);
    return { gems: found, zoneAvgPSF: avg };
  }, [blocks]);

  return (
    <div className="panel-card">
      <div className="panel-header">
        <h3 className="panel-title">Hidden Gems</h3>
        <button className={`toggle-btn ${active ? 'active' : ''}`} onClick={onToggle}>
          {active ? 'On' : 'Off'}
        </button>
      </div>
      <p className="panel-desc">Blocks below zone average of ${zoneAvgPSF.toFixed(2)}/psf</p>

      {active && (
        <div className="gem-list">
          {gems.length === 0 ? (
            <p className="empty-msg">None found in this zone</p>
          ) : (
            gems.map(b => {
              const clickable = typeof onSelectBlock === 'function';
              const ItemTag = clickable ? 'button' : 'div';

              return (
                <ItemTag
                  key={b.block_id}
                  className={`gem-item${clickable ? ' gem-item-btn' : ''}${selectedBlockId === b.block_id ? ' gem-item-selected' : ''}`}
                  type={clickable ? 'button' : undefined}
                  onClick={clickable ? () => onSelectBlock(b.block_id) : undefined}
                  aria-pressed={clickable ? selectedBlockId === b.block_id : undefined}
                >
                  <div className="gem-info">
                    <strong>Blk {b.block_num}</strong> {b.street_name}
                  </div>
                  <div className="gem-psf">
                    <span className="gem-price">${b.avg_psf.toFixed(2)}/psf</span>
                    <span className="gem-savings">-${(zoneAvgPSF - b.avg_psf).toFixed(2)}</span>
                  </div>
                </ItemTag>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}
