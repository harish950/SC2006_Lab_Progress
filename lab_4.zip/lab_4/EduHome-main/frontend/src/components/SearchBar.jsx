import React, { useState, useRef, useEffect, useCallback } from 'react';
import { getSuggestions } from '../services/searchService';

export default function SearchBar({ onSearch, size = 'large' }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState({ schools: [], blocks: [], areas: [] });
  const [showDropdown, setShowDropdown] = useState(false);
  const [error, setError] = useState('');
  const [highlightIdx, setHighlightIdx] = useState(-1);
  const wrapperRef = useRef(null);
  const debounceRef = useRef(null);

  // Build a flat list from all categories for keyboard navigation
  const flatItems = buildFlatList(results);

  useEffect(() => {
    function handleClickOutside(e) {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target)) {
        setShowDropdown(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const fetchSuggestions = useCallback((q) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!q.trim()) {
      setResults({ schools: [], blocks: [], areas: [] });
      setShowDropdown(false);
      return;
    }
    debounceRef.current = setTimeout(async () => {
      try {
        const data = await getSuggestions(q);
        setResults(data);
        const hasResults = data.schools.length > 0 || data.blocks.length > 0 || data.areas.length > 0;
        setShowDropdown(hasResults);
        if (hasResults) setError('');
      } catch {
        setResults({ schools: [], blocks: [], areas: [] });
        setShowDropdown(false);
      }
    }, 250);
  }, []);

  const handleChange = (e) => {
    const val = e.target.value;
    setQuery(val);
    setError('');
    setHighlightIdx(-1);
    fetchSuggestions(val);
  };

  const handleFocus = () => {
    if (query.trim().length >= 1 && flatItems.length > 0) {
      setShowDropdown(true);
    }
  };

  const handleSelect = (item) => {
    setQuery(item.label);
    setShowDropdown(false);
    setHighlightIdx(-1);
    onSearch(item);
  };

  const handleKeyDown = (e) => {
    if (!showDropdown || flatItems.length === 0) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlightIdx((prev) => (prev < flatItems.length - 1 ? prev + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlightIdx((prev) => (prev > 0 ? prev - 1 : flatItems.length - 1));
    } else if (e.key === 'Enter' && highlightIdx >= 0) {
      e.preventDefault();
      handleSelect(flatItems[highlightIdx]);
    } else if (e.key === 'Escape') {
      setShowDropdown(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!query.trim()) {
      setError('Please enter a search term');
      return;
    }
    if (flatItems.length > 0) {
      handleSelect(flatItems[0]);
    } else {
      setError('No results found. Try a school name, block number, or street.');
    }
  };

  let runningIdx = 0;

  return (
    <div className={`search-bar ${size}`} ref={wrapperRef}>
      <form onSubmit={handleSubmit} className="search-bar-form">
        <div className="search-input-wrapper">
          <svg className="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
          </svg>
          <input
            type="text"
            value={query}
            onChange={handleChange}
            onFocus={handleFocus}
            onKeyDown={handleKeyDown}
            placeholder="Search schools, blocks, or areas..."
            className="search-input"
            autoComplete="off"
          />
        </div>
        <button type="submit" className="btn btn-primary search-btn">Search</button>
      </form>

      {showDropdown && (
        <ul className="search-dropdown">
          {results.schools.length > 0 && (
            <>
              <li className="search-dropdown-header">Schools</li>
              {results.schools.map((s) => {
                const idx = runningIdx++;
                return (
                  <li
                    key={`school-${s.school_id}`}
                    onClick={() => handleSelect({ type: 'school', ...s, label: s.official_name })}
                    className={`search-dropdown-item${idx === highlightIdx ? ' highlighted' : ''}`}
                  >
                    <span className="search-dropdown-icon">🏫</span>
                    <span className="search-dropdown-name">{s.official_name}</span>
                  </li>
                );
              })}
            </>
          )}
          {results.blocks.length > 0 && (
            <>
              <li className="search-dropdown-header">HDB Blocks</li>
              {results.blocks.map((b) => {
                const idx = runningIdx++;
                return (
                  <li
                    key={`block-${b.block_id}`}
                    onClick={() => handleSelect({ type: 'block', ...b, label: `Blk ${b.block_num} ${b.street_name}` })}
                    className={`search-dropdown-item${idx === highlightIdx ? ' highlighted' : ''}`}
                  >
                    <span className="search-dropdown-icon">🏠</span>
                    <span className="search-dropdown-name">Blk {b.block_num} {b.street_name}</span>
                  </li>
                );
              })}
            </>
          )}
          {results.areas.length > 0 && (
            <>
              <li className="search-dropdown-header">Areas</li>
              {results.areas.map((street) => {
                const idx = runningIdx++;
                return (
                  <li
                    key={`area-${street}`}
                    onClick={() => handleSelect({ type: 'area', street_name: street, label: street })}
                    className={`search-dropdown-item${idx === highlightIdx ? ' highlighted' : ''}`}
                  >
                    <span className="search-dropdown-icon">📍</span>
                    <span className="search-dropdown-name">{street}</span>
                  </li>
                );
              })}
            </>
          )}
        </ul>
      )}

      {error && <p className="search-error">{error}</p>}
    </div>
  );
}

function buildFlatList({ schools, blocks, areas }) {
  const items = [];
  for (const s of schools) {
    items.push({ type: 'school', ...s, label: s.official_name });
  }
  for (const b of blocks) {
    items.push({ type: 'block', ...b, label: `Blk ${b.block_num} ${b.street_name}` });
  }
  for (const street of areas) {
    items.push({ type: 'area', street_name: street, label: street });
  }
  return items;
}
