import React, { useEffect, useState } from 'react';

const FLAT_TYPE_OPTIONS = ['2 ROOM', '3 ROOM', '4 ROOM', '5 ROOM', 'EXECUTIVE'];

export default function FilterPanel({ onApplyFilter, onClearFilters, resultCount, initialFilters = null }) {
  const [maxBudget, setMaxBudget] = useState('');
  const [minArea, setMinArea] = useState('');
  const [childStartYear, setChildStartYear] = useState('');
  const [selectedFlatTypes, setSelectedFlatTypes] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!initialFilters) {
      setMaxBudget('');
      setMinArea('');
      setChildStartYear('');
      setSelectedFlatTypes([]);
      return;
    }

    setMaxBudget(initialFilters.maxBudget != null ? String(initialFilters.maxBudget) : '');
    setMinArea(initialFilters.minArea != null ? String(initialFilters.minArea) : '');
    setChildStartYear(initialFilters.childStartYear != null ? String(initialFilters.childStartYear) : '');
    setSelectedFlatTypes(Array.isArray(initialFilters.flatTypes) ? initialFilters.flatTypes : []);
  }, [initialFilters]);

  const handleApply = (e) => {
    e.preventDefault();
    setError('');

    if (maxBudget && (isNaN(maxBudget) || Number(maxBudget) <= 0)) {
      setError('Budget must be a positive number');
      return;
    }
    if (minArea && (isNaN(minArea) || Number(minArea) <= 0)) {
      setError('Area must be a positive number');
      return;
    }
    if (childStartYear && (isNaN(childStartYear) || Number(childStartYear) < 2025 || Number(childStartYear) > 2035)) {
      setError('Year must be between 2025 and 2035');
      return;
    }

    onApplyFilter({
      maxBudget: maxBudget ? Number(maxBudget) : null,
      minArea: minArea ? Number(minArea) : null,
      childStartYear: childStartYear ? Number(childStartYear) : null,
      flatTypes: selectedFlatTypes.length > 0 ? selectedFlatTypes : null,
    });
  };

  const handleClear = () => {
    setMaxBudget('');
    setMinArea('');
    setChildStartYear('');
    setSelectedFlatTypes([]);
    setError('');
    onClearFilters();
  };

  return (
    <div className="panel-card filter-panel">
      <form onSubmit={handleApply}>
        <div className="form-group">
          <label>Max budget ($)</label>
          <input type="number" value={maxBudget} onChange={e => setMaxBudget(e.target.value)} placeholder="600000" />
        </div>
        <div className="form-group">
          <label>Min floor area (sqm)</label>
          <input type="number" value={minArea} onChange={e => setMinArea(e.target.value)} placeholder="70" />
        </div>
        <div className="form-group">
          <label>P1 start year</label>
          <input type="number" value={childStartYear} onChange={e => setChildStartYear(e.target.value)} placeholder="2027" />
        </div>
        <div className="form-group">
          <label>Housing type</label>
          <div className="chip-group">
            {FLAT_TYPE_OPTIONS.map(ft => {
              const active = selectedFlatTypes.includes(ft);
              return (
                <button
                  key={ft}
                  type="button"
                  className={`filter-chip ${active ? 'active' : ''}`}
                  onClick={() =>
                    setSelectedFlatTypes(prev =>
                      active ? prev.filter(t => t !== ft) : [...prev, ft]
                    )
                  }
                >
                  {ft}
                </button>
              );
            })}
          </div>
        </div>

        {error && <p className="form-error">{error}</p>}

        <div className="filter-actions">
          <button type="submit" className="btn btn-primary">Apply</button>
          <button type="button" className="btn btn-outline" onClick={handleClear}>Clear</button>
        </div>
      </form>

      {resultCount !== undefined && (
        <p className="filter-count">
          {resultCount === 0 ? 'No blocks match criteria' : `${resultCount} blocks`}
        </p>
      )}
    </div>
  );
}
