import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import SearchBar from './SearchBar';
import FilterPanel from './FilterPanel';

const FILTER_STORAGE_KEY = 'eduhome_active_filters';

function loadSavedFilters() {
  try {
    const raw = localStorage.getItem(FILTER_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch {
    return null;
  }
}

function normalizeCriteria(criteria = {}) {
  const normalized = {};
  if (criteria.maxBudget != null) normalized.maxBudget = Number(criteria.maxBudget);
  if (criteria.minArea != null) normalized.minArea = Number(criteria.minArea);
  if (criteria.childStartYear != null) normalized.childStartYear = Number(criteria.childStartYear);
  if (Array.isArray(criteria.flatTypes) && criteria.flatTypes.length > 0) {
    normalized.flatTypes = criteria.flatTypes;
  }
  return normalized;
}

function countActiveFilters(criteria = {}) {
  let count = 0;
  if (criteria.maxBudget != null) count += 1;
  if (criteria.minArea != null) count += 1;
  if (criteria.childStartYear != null) count += 1;
  if (Array.isArray(criteria.flatTypes) && criteria.flatTypes.length > 0) count += 1;
  return count;
}

export default function NavBar() {
  const { user, isAuthenticated, resendVerification } = useAuth();
  const navigate = useNavigate();
  const [filterOpen, setFilterOpen] = useState(false);
  const [activeFilters, setActiveFilters] = useState(() => loadSavedFilters());
  const [bannerDismissed, setBannerDismissed] = useState(false);
  const [resendStatus, setResendStatus] = useState(''); // '' | 'sending' | 'sent' | 'error'
  const filterRef = useRef(null);
  const activeFilterCount = countActiveFilters(activeFilters || {});
  const filterLabel = activeFilterCount > 0 ? `Filters (${activeFilterCount})` : 'Filters';

  const showVerifyBanner = isAuthenticated && user && !user.is_verified && !bannerDismissed;

  useEffect(() => {
    function handleClickOutside(e) {
      if (filterRef.current && !filterRef.current.contains(e.target)) {
        setFilterOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearch = (selection) => {
    navigate('/', { state: { selection, _ts: Date.now() } });
  };

  const handleApplyFilters = (criteria) => {
    const normalized = normalizeCriteria(criteria);
    setActiveFilters(normalized);
    localStorage.setItem(FILTER_STORAGE_KEY, JSON.stringify(normalized));
    navigate('/', { state: { filterAction: { type: 'apply', criteria: normalized }, _ts: Date.now() } });
    setFilterOpen(false);
  };

  const handleClearFilters = () => {
    setActiveFilters(null);
    localStorage.removeItem(FILTER_STORAGE_KEY);
    navigate('/', { state: { filterAction: { type: 'clear' }, _ts: Date.now() } });
    setFilterOpen(false);
  };

  const handleResendVerification = async () => {
    setResendStatus('sending');
    const result = await resendVerification();
    setResendStatus(result.success ? 'sent' : 'error');
  };

  return (
    <>
      <nav className="navbar">
        <div className="navbar-inner">
          <a
            href="/"
            className="navbar-brand"
            onClick={(e) => {
              e.preventDefault();
              navigate('/', { state: { reset: true, _ts: Date.now() } });
            }}
          >
            <span className="navbar-logo">E</span>
            <span>EduHome</span>
          </a>

          <div className="navbar-search">
            <SearchBar onSearch={handleSearch} size="small" />
            <div className="navbar-filter" ref={filterRef}>
              <button
                className={`btn navbar-filter-btn ${filterOpen ? 'btn-primary' : 'btn-outline'}`}
                onClick={() => setFilterOpen(!filterOpen)}
                type="button"
                aria-label="Toggle filters"
              >
                <span className="navbar-filter-btn-content">
                  <svg className="navbar-filter-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M3 5h18l-7 8v5l-4 2v-7L3 5z" />
                  </svg>
                  <span className="navbar-filter-text">{filterLabel}</span>
                </span>
              </button>
              {filterOpen && (
                <div className="navbar-filter-menu">
                  <FilterPanel
                    onApplyFilter={handleApplyFilters}
                    onClearFilters={handleClearFilters}
                    initialFilters={activeFilters}
                  />
                </div>
              )}
            </div>
          </div>

          <div className="navbar-right">
            {isAuthenticated ? (
              <Link to="/profile" className="navbar-user-btn">
                {user.email}
              </Link>
            ) : (
              <Link to="/profile" className="btn btn-sm btn-primary">
                Sign up
              </Link>
            )}
          </div>
        </div>
      </nav>

      {showVerifyBanner && (
        <div className="verify-banner">
          <span>
            Please verify your email address.
            {resendStatus === '' && (
              <button className="link-btn" onClick={handleResendVerification} style={{ marginLeft: 8 }}>
                Resend email
              </button>
            )}
            {resendStatus === 'sending' && <span style={{ marginLeft: 8 }}>Sending...</span>}
            {resendStatus === 'sent' && <span style={{ marginLeft: 8, color: 'var(--green)' }}>Sent!</span>}
            {resendStatus === 'error' && <span style={{ marginLeft: 8, color: 'var(--red)' }}>Failed to send</span>}
          </span>
          <button className="verify-banner-close" onClick={() => setBannerDismissed(true)}>&times;</button>
        </div>
      )}

    </>
  );
}
