import React, { useMemo } from 'react';

function getRemainingLease(leaseStart) {
  return 99 - (new Date().getFullYear() - leaseStart);
}

export default function LeaseGuard({ active, onToggle, schoolId, blocks = [], childStartYear }) {
  const currentYear = new Date().getFullYear();
  const requiredYears = childStartYear
    ? Math.max(0, childStartYear + 6 - currentYear)
    : 30;

  const flagged = useMemo(() => {
    return blocks.filter(b => {
      const remaining = getRemainingLease(b.lease_start_year);
      return remaining < requiredYears;
    });
  }, [blocks, requiredYears]);

  return (
    <div className="panel-card">
      <div className="panel-header">
        <h3 className="panel-title">Lease check</h3>
        <button className={`toggle-btn ${active ? 'active' : ''}`} onClick={onToggle}>
          {active ? 'On' : 'Off'}
        </button>
      </div>
      <p className="panel-desc">
        Flags blocks as insufficient when remaining lease is less than {requiredYears} years.
      </p>

      {active && (
        <div className="lease-list">
          {flagged.length === 0 ? (
            <p className="empty-msg success-msg">All leases sufficient</p>
          ) : (
            flagged.map(b => {
              const remaining = getRemainingLease(b.lease_start_year);
              return (
                <div key={b.block_id} className="lease-item">
                  <div className="lease-info">
                    <strong>Blk {b.block_num}</strong> {b.street_name}
                  </div>
                  <div className="lease-detail">
                    <span className="lease-years">{remaining} yrs</span>
                    <span className="lease-start">from {b.lease_start_year}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}
