"""Local development entry point — avoids the __main__ dual-module issue."""

from backend.app import create_app

app = create_app()
app.run(debug=True, port=5001)
