"""WatchlistUI — watchlist CRUD and alert endpoints (UC4, FR7)."""

from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user

from backend.control.watchlist_controller import WatchlistController

watchlist_bp = Blueprint("watchlist", __name__)


@watchlist_bp.route("/watchlist", methods=["GET"])
@login_required
def get_watchlist():
    """Retrieve the current user's watchlist items."""
    try:
        items = WatchlistController.get_user_watchlist(current_user.user_id)
        return jsonify({
            "success": True,
            "watchlist": items
        }), 200
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@watchlist_bp.route("/watchlist", methods=["POST"])
@login_required
def add_item():
    """Subscribe to a school zone with budget criteria."""
    data = request.get_json(silent=True) or {}
    school_id = data.get("school_id")
    min_budget = data.get("min_budget")
    max_budget = data.get("max_budget")

    if school_id is None:
        return jsonify({"success": False, "error": "school_id is required"}), 400

    if not current_user.contact_no:
        return jsonify({
            "success": False,
            "error": "Valid contact details are required before saving to watchlist"
        }), 400

    try:
        item = WatchlistController.add_watchlist_item(
            user_id=current_user.user_id,
            school_id=int(school_id),
            min_budget=float(min_budget) if min_budget is not None else None,
            max_budget=float(max_budget) if max_budget is not None else None,
        )
        if item is None:
            return jsonify({"success": False, "error": "Could not add watchlist item"}), 400

        return jsonify({
            "success": True,
            "message": "Watchlist item added successfully",
            "watch_item": {
                "watch_id": item.watch_id,
                "school_id": item.school_id,
                "min_budget": float(item.min_budget) if item.min_budget else None,
                "max_budget": float(item.max_budget) if item.max_budget else None,
                "is_active": item.is_active
            }
        }), 201

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@watchlist_bp.route("/watchlist/<int:watch_id>", methods=["DELETE"])
@login_required
def remove_item(watch_id):
    """Remove a watchlist subscription. Verifies ownership."""
    try:
        ok = WatchlistController.remove_watchlist_item(watch_id, current_user.user_id)
        if not ok:
            return jsonify({
                "success": False,
                "error": "Watchlist item not found or not owned by user"
            }), 404

        return jsonify({
            "success": True,
            "message": "Watchlist item removed successfully"
        }), 200

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@watchlist_bp.route("/watchlist/<int:watch_id>/toggle", methods=["PATCH"])
@login_required
def toggle_item(watch_id):
    """Pause or resume a watchlist subscription. Verifies ownership."""
    try:
        result = WatchlistController.toggle_watchlist_item(watch_id, current_user.user_id)
        if result is None:
            return jsonify({
                "success": False,
                "error": "Watchlist item not found or not owned by user"
            }), 404

        return jsonify({
            "success": True,
            "watch_item": result
        }), 200

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
