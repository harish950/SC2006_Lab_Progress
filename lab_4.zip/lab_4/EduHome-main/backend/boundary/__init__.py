# Blueprints are registered directly in app.py's create_app() to avoid
# circular imports (boundary routes import controllers, which import
# boundary/external APIs, which would trigger this __init__ again).
