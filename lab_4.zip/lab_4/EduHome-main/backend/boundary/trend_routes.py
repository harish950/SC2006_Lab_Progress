"""Market Trend — trend endpoints (UC6, FR3)."""

from flask import Blueprint, jsonify

from backend.app import cache
from backend.control.analytics_controller import AnalyticsController

trend_bp = Blueprint("trend", __name__)


@trend_bp.route("/trend/<int:block_id>", methods=["GET"])
@cache.cached(timeout=3600)
def get_market_trend(block_id):
    """UC6 — 12-month price trend with moving average and momentum."""
    try:
        result = AnalyticsController.generate_market_trend(block_id)

        if result is None:
            return jsonify({
                "error": "Insufficient historical data for this block"
            }), 404

        return jsonify(result), 200

    except Exception as e:
        return jsonify({
            "error": "Service unavailable",
            "details": str(e)
        }), 500
