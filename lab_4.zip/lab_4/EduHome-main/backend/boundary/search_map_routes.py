"""SearchMapUI — search and map endpoints (UC1, UC3, UC7, FR1, FR2, FR4)."""

from flask import Blueprint, request, jsonify
from sqlalchemy import func

from backend.app import cache
from backend.control.search_controller import SearchController
from backend.control.analytics_controller import AnalyticsController
from backend.entity import db
from backend.entity.primary_school import PrimarySchool

search_bp = Blueprint("search", __name__)


@search_bp.route("/schools", methods=["GET"])
@cache.cached(timeout=3600, key_prefix="all_schools")
def get_all_schools():
    """Return all primary schools for autocomplete and map display."""
    try:
        rows = db.session.query(
            PrimarySchool.school_id,
            PrimarySchool.official_name,
            PrimarySchool.postal_code,
            func.ST_Y(func.Geometry(PrimarySchool.location)).label("latitude"),
            func.ST_X(func.Geometry(PrimarySchool.location)).label("longitude"),
            PrimarySchool.vacancies,
        ).all()
        return jsonify([
            {
                "school_id": r.school_id,
                "official_name": r.official_name,
                "postal_code": r.postal_code,
                "latitude": r.latitude,
                "longitude": r.longitude,
                "vacancies": r.vacancies,
            }
            for r in rows
        ]), 200
    except Exception as e:
        return jsonify({
            "error": "Service unavailable",
            "details": str(e)
        }), 500


@search_bp.route("/search/suggestions", methods=["GET"])
@cache.cached(timeout=300, query_string=True)
def suggestions():
    """Smart search — return categorised suggestions for schools, blocks, areas."""
    q = request.args.get("q", "").strip()
    if not q:
        return jsonify({"schools": [], "blocks": [], "areas": []}), 200

    result = SearchController.get_suggestions(q)
    return jsonify(result), 200


def _by_block_cache_key():
    data = request.get_json(silent=True) or {}
    return f"search_by_block:{data.get('block_id', '')}"


@search_bp.route("/search/by-block", methods=["POST"])
@cache.cached(timeout=3600, make_cache_key=_by_block_cache_key)
def search_by_block():
    """Search by HDB block — find nearest school and return its priority zone."""
    data = request.get_json(silent=True) or {}
    block_id = data.get("block_id")

    if block_id is None:
        return jsonify({"error": "block_id is required"}), 400

    result = SearchController.search_by_block(block_id)
    if result is None:
        return jsonify({"error": "Block not found or no nearby school"}), 404

    return jsonify(result)


def _by_area_cache_key():
    data = request.get_json(silent=True) or {}
    return f"search_by_area:{data.get('street_name', '').strip()}"


@search_bp.route("/search/by-area", methods=["POST"])
@cache.cached(timeout=3600, make_cache_key=_by_area_cache_key)
def search_by_area():
    """Search by area/street — find nearest school and return its priority zone."""
    data = request.get_json(silent=True) or {}
    street_name = data.get("street_name", "").strip()

    if not street_name:
        return jsonify({"error": "street_name is required"}), 400

    result = SearchController.search_by_area(street_name)
    if result is None:
        return jsonify({"error": "Area not found or no nearby school"}), 404

    return jsonify(result)


def _search_cache_key():
    data = request.get_json(silent=True) or {}
    return f"search:{data.get('school_name', '').strip()}"


@search_bp.route("/search", methods=["POST"])
@cache.cached(timeout=3600, make_cache_key=_search_cache_key)
def search():
    """UC1 — Search school priority zone. Returns gold/silver HDB blocks."""
    data = request.get_json(silent=True) or {}
    school_name = data.get("school_name", "").strip()

    if not school_name:
        return jsonify({"error": "school_name is required"}), 400

    result = SearchController.search_school_priority_zone(school_name)
    if result is None:
        return jsonify({"error": "School not found"}), 404

    return jsonify(result)


@search_bp.route("/search/heatmap", methods=["POST"])
def heatmap():
    """UC7 — Affordability heatmap overlay for searched blocks."""
    data = request.get_json(silent=True) or {}
    blocks = data.get("blocks", [])

    if not blocks:
        # Also support school_name based lookup for backwards compat
        school_name = data.get("school_name")
        if school_name:
            result = SearchController.search_school_priority_zone(school_name)
            if result is None:
                return jsonify({"error": "Invalid school name"}), 404
            blocks = result["gold"] + result["silver"]
        else:
            return jsonify({"error": "blocks list is required"}), 400

    result = AnalyticsController.generate_affordability_heatmap(blocks)
    return jsonify(result)


@search_bp.route("/search/hidden-gems", methods=["POST"])
def hidden_gems():
    """UC3 — Identify undervalued blocks in the zone."""
    data = request.get_json(silent=True) or {}
    blocks = data.get("blocks", [])

    if not blocks:
        # Also support school_name based lookup for backwards compat
        school_name = data.get("school_name")
        if school_name:
            result = SearchController.search_school_priority_zone(school_name)
            if result is None:
                return jsonify({"error": "Invalid school name"}), 404
            blocks = result["gold"]
        else:
            return jsonify({"error": "blocks list is required"}), 400

    gems = AnalyticsController.calculate_valuation_gap(blocks)
    return jsonify(gems)
