"""ExternalOneMapAPI — SLA OneMap client for geocoding and routing.

Endpoints used:
  - Search (no auth):  GET /api/common/elastic/search
  - Routing (auth):    GET /api/public/routingsvc/route
  - Token:             POST /api/auth/post/getToken
"""

import logging
import time

import requests
from flask import current_app

logger = logging.getLogger(__name__)


class ExternalOneMapAPI:

    BASE_URL = "https://www.onemap.gov.sg/api"
    SEARCH_URL = f"{BASE_URL}/common/elastic/search"
    ROUTE_URL = f"{BASE_URL}/public/routingsvc/route"
    TOKEN_URL = f"{BASE_URL}/auth/post/getToken"

    # Rate-limit delay between consecutive requests (seconds).
    # Only applied for single calls; batch callers manage their own pacing
    # via concurrency limits.
    REQUEST_DELAY = 0.15

    # OneMap's search API degrades significantly under concurrent load
    # (tested 2-10 workers: all lose 30-95% of results). Sequential
    # geocoding at 0.15s delay gets 99.9% success rate.
    BATCH_CONCURRENCY = 1

    _cached_token = None
    _token_expiry = 0

    # ------------------------------------------------------------------
    # Geocoding (no auth required)
    # ------------------------------------------------------------------

    @classmethod
    def request_coordinates(cls, search_val):
        """Geocode an address or postal code to (lat, lng).

        Args:
            search_val: Address string or 6-digit postal code.

        Returns:
            (lat, lng) tuple, or None if not found / service unavailable.
        """
        if current_app.config.get("DEMO_MODE"):
            return cls._demo_coordinates(search_val)

        try:
            resp = requests.get(
                cls.SEARCH_URL,
                params={
                    "searchVal": str(search_val),
                    "returnGeom": "Y",
                    "getAddrDetails": "Y",
                    "pageNum": 1,
                },
                timeout=10,
            )
            resp.raise_for_status()
            data = resp.json()

            if data.get("found", 0) == 0:
                logger.debug("OneMap: No results for '%s'", search_val)
                return None

            result = data["results"][0]
            lat = float(result["LATITUDE"])
            lng = float(result["LONGITUDE"])
            return (lat, lng)

        except Exception:
            logger.debug(
                "OneMap: Geocode failed for '%s'", search_val, exc_info=True
            )
            return None
        finally:
            time.sleep(cls.REQUEST_DELAY)

    # ------------------------------------------------------------------
    # Batch geocoding (concurrent)
    # ------------------------------------------------------------------

    @classmethod
    def batch_geocode(cls, search_values):
        """Geocode multiple addresses concurrently with throttling.

        Uses a thread pool with a throttle to avoid overwhelming OneMap.
        ~5 concurrent requests with a small per-request delay gives roughly
        a 5x speedup over sequential calls while staying under rate limits.

        Args:
            search_values: List of address strings.

        Returns:
            Dict mapping search_val -> (lat, lng) or None.
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed
        import threading

        if current_app.config.get("DEMO_MODE"):
            return {sv: cls._demo_coordinates(sv) for sv in search_values}

        results = {}
        failed = 0
        throttle = threading.Semaphore(cls.BATCH_CONCURRENCY)

        def _geocode_one(search_val):
            with throttle:
                try:
                    resp = requests.get(
                        cls.SEARCH_URL,
                        params={
                            "searchVal": str(search_val),
                            "returnGeom": "Y",
                            "getAddrDetails": "Y",
                            "pageNum": 1,
                        },
                        timeout=10,
                    )
                    resp.raise_for_status()
                    data = resp.json()
                    if data.get("found", 0) == 0:
                        return (search_val, None)
                    r = data["results"][0]
                    return (search_val, (float(r["LATITUDE"]), float(r["LONGITUDE"])))
                except Exception:
                    return (search_val, None)
                finally:
                    time.sleep(cls.REQUEST_DELAY)

        with ThreadPoolExecutor(max_workers=cls.BATCH_CONCURRENCY) as pool:
            futures = {pool.submit(_geocode_one, sv): sv for sv in search_values}
            for future in as_completed(futures):
                sv, coords = future.result()
                results[sv] = coords
                if coords is None:
                    failed += 1

        if failed:
            logger.info(
                "OneMap: Batch geocoded %d addresses (%d not found)",
                len(search_values), failed,
            )

        return results

    # ------------------------------------------------------------------
    # Commute / routing (auth required)
    # ------------------------------------------------------------------

    @classmethod
    def request_commute_time(cls, start_lat, start_lng, end_lat, end_lng,
                             mode="pt"):
        """Get travel time between two points via OneMap routing API.

        Args:
            start_lat, start_lng: Origin coordinates.
            end_lat, end_lng:     Destination coordinates.
            mode: Route mode — "pt" (public transport), "drive", "walk",
                  "cycle". Default "pt".

        Returns:
            Travel time in minutes (int), or None on failure.
        """
        if current_app.config.get("DEMO_MODE"):
            return cls._demo_commute_time()

        token = cls._get_token()
        if token is None:
            logger.warning("OneMap: Cannot route without auth token")
            return None

        try:
            now_str = "07:30:00"  # default morning commute
            resp = requests.get(
                cls.ROUTE_URL,
                params={
                    "start": f"{start_lat},{start_lng}",
                    "end": f"{end_lat},{end_lng}",
                    "routeType": mode,
                    "date": "03-28-2026",
                    "time": now_str,
                    "mode": "TRANSIT",
                    "numItineraries": 1,
                },
                headers={"Authorization": token},
                timeout=15,
            )
            resp.raise_for_status()
            data = resp.json()

            plan = data.get("plan", {})
            itineraries = plan.get("itineraries", [])
            if not itineraries:
                return None

            duration_sec = itineraries[0].get("duration", 0)
            return max(1, round(duration_sec / 60))

        except Exception:
            logger.debug("OneMap: Routing failed", exc_info=True)
            return None
        finally:
            time.sleep(cls.REQUEST_DELAY)

    # ------------------------------------------------------------------
    # Auth token management
    # ------------------------------------------------------------------

    @classmethod
    def _get_token(cls):
        """Obtain or refresh the OneMap API auth token."""
        import time as _time

        if cls._cached_token and _time.time() < cls._token_expiry:
            return cls._cached_token

        # Try email/password auth first
        email = current_app.config.get("ONEMAP_EMAIL", "")
        password = current_app.config.get("ONEMAP_PASSWORD", "")
        if email and password:
            try:
                resp = requests.post(
                    cls.TOKEN_URL,
                    json={"email": email, "password": password},
                    timeout=10,
                )
                resp.raise_for_status()
                data = resp.json()

                cls._cached_token = data.get("access_token")
                cls._token_expiry = _time.time() + (2 * 24 * 3600)
                return cls._cached_token

            except Exception:
                logger.error("OneMap: Token request failed", exc_info=True)

        # Fall back to pre-configured token from env
        static_token = current_app.config.get("ONEMAP_TOKEN", "")
        if static_token:
            cls._cached_token = static_token
            cls._token_expiry = _time.time() + 3600
            return cls._cached_token

        logger.warning("OneMap: No auth credentials configured")
        return None

    # ------------------------------------------------------------------
    # Demo mode fallback (NFR3)
    # ------------------------------------------------------------------

    @staticmethod
    def _demo_coordinates(search_val):
        """Return cached coordinates for known demo addresses.

        Keys match both postal-code lookups (school geocoding) and
        block+street lookups (datasync geocoding, e.g. "115 JALAN BUKIT MERAH").
        """
        demo_cache = {
            # Schools (by postal code)
            "298981": (1.3048, 103.8198),   # Raffles Girls'
            "267923": (1.3150, 103.8050),   # Nanyang
            "428903": (1.3067, 103.9020),   # Tao Nan
            "278120": (1.3230, 103.7850),   # Henry Park
            "579646": (1.3540, 103.8380),   # Ai Tong
            "571402": (1.3530, 103.8488),   # CHIJ St Nicholas
            "579767": (1.3559, 103.8350),   # Catholic High
            "546417": (1.3575, 103.8810),   # Rosyth
            "279747": (1.3180, 103.7990),   # Pei Hwa
            "369117": (1.3260, 103.8830),   # Red Swastika
            # HDB blocks (by block + street from demo resale data)
            "115 JALAN BUKIT MERAH": (1.2827, 103.8025),
            "45 QUEENSWAY": (1.2958, 103.8005),
            "82 MARINE PARADE CENTRAL": (1.3030, 103.9065),
            # Additional schools (by name for datasync geocoding)
            "ANGLO-CHINESE SCHOOL (PRIMARY)": (1.3050, 103.8230),
            "METHODIST GIRLS' SCHOOL (PRIMARY)": (1.3070, 103.8270),
            "ST. HILDA'S PRIMARY SCHOOL": (1.3380, 103.9300),
            "KONG HWA SCHOOL": (1.3090, 103.8920),
            "CHONGFU SCHOOL": (1.3690, 103.8760),
            "RULANG PRIMARY SCHOOL": (1.3460, 103.7330),
            "NAN HUA PRIMARY SCHOOL": (1.3180, 103.8010),
            "MARIS STELLA HIGH SCHOOL (PRIMARY)": (1.3510, 103.8660),
            "RIVER VALLEY PRIMARY SCHOOL": (1.2930, 103.8260),
            "BEACON PRIMARY SCHOOL": (1.3950, 103.7470),
        }
        return demo_cache.get(str(search_val).strip())

    @staticmethod
    def _demo_commute_time():
        """Return a fixed commute time for demo mode."""
        return 15
