"""LoginUI — authentication endpoints (UC4)."""

from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user

from backend.control.account_controller import AccountController

auth_bp = Blueprint("auth", __name__)


def _user_dict(user):
    return {
        "id": user.user_id,
        "email": user.email,
        "contact_no": user.contact_no,
        "is_verified": user.is_verified,
    }


@auth_bp.route("/auth/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    email = data.get("email", "").strip()
    password = data.get("password", "")

    if not email or not password:
        return jsonify({"success": False, "error": "Email and password are required"}), 400

    try:
        user = AccountController.verify_credentials(email, password)
        if user is None:
            return jsonify({"success": False, "error": "Invalid email or password"}), 401

        AccountController.create_session(user)
        return jsonify({
            "success": True,
            "message": "Login successful",
            "user": _user_dict(user)
        }), 200

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@auth_bp.route("/auth/logout", methods=["POST"])
@login_required
def logout():
    AccountController.destroy_session()
    return jsonify({"success": True, "message": "Logged out"})


@auth_bp.route("/auth/register", methods=["POST"])
def register():
    data = request.get_json(silent=True) or {}
    email = data.get("email", "").strip()
    password = data.get("password", "")
    contact_no = data.get("contact_no")

    if not email or not password:
        return jsonify({"success": False, "error": "Email and password are required"}), 400

    try:
        user = AccountController.register_user(email, password, contact_no)
        if user is None:
            return jsonify({"success": False, "error": "Email already registered"}), 409

        AccountController.create_session(user)
        return jsonify({
            "success": True,
            "message": "Registration successful",
            "user": _user_dict(user)
        }), 201

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@auth_bp.route("/auth/me", methods=["GET"])
@login_required
def me():
    return jsonify({
        "success": True,
        "user": _user_dict(current_user)
    }), 200


@auth_bp.route("/auth/verify-email", methods=["POST"])
def verify_email():
    data = request.get_json(silent=True) or {}
    token = data.get("token", "")

    if not token:
        return jsonify({"success": False, "error": "Token is required"}), 400

    try:
        user = AccountController.confirm_email(token)
        if user is None:
            return jsonify({"success": False, "error": "Invalid or expired token"}), 400

        return jsonify({"success": True, "message": "Email verified"}), 200
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@auth_bp.route("/auth/resend-verification", methods=["POST"])
@login_required
def resend_verification():
    if current_user.is_verified:
        return jsonify({"success": False, "error": "Email already verified"}), 400

    AccountController.send_verification_email(current_user)
    return jsonify({"success": True, "message": "Verification email sent"}), 200


@auth_bp.route("/auth/forgot-password", methods=["POST"])
def forgot_password():
    data = request.get_json(silent=True) or {}
    email = data.get("email", "").strip()

    if not email:
        return jsonify({"success": False, "error": "Email is required"}), 400

    try:
        AccountController.send_reset_email(email)
        # Always return 200 to prevent email enumeration
        return jsonify({"success": True, "message": "If that email is registered, a reset link has been sent"}), 200
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@auth_bp.route("/auth/reset-password", methods=["POST"])
def reset_password():
    data = request.get_json(silent=True) or {}
    token = data.get("token", "")
    password = data.get("password", "")

    if not token or not password:
        return jsonify({"success": False, "error": "Token and password are required"}), 400

    if len(password) < 6:
        return jsonify({"success": False, "error": "Password must be at least 6 characters"}), 400

    try:
        success = AccountController.reset_password(token, password)
        if not success:
            return jsonify({"success": False, "error": "Invalid or expired token"}), 400

        return jsonify({"success": True, "message": "Password reset successful"}), 200
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@auth_bp.route("/auth/account", methods=["DELETE"])
@login_required
def delete_account():
    data = request.get_json(silent=True) or {}
    password = data.get("password", "")

    if not password:
        return jsonify({"success": False, "error": "Password is required"}), 400

    if not current_user.authenticate(password):
        return jsonify({"success": False, "error": "Incorrect password"}), 401

    try:
        success = AccountController.delete_account(current_user.user_id)
        if not success:
            return jsonify({"success": False, "error": "Failed to delete account"}), 500

        return jsonify({"success": True, "message": "Account deleted"}), 200
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
