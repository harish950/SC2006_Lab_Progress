"""FilterPanelUI — budget, area, and lease filter endpoints (UC2, UC9, FR6)."""

from flask import Blueprint, request, jsonify

from backend.control.search_controller import SearchController

filter_bp = Blueprint("filter", __name__)


@filter_bp.route("/filter", methods=["POST"])
def apply_filters():
    """UC2 + UC9 — Filter blocks by budget, area, and lease decay."""
    try:
        data = request.get_json(silent=True) or {}

        blocks = data.get("blocks", [])
        max_budget = data.get("maxBudget") or data.get("max_price")
        min_area = data.get("minArea") or data.get("min_area")
        child_start_year = data.get("childStartYear") or data.get("child_start_year")
        flat_types = data.get("flatTypes") or data.get("flat_types")

        if not isinstance(blocks, list) or not blocks:
            return jsonify({"error": "blocks list is required"}), 400

        try:
            if max_budget not in (None, ""):
                max_budget = float(max_budget)
                if max_budget < 0:
                    raise ValueError

            if min_area not in (None, ""):
                min_area = int(min_area)
                if min_area < 0:
                    raise ValueError

            if child_start_year not in (None, ""):
                child_start_year = int(child_start_year)
                if child_start_year < 0:
                    raise ValueError

        except (TypeError, ValueError):
            return jsonify({"error": "Invalid numeric input"}), 400

        filtered_blocks = SearchController.filter_by_budget_and_area(
            blocks,
            max_price=max_budget,
            min_area=min_area,
        )

        if flat_types and isinstance(flat_types, list):
            filtered_blocks = SearchController.filter_by_housing_type(
                filtered_blocks,
                flat_types,
            )

        if child_start_year is not None:
            filtered_blocks = SearchController.apply_lease_decay_guard(
                filtered_blocks,
                child_start_year,
            )

        return jsonify({"blocks": filtered_blocks}), 200

    except Exception as e:
        return jsonify({
            "error": "Service unavailable",
            "details": str(e)
        }), 500
