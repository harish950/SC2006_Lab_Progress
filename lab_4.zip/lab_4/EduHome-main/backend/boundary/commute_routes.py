"""Commute Optimizer — travel-time ranking endpoints (UC10, FR8)."""

from flask import Blueprint, request, jsonify

from backend.app import cache
from backend.control.commute_controller import CommuteController

commute_bp = Blueprint("commute", __name__)


def _commute_cache_key():
    data = request.get_json(silent=True) or {}
    return f"commute:{data.get('school_id', '')}:{data.get('top_n', 3)}"


def _commute_time_cache_key():
    data = request.get_json(silent=True) or {}
    return f"commute_time:{data.get('school_id', '')}:{data.get('block_id', '')}"


@commute_bp.route("/commute", methods=["POST"])
@cache.cached(timeout=3600, make_cache_key=_commute_cache_key)
def best_alternatives():
    """UC10 — Rank silver-zone blocks by shortest commute to school."""
    data = request.get_json(silent=True) or {}
    school_id = data.get("school_id")
    top_n = data.get("top_n", 3)

    if school_id is None:
        return jsonify({"error": "school_id is required"}), 400

    results = CommuteController.find_best_alternative_blocks(
        int(school_id), top_n=int(top_n),
    )
    if not results:
        return jsonify({"error": "No alternatives found or routing unavailable"}), 404

    return jsonify(results)


@commute_bp.route("/commute/time", methods=["POST"])
@cache.cached(timeout=3600, make_cache_key=_commute_time_cache_key)
def commute_time():
    """Get commute time between a specific block and school."""
    data = request.get_json(silent=True) or {}
    school_id = data.get("school_id")
    block_id = data.get("block_id")

    if school_id is None or block_id is None:
        return jsonify({"error": "school_id and block_id are required"}), 400

    minutes = CommuteController.get_commute_time(int(school_id), int(block_id))
    if minutes is None:
        return jsonify({"error": "Could not determine commute time"}), 404

    return jsonify({"travel_time_min": minutes})
