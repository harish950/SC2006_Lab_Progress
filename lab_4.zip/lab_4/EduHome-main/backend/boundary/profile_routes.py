"""Profile routes — email history for the current user."""

from flask import Blueprint, jsonify
from flask_login import login_required, current_user

from backend.entity.email_log import EmailLog

profile_bp = Blueprint("profile", __name__)


@profile_bp.route("/profile/emails", methods=["GET"])
@login_required
def get_email_logs():
    logs = (
        EmailLog.query
        .filter_by(user_id=current_user.user_id)
        .order_by(EmailLog.sent_at.desc())
        .all()
    )
    return jsonify({
        "success": True,
        "emails": [
            {
                "log_id": log.log_id,
                "email_type": log.email_type,
                "recipient": log.recipient,
                "subject": log.subject,
                "sent_at": log.sent_at.isoformat() if log.sent_at else None,
            }
            for log in logs
        ],
    })
