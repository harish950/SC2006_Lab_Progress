from datetime import datetime, timezone

from backend.entity import db


class EmailLog(db.Model):
    __tablename__ = "email_logs"

    log_id    = db.Column(db.Integer, primary_key=True)
    user_id   = db.Column(db.Integer, db.ForeignKey("users.user_id", ondelete="CASCADE"), nullable=False)
    email_type = db.Column(db.String(50), nullable=False)  # verification | password_reset | watchlist_alert
    recipient = db.Column(db.String(255), nullable=False)
    subject   = db.Column(db.String(500), nullable=False)
    sent_at   = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
