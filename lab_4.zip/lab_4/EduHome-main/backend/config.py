"""EduHome configuration — loaded via app.config.from_object(Config)."""

import os
from pathlib import Path

from dotenv import load_dotenv

# Load .env from project root
load_dotenv(Path(__file__).resolve().parent.parent / ".env")


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key")

    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL",
        "postgresql+psycopg2://localhost:5432/eduhome",
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
        "pool_size": 5,
        "max_overflow": 10,
        "pool_recycle": 300,
        "pool_timeout": 30,
        # TCP keepalive to prevent Neon from dropping idle connections
        "connect_args": {
            "keepalives": 1,
            "keepalives_idle": 30,
            "keepalives_interval": 10,
            "keepalives_count": 5,
        },
    }

    # External APIs
    ONEMAP_BASE_URL = "https://www.onemap.gov.sg/api"
    ONEMAP_TOKEN = os.environ.get("ONEMAP_TOKEN", "")
    ONEMAP_EMAIL = os.environ.get("ONEMAP_EMAIL", "")
    ONEMAP_PASSWORD = os.environ.get("ONEMAP_PASSWORD", "")

    GOVDATA_HDB_URL = "https://data.gov.sg/api/action/datastore_search"
    GOVDATA_MOE_URL = "https://data.gov.sg/api/action/datastore_search"
    GOV_DATA_API = os.environ.get("GOV_DATA_API", "")

    # Mail (for watchlist alerts — FR7)
    MAIL_SERVER = os.environ.get("MAIL_SERVER", "")
    MAIL_PORT = int(os.environ.get("MAIL_PORT", 587))
    MAIL_USE_TLS = os.environ.get("MAIL_USE_TLS", "true").lower() == "true"
    MAIL_USERNAME = os.environ.get("MAIL_USERNAME", "")
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD", "")
    MAIL_DEFAULT_SENDER = os.environ.get("MAIL_DEFAULT_SENDER", os.environ.get("MAIL_USERNAME", ""))

    # Frontend URL for email links
    FRONTEND_URL = os.environ.get("FRONTEND_URL", "http://localhost:3000")

    # Session cookie settings
    SESSION_COOKIE_SECURE = os.environ.get("SESSION_COOKIE_SECURE", "false").lower() == "true"
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = os.environ.get("SESSION_COOKIE_SAMESITE", "Lax")

    # CORS
    CORS_ORIGINS = os.environ.get("CORS_ORIGINS", "*")

    # Cache
    CACHE_TYPE = "SimpleCache"
    CACHE_DEFAULT_TIMEOUT = 3600

    # System settings
    DEMO_MODE = os.environ.get("DEMO_MODE", "false").lower() == "true"
    SYNC_INTERVAL_HOURS = int(os.environ.get("SYNC_INTERVAL_HOURS", 24))
