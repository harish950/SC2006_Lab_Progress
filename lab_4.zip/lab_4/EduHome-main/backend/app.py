"""EduHome Flask application factory."""

import logging
import os

from flask import Flask, jsonify, request
from flask_caching import Cache
from flask_cors import CORS
from flask_login import LoginManager
from flask_mail import Mail

from backend.config import Config
from backend.entity import db
from backend.entity.user import User

cache = Cache()
login_manager = LoginManager()
mail = Mail()


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


@login_manager.unauthorized_handler
def unauthorized():
    return jsonify({"success": False, "error": "Authentication required"}), 401

# Application factory
# 'testing' flag is used to disable heavy components (e.g. scheduler)
# during unit tests to prevent slowdowns and hanging
def create_app(testing=False):
    app = Flask(__name__)
    app.config.from_object(Config)
    app.config["TESTING"] = testing

    # Initialise extensions
    db.init_app(app)
    cache.init_app(app)
    login_manager.init_app(app)
    login_manager.session_protection = "strong"
    mail.init_app(app)
    CORS(app, supports_credentials=True, origins=Config.CORS_ORIGINS.split(","))

    # Register blueprints
    from backend.boundary.auth_routes import auth_bp
    from backend.boundary.search_map_routes import search_bp
    from backend.boundary.filter_panel_routes import filter_bp
    from backend.boundary.watchlist_routes import watchlist_bp
    from backend.boundary.trend_routes import trend_bp
    from backend.boundary.ballot_risk_routes import ballot_bp
    from backend.boundary.commute_routes import commute_bp
    from backend.boundary.profile_routes import profile_bp

    app.register_blueprint(auth_bp, url_prefix="/api")
    app.register_blueprint(search_bp, url_prefix="/api")
    app.register_blueprint(filter_bp, url_prefix="/api")
    app.register_blueprint(watchlist_bp, url_prefix="/api")
    app.register_blueprint(trend_bp, url_prefix="/api")
    app.register_blueprint(ballot_bp, url_prefix="/api")
    app.register_blueprint(commute_bp, url_prefix="/api")
    app.register_blueprint(profile_bp, url_prefix="/api")

    serverless = os.environ.get("SERVERLESS", "").lower() == "true"

    # Create tables on first run (skip in serverless — schema managed via migrations)
    if not serverless:
        with app.app_context():
            db.create_all()

    # Background data sync (UC5) — skip in serverless (replaced by Vercel Cron)
    if not app.config.get("TESTING") and not serverless:
        _start_scheduler(app)

    # Cron endpoint for Vercel scheduled functions
    @app.route("/api/cron/daily-sync", methods=["GET"])
    def cron_daily_sync():
        cron_secret = os.environ.get("CRON_SECRET", "")
        auth_header = request.headers.get("Authorization", "")
        if not cron_secret or auth_header != f"Bearer {cron_secret}":
            return jsonify({"error": "Unauthorized"}), 401

        from backend.control.datasync_controller import DataSyncController
        controller = DataSyncController(app=app)
        controller.trigger_daily_update()
        cache.clear()
        return jsonify({"success": True, "message": "Daily sync completed"})

    return app


def _start_scheduler(app):
    """Start APScheduler for periodic data sync."""
    try:
        from apscheduler.schedulers.background import BackgroundScheduler
        from backend.control.datasync_controller import DataSyncController

        controller = DataSyncController(app=app)
        hours = app.config.get("SYNC_INTERVAL_HOURS", 24)

        scheduler = BackgroundScheduler()
        scheduler.add_job(
            func=lambda: _run_sync(app, controller),
            trigger="interval",
            hours=hours,
            id="datasync",
        )
        scheduler.start()

        logging.getLogger(__name__).info(
            "APScheduler started — data sync every %d hours", hours,
        )
    except Exception:
        logging.getLogger(__name__).warning(
            "APScheduler not started", exc_info=True,
        )


def _run_sync(app, controller):
    """Run data sync inside an app context."""
    with app.app_context():
        controller.trigger_daily_update()
        cache.clear()


if __name__ == "__main__":
    # Use `python run.py` instead — running this file directly causes a
    # dual-module issue where __main__.cache != backend.app.cache.
    raise SystemExit("Run the dev server with: python run.py")
