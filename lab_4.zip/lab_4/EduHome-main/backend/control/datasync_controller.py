"""
DataSyncController -- scheduled background data ingestion (UC5).

State flow (from Dialog Map):
    IdleState -> RetrievingMarketData -> ValidatingMarketData
    -> UpdatingDatabase -> CheckingWatchlists -> SendingAlerts -> IdleState

Error / skip branches:
    ErrorMarketData     -- download or validation failure -> IdleState
    NoNewDataState      -- database already up to date    -> IdleState
    NoWatchlistMatchState -- no zones matched             -> IdleState
"""

import logging
from datetime import datetime

from flask import current_app
from sqlalchemy import text

from backend.entity import db
from backend.entity.transaction import Transaction
from backend.entity.hdb_block import HDBBlock
from backend.entity.primary_school import PrimarySchool
from backend.entity.persistent_store import PersistentStore
from backend.boundary.external.govdata_api import ExternalGovDataAPI
from backend.boundary.external.onemap_api import ExternalOneMapAPI

logger = logging.getLogger(__name__)


class DataSyncController:
    """Orchestrates daily data sync from data.gov.sg (UC5).

    Delegates to ExternalGovDataAPI for data retrieval and
    ExternalOneMapAPI for geocoding new HDB blocks.
    """

    REQUIRED_FIELDS = frozenset({
        "month", "town", "flat_type", "block",
        "street_name", "floor_area_sqm", "resale_price",
    })

    def __init__(self, app=None):
        self.app = app
        self._last_sync = None
        self._last_status = None
        self._geocode_cache = {}  # (block_num, street) -> (lat, lng) or None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def trigger_daily_update(self, months_back=None):
        """Entry point called by APScheduler on each sync interval.

        Args:
            months_back: If set, only fetch records from this many months ago
                         onwards. Useful for initial seeding (e.g. months_back=60
                         for 5 years). None fetches all available data.

        Returns True on success (including "no new data"), False on error.
        """
        logger.info("UC5: Data sync triggered")
        self._last_status = "running"

        try:
            # --- RetrievingMarketData ---
            raw_records = ExternalGovDataAPI.fetch_latest_resale_data(
                months_back=months_back
            )
            if raw_records is None:
                self._last_status = "error_download"
                logger.error("UC5: Failed to retrieve resale data")
                return False

            # --- ValidatingMarketData ---
            valid_records = self._validate_records(raw_records)
            if valid_records is None:
                self._last_status = "error_validation"
                logger.error("UC5: Data validation failed")
                return False

            # --- UpdatingDatabase ---
            new_count = self._persist_transactions(valid_records)
            logger.info("UC5: %d new transactions persisted", new_count)

            # --- Sync school vacancy data ---
            self._sync_school_vacancies()

            if new_count == 0:
                self._last_status = "no_new_data"
                logger.info("UC5: Database already up to date")
                return True

            # --- CheckingWatchlists / SendingAlerts ---
            self._check_watchlists_and_alert()

            self._last_sync = datetime.utcnow()
            self._last_status = "success"
            logger.info("UC5: Sync completed at %s", self._last_sync)
            return True

        except Exception:
            self._last_status = "error"
            logger.exception("UC5: Unexpected error during sync")
            return False

    def get_sync_status(self):
        """Return current sync state for monitoring / health-check."""
        return {
            "last_sync": self._last_sync.isoformat() if self._last_sync else None,
            "status": self._last_status,
        }

    # ------------------------------------------------------------------
    # ValidatingMarketData
    # ------------------------------------------------------------------

    def _validate_records(self, raw_records):
        """Check data format and structural integrity.

        Returns a list of validated records, or None if the schema itself
        is broken (missing required columns).
        """
        if not raw_records:
            return []

        # Schema check on the first record
        first_keys = set(raw_records[0].keys())
        missing = self.REQUIRED_FIELDS - first_keys
        if missing:
            logger.error("UC5: Schema mismatch -- missing fields: %s", missing)
            return None

        valid = []
        skipped = 0

        for rec in raw_records:
            try:
                price = float(rec.get("resale_price", 0))
                area = float(rec.get("floor_area_sqm", 0))
                month = rec.get("month", "")

                if price <= 0 or area <= 0:
                    skipped += 1
                    continue

                # month must be YYYY-MM
                datetime.strptime(month, "%Y-%m")

                valid.append(rec)
            except (ValueError, TypeError):
                skipped += 1

        if skipped:
            logger.warning("UC5: Skipped %d invalid records", skipped)

        return valid

    # ------------------------------------------------------------------
    # UpdatingDatabase
    # ------------------------------------------------------------------

    def _persist_transactions(self, valid_records):
        """Resolve block references, auto-create missing blocks via OneMap
        geocoding, and bulk-insert new transactions.

        Only records whose month is strictly after the latest transaction
        already stored are inserted, preventing duplicates across syncs.
        Returns the number of newly inserted rows.
        """
        if not valid_records:
            return 0

        # Latest month already in DB (None on first run)
        latest_date = db.session.query(
            db.func.max(Transaction.transaction_date)
        ).scalar()

        # Block lookup: (block_num, street_name) -> block_id
        block_lookup = {
            (b.block_num.strip().upper(), b.street_name.strip().upper()): b.block_id
            for b in HDBBlock.query.with_entities(
                HDBBlock.block_id, HDBBlock.block_num, HDBBlock.street_name
            ).all()
        }

        # --- First pass: collect unknown addresses that need geocoding ---
        addresses_to_geocode = set()
        for rec in valid_records:
            tx_date = datetime.strptime(rec["month"], "%Y-%m").date()
            if latest_date and tx_date <= latest_date:
                continue

            block_num = rec.get("block", "").strip().upper()
            street = rec.get("street_name", "").strip().upper()
            if (block_num, street) not in block_lookup:
                addresses_to_geocode.add((
                    block_num,
                    street,
                    rec.get("lease_commence_date", ""),
                ))

        # --- Batch geocode and create blocks ---
        if addresses_to_geocode:
            logger.info(
                "UC5: %d unknown blocks found — geocoding via OneMap",
                len(addresses_to_geocode),
            )
            created = self._batch_geocode_and_create_blocks(
                addresses_to_geocode, block_lookup,
            )
            logger.info("UC5: Created %d new HDB blocks", created)

        # --- Second pass: build transactions ---
        new_transactions = []
        unmatched_blocks = set()

        for rec in valid_records:
            tx_date = datetime.strptime(rec["month"], "%Y-%m").date()

            # Skip months we already have
            if latest_date and tx_date <= latest_date:
                continue

            block_num = rec.get("block", "").strip().upper()
            street = rec.get("street_name", "").strip().upper()
            block_id = block_lookup.get((block_num, street))

            if block_id is None:
                unmatched_blocks.add((block_num, street))
                continue

            new_transactions.append(Transaction(
                block_id=block_id,
                resale_price=float(rec["resale_price"]),
                floor_area_sqm=int(float(rec["floor_area_sqm"])),
                transaction_date=tx_date,
                flat_type=rec.get("flat_type", "").strip(),
            ))

        if unmatched_blocks:
            logger.warning(
                "UC5: %d block addresses could not be geocoded — "
                "transactions skipped",
                len(unmatched_blocks),
            )

        if new_transactions:
            PersistentStore.bulk_insert_transactions(new_transactions)

        return len(new_transactions)

    # ------------------------------------------------------------------
    # Batch geocode + bulk INSERT HDB blocks
    # ------------------------------------------------------------------

    def _batch_geocode_and_create_blocks(self, addresses_to_geocode, block_lookup):
        """Geocode addresses concurrently and bulk-insert new HDB blocks.

        Updates block_lookup in-place with new (block_num, street) -> block_id
        mappings. Returns the number of blocks created.
        """
        # Build search values, skipping addresses already in the geocode cache
        uncached = {}   # search_val -> (block_num, street, lease_str)
        cached = {}     # search_val -> (block_num, street, lease_str)

        for block_num, street, lease_str in addresses_to_geocode:
            search_val = f"{block_num} {street}"
            if (block_num, street) in self._geocode_cache:
                cached[search_val] = (block_num, street, lease_str)
            else:
                uncached[search_val] = (block_num, street, lease_str)

        # Concurrent geocoding for uncached addresses
        if uncached:
            geo_results = ExternalOneMapAPI.batch_geocode(list(uncached.keys()))
            for sv, coords in geo_results.items():
                bnum, st, _ = uncached[sv]
                self._geocode_cache[(bnum, st)] = coords

        # Merge cached + freshly geocoded into rows to insert
        all_entries = {}
        all_entries.update(uncached)
        all_entries.update(cached)

        rows = []
        for search_val, (block_num, street, lease_str) in all_entries.items():
            coords = self._geocode_cache.get((block_num, street))
            if coords is None:
                continue

            lat, lng = coords
            lease_year = None
            if lease_str:
                try:
                    lease_year = int(lease_str)
                except (ValueError, TypeError):
                    pass

            rows.append({
                "street": street,
                "block": block_num,
                "lease": lease_year,
                "lng": lng,
                "lat": lat,
            })

        if not rows:
            db.session.commit()
            return 0

        # Bulk INSERT blocks using a single statement with multiple
        # VALUES tuples so RETURNING works across all rows.
        try:
            values_clauses = []
            params = {}
            for i, r in enumerate(rows):
                values_clauses.append(
                    f"(:street_{i}, :block_{i}, :lease_{i},"
                    f" ST_SetSRID(ST_MakePoint(:lng_{i}, :lat_{i}), 4326)"
                    f"::geography)"
                )
                params[f"street_{i}"] = r["street"]
                params[f"block_{i}"] = r["block"]
                params[f"lease_{i}"] = r["lease"]
                params[f"lng_{i}"] = r["lng"]
                params[f"lat_{i}"] = r["lat"]

            sql = (
                "INSERT INTO hdb_blocks"
                " (street_name, block_num, lease_start_year, location)"
                f" VALUES {', '.join(values_clauses)}"
                " RETURNING block_id, block_num, street_name"
            )
            result = db.session.execute(text(sql), params)
            for row in result:
                block_lookup[(row.block_num.strip().upper(),
                              row.street_name.strip().upper())] = row.block_id
            db.session.commit()
        except Exception:
            db.session.rollback()
            logger.exception("UC5: Bulk block insert failed")
            return 0

        return len(rows)

    # ------------------------------------------------------------------
    # School vacancy sync
    # ------------------------------------------------------------------

    def _sync_school_vacancies(self):
        """Fetch MOE school vacancy data, update existing schools and
        insert any new schools discovered from the API.

        New schools are geocoded via OneMap and get auto-generated
        priority zones (1 km GOLD, 2 km SILVER).
        """
        try:
            records = ExternalGovDataAPI.fetch_school_vacancies()
            if records is None:
                logger.warning("UC5: Failed to fetch school vacancy data — skipping")
                return

            if not records:
                logger.info("UC5: No school vacancy records returned")
                return

            # Build lookup: upper-cased name -> PrimarySchool row
            schools = PrimarySchool.query.all()
            school_lookup = {
                s.official_name.strip().upper(): s for s in schools
            }

            updated = 0
            new_schools = []  # records for schools not yet in DB

            for rec in records:
                name = rec.get("school_name", "").strip().upper()
                vacancy = rec.get("vacancy")
                if not name or vacancy is None:
                    continue

                school = school_lookup.get(name)
                if school is not None:
                    try:
                        school.vacancies = int(vacancy)
                        updated += 1
                    except (ValueError, TypeError):
                        pass
                else:
                    new_schools.append(rec)

            if updated:
                db.session.commit()
            logger.info("UC5: Updated vacancies for %d schools", updated)

            # --- Insert new schools ---
            if new_schools:
                created = self._insert_new_schools(new_schools, school_lookup)
                logger.info("UC5: Inserted %d new schools", created)

        except Exception:
            db.session.rollback()
            logger.exception("UC5: Error syncing school vacancies")

    def _insert_new_schools(self, records, school_lookup):
        """Geocode and insert new schools, then create their priority zones.

        Args:
            records: list of API record dicts with school_name, vacancy.
            school_lookup: existing name->school map (upper-cased keys),
                           updated in-place with newly inserted schools.

        Returns number of schools created.
        """
        # Geocode school names via OneMap
        names_to_geocode = []
        for rec in records:
            display_name = rec.get("school_name", "").strip()
            if display_name:
                names_to_geocode.append(display_name)

        if not names_to_geocode:
            return 0

        logger.info(
            "UC5: Geocoding %d new schools via OneMap", len(names_to_geocode),
        )
        geo_results = ExternalOneMapAPI.batch_geocode(names_to_geocode)

        # Build and insert school rows
        created = 0
        new_school_ids = []

        for rec in records:
            display_name = rec.get("school_name", "").strip()
            upper_name = display_name.upper()
            if upper_name in school_lookup:
                continue  # already handled

            coords = geo_results.get(display_name)
            if coords is None:
                logger.debug("UC5: Could not geocode school '%s' — skipping", display_name)
                continue

            lat, lng = coords
            try:
                vacancy = int(rec.get("vacancy", 0))
            except (ValueError, TypeError):
                vacancy = 0

            # Title-case the name for consistent display
            official_name = display_name.title()

            school = PrimarySchool(
                official_name=official_name,
                location=PrimarySchool.make_location(lat, lng),
                vacancies=vacancy,
            )
            db.session.add(school)
            db.session.flush()  # assigns school_id

            school_lookup[upper_name] = school
            new_school_ids.append(school.school_id)
            created += 1

        if new_school_ids:
            db.session.commit()
            self._create_priority_zones(new_school_ids)

        return created

    def _create_priority_zones(self, school_ids):
        """Create GOLD_1KM and SILVER_2KM priority zones for the given schools."""
        try:
            for radius_tier, metres in [("GOLD_1KM", 1000), ("SILVER_2KM", 2000)]:
                sql = (
                    "INSERT INTO priority_zones (school_id, radius_tier, boundary) "
                    "SELECT school_id, :tier, ST_Buffer(location, :metres)::geography "
                    "FROM primary_schools WHERE school_id = ANY(:ids)"
                )
                db.session.execute(
                    text(sql),
                    {"tier": radius_tier, "metres": metres, "ids": school_ids},
                )
            db.session.commit()
            logger.info("UC5: Created priority zones for %d new schools", len(school_ids))
        except Exception:
            db.session.rollback()
            logger.exception("UC5: Failed to create priority zones")

    # ------------------------------------------------------------------
    # CheckingWatchlists / SendingAlerts
    # ------------------------------------------------------------------

    def _check_watchlists_and_alert(self):
        """Delegate to WatchlistController to match new data against
        active subscriptions and dispatch email notifications.

        Gracefully skips if the watchlist module is not yet implemented.
        """
        try:
            from backend.control.watchlist_controller import WatchlistController
            WatchlistController.check_triggers_and_send_alerts()
            logger.info("UC5: Watchlist alerts dispatched")
        except (ImportError, AttributeError):
            logger.info(
                "UC5: WatchlistController not available -- skipping alerts"
            )
