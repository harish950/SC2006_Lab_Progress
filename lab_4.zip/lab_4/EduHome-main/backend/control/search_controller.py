"""
SearchController — core search and zone logic (UC1, UC2, UC9).

FR1: Priority Zone Search — HDB blocks within 1km Gold / 2km Silver
FR6: Lease Decay Guard — flag blocks with insufficient remaining lease
"""

from datetime import date

from sqlalchemy import func, or_, text
from geoalchemy2 import Geography
from geoalchemy2.elements import WKTElement

from backend.entity import db
from backend.entity.primary_school import PrimarySchool
from backend.entity.priority_zone import PriorityZone
from backend.entity.hdb_block import HDBBlock
from backend.entity.transaction import Transaction


class SearchController:

    # ------------------------------------------------------------------
    # UC1 — Search School Priority Zone (FR1)
    # ------------------------------------------------------------------

    @staticmethod
    def validate_school_name(name):
        """Check school name against PrimarySchool dataset.

        Returns the PrimarySchool row if found, else None.
        """
        if not name or not name.strip():
            return None
        return PrimarySchool.query.filter(
            PrimarySchool.official_name.ilike(f"%{name.strip()}%")
        ).first()

    @staticmethod
    def search_school_priority_zone(school_name):
        """Retrieve all HDB blocks within 1km (Gold) and 2km (Silver) of a school.

        Returns dict: {"school": {...}, "gold": [...], "silver": [...]}
        or None if school not found.

        Uses PostGIS ST_DWithin for indexed spatial lookup (NFR1 < 2s).
        """
        school = SearchController.validate_school_name(school_name)
        if school is None:
            return None

        gold_blocks = (
            HDBBlock.query
            .filter(
                func.ST_DWithin(
                    HDBBlock.location,
                    school.location,
                    1000,  # 1km in metres (geography type)
                )
            )
            .all()
        )

        silver_blocks = (
            HDBBlock.query
            .filter(
                func.ST_DWithin(
                    HDBBlock.location,
                    school.location,
                    2000,  # 2km
                ),
                ~func.ST_DWithin(
                    HDBBlock.location,
                    school.location,
                    1000,
                ),
            )
            .all()
        )

        all_blocks = gold_blocks + silver_blocks
        all_block_ids = [b.block_id for b in all_blocks]
        tx_map = SearchController._batch_transaction_data(all_block_ids)

        return {
            "school": {
                "school_id": school.school_id,
                "official_name": school.official_name,
                "postal_code": school.postal_code,
                "latitude": school.latitude,
                "longitude": school.longitude,
                "vacancies": school.vacancies,
            },
            "gold": [SearchController._block_to_dict(b, "GOLD_1KM", tx_map) for b in gold_blocks],
            "silver": [SearchController._block_to_dict(b, "SILVER_2KM", tx_map) for b in silver_blocks],
        }

    # ------------------------------------------------------------------
    # UC2 — Filter by Budget and Area
    # ------------------------------------------------------------------

    @staticmethod
    def filter_by_budget_and_area(blocks, max_price=None, min_area=None):
        """Filter a list of block dicts by most recent transaction price
        and floor area.

        Args:
            blocks: List of block dicts (must include 'latest_price'/'latest_area'
                    from _batch_transaction_data).
            max_price: Maximum resale price filter (float), or None.
            min_area: Minimum floor area in sqm (int), or None.

        Returns filtered list.
        """
        if max_price is None and min_area is None:
            return blocks

        filtered = []
        for block in blocks:
            price = block.get("latest_price")
            area = block.get("latest_area")

            if price is None:
                # No transactions — keep block but it won't match price filter
                if max_price is None:
                    filtered.append(block)
                continue

            if max_price is not None and price > max_price:
                continue
            if min_area is not None and (area is None or area < min_area):
                continue

            filtered.append(block)

        return filtered

    # ------------------------------------------------------------------
    # UC9 ��� Lease Decay Guard (FR6)
    # ------------------------------------------------------------------

    @staticmethod
    def apply_lease_decay_guard(blocks, child_start_year):
        """Flag blocks where remaining lease is insufficient for 6 years
        of primary education starting from child_start_year.

        Adds 'lease_warning' boolean and 'remaining_lease' int to each block dict.
        """
        required_years = child_start_year + 6 - date.today().year
        current_year = date.today().year

        for block in blocks:
            remaining = 99 - (current_year - block.get("lease_start_year", current_year))
            block["remaining_lease"] = remaining
            block["lease_warning"] = remaining < required_years

        return blocks

    # ------------------------------------------------------------------
    # Smart Search — suggestions, block search, area search
    # ------------------------------------------------------------------

    @staticmethod
    def _find_nearest_school(location):
        """Find the closest PrimarySchool to a PostGIS geography point."""
        school = (
            PrimarySchool.query
            .order_by(func.ST_Distance(PrimarySchool.location, location))
            .first()
        )
        return school

    @staticmethod
    def get_suggestions(q, limit=8):
        """Return categorised suggestions: schools, blocks, areas."""
        if not q or not q.strip():
            return {"schools": [], "blocks": [], "areas": []}

        q = q.strip()
        pattern = f"%{q}%"

        schools = (
            PrimarySchool.query
            .filter(PrimarySchool.official_name.ilike(pattern))
            .limit(limit)
            .all()
        )

        blocks = (
            HDBBlock.query
            .filter(
                or_(
                    HDBBlock.block_num.ilike(pattern),
                    (HDBBlock.block_num + ' ' + HDBBlock.street_name).ilike(pattern),
                )
            )
            .limit(limit)
            .all()
        )

        area_rows = (
            db.session.query(HDBBlock.street_name)
            .filter(HDBBlock.street_name.ilike(pattern))
            .distinct()
            .limit(limit)
            .all()
        )

        return {
            "schools": [
                {
                    "school_id": s.school_id,
                    "official_name": s.official_name,
                    "postal_code": s.postal_code,
                }
                for s in schools
            ],
            "blocks": [
                {
                    "block_id": b.block_id,
                    "block_num": b.block_num,
                    "street_name": b.street_name,
                }
                for b in blocks
            ],
            "areas": [row.street_name for row in area_rows],
        }

    @staticmethod
    def search_by_block(block_id):
        """Find nearest school for a block and return priority zone results."""
        block = HDBBlock.query.get(block_id)
        if block is None:
            return None

        school = SearchController._find_nearest_school(block.location)
        if school is None:
            return None

        result = SearchController.search_school_priority_zone(school.official_name)
        if result is None:
            return None

        result["focus_block_id"] = block.block_id
        return result

    @staticmethod
    def search_by_area(street_name):
        """Find nearest school for an area (street) and return priority zone results."""
        if not street_name or not street_name.strip():
            return None

        street_name = street_name.strip()

        row = db.session.execute(
            text(
                "SELECT ST_Y(c::geometry) AS lat, ST_X(c::geometry) AS lng "
                "FROM (SELECT ST_Centroid(ST_Collect(location::geometry))::geography AS c "
                "      FROM hdb_blocks WHERE LOWER(street_name) = LOWER(:street)) sub"
            ),
            {"street": street_name},
        ).fetchone()

        if row is None or row.lat is None:
            return None

        point = WKTElement(f"POINT({row.lng} {row.lat})", srid=4326)

        school = SearchController._find_nearest_school(point)
        if school is None:
            return None

        result = SearchController.search_school_priority_zone(school.official_name)
        if result is None:
            return None

        result["focus_street"] = street_name
        result["area_center"] = {"latitude": row.lat, "longitude": row.lng}
        return result

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def filter_by_housing_type(blocks, flat_types):
        """Filter blocks that have at least one transaction matching the given flat types.

        Args:
            blocks: List of block dicts (must include 'flat_types' from _batch_transaction_data).
            flat_types: List of flat type strings, e.g. ["3 ROOM", "4 ROOM"].

        Returns filtered list.
        """
        if not flat_types:
            return blocks

        upper_types = {ft.upper() for ft in flat_types}
        return [
            block for block in blocks
            if {ft.upper() for ft in block.get("flat_types", []) if ft} & upper_types
        ]

    @staticmethod
    def _batch_transaction_data(block_ids):
        """Prefetch latest transaction + flat types for all blocks in 2 queries."""
        if not block_ids:
            return {}

        # Latest transaction per block (window function)
        from sqlalchemy import desc
        from sqlalchemy.orm import aliased

        ranked = (
            db.session.query(
                Transaction.block_id,
                Transaction.resale_price,
                Transaction.floor_area_sqm,
                func.row_number().over(
                    partition_by=Transaction.block_id,
                    order_by=desc(Transaction.transaction_date),
                ).label("rn"),
            )
            .filter(Transaction.block_id.in_(block_ids))
            .subquery()
        )
        latest_rows = (
            db.session.query(
                ranked.c.block_id,
                ranked.c.resale_price,
                ranked.c.floor_area_sqm,
            )
            .filter(ranked.c.rn == 1)
            .all()
        )

        # Distinct flat types per block
        type_rows = (
            db.session.query(Transaction.block_id, Transaction.flat_type)
            .filter(
                Transaction.block_id.in_(block_ids),
                Transaction.flat_type.isnot(None),
            )
            .distinct()
            .all()
        )

        # Build lookup map
        tx_map = {}
        for row in latest_rows:
            psf = None
            if row.floor_area_sqm and row.floor_area_sqm > 0:
                sqft = row.floor_area_sqm * 10.764
                psf = float(row.resale_price) / sqft
            tx_map[row.block_id] = {
                "avg_psf": psf,
                "latest_price": float(row.resale_price) if row.resale_price else None,
                "latest_area": row.floor_area_sqm,
                "flat_types": [],
            }

        for row in type_rows:
            if row.block_id in tx_map:
                tx_map[row.block_id]["flat_types"].append(row.flat_type)
            else:
                tx_map[row.block_id] = {
                    "avg_psf": None,
                    "latest_price": None,
                    "latest_area": None,
                    "flat_types": [row.flat_type],
                }

        return tx_map

    @staticmethod
    def _block_to_dict(block, zone, tx_map=None):
        """Convert an HDBBlock ORM object to a JSON-serialisable dict."""
        tx_data = (tx_map or {}).get(block.block_id, {})
        avg_psf = tx_data.get("avg_psf")
        flat_types = tx_data.get("flat_types", [])

        return {
            "block_id": block.block_id,
            "street_name": block.street_name,
            "block_num": block.block_num,
            "latitude": block.latitude,
            "longitude": block.longitude,
            "lease_start_year": block.lease_start_year,
            "total_units": block.total_units,
            "zone": zone,
            "avg_psf": round(avg_psf, 2) if avg_psf else None,
            "latest_price": tx_data.get("latest_price"),
            "latest_area": tx_data.get("latest_area"),
            "flat_types": flat_types,
        }
