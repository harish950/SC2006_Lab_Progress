"""
AccountController — authentication and session management (UC4).

Handles login credential verification, session creation/destruction,
email verification, password reset, and account deletion.
"""

import logging
from datetime import datetime, timezone

from flask import current_app
from flask_login import login_user, logout_user
from flask_mail import Message
from itsdangerous import URLSafeTimedSerializer, SignatureExpired, BadSignature
from werkzeug.security import generate_password_hash

from backend.entity import db
from backend.entity.user import User
from backend.entity.email_log import EmailLog

logger = logging.getLogger(__name__)


class AccountController:

    # ---- email log helper ----

    @staticmethod
    def _log_email(user_id, email_type, recipient, subject):
        entry = EmailLog(
            user_id=user_id,
            email_type=email_type,
            recipient=recipient,
            subject=subject,
            sent_at=datetime.now(timezone.utc),
        )
        db.session.add(entry)
        db.session.commit()

    # ---- token helpers ----

    @staticmethod
    def _get_serializer():
        return URLSafeTimedSerializer(current_app.config["SECRET_KEY"])

    @staticmethod
    def generate_token(email, salt):
        s = AccountController._get_serializer()
        return s.dumps(email, salt=salt)

    @staticmethod
    def verify_token(token, salt, max_age):
        s = AccountController._get_serializer()
        try:
            return s.loads(token, salt=salt, max_age=max_age)
        except (SignatureExpired, BadSignature):
            return None

    # ---- session management ----

    @staticmethod
    def verify_credentials(email, password):
        if not email or not password:
            return None
        user = User.query.filter_by(email=email).first()
        if user is None:
            return None
        if user.authenticate(password):
            return user
        return None

    @staticmethod
    def create_session(user):
        login_user(user)
        logger.info("UC4: Session created for user %s", user.email)
        return True

    @staticmethod
    def destroy_session():
        logout_user()
        logger.info("UC4: Session destroyed")
        return True

    # ---- registration ----

    @staticmethod
    def register_user(email, password, contact_no=None):
        if User.query.filter_by(email=email).first():
            return None

        user = User(
            email=email,
            password_hash=generate_password_hash(password, method="pbkdf2:sha256"),
            contact_no=contact_no,
        )
        db.session.add(user)
        db.session.commit()

        logger.info("UC4: New user registered: %s", email)

        try:
            AccountController.send_verification_email(user)
        except Exception:
            logger.warning("Failed to send verification email to %s", email, exc_info=True)

        return user

    # ---- email verification ----

    @staticmethod
    def send_verification_email(user):
        from backend.app import mail

        token = AccountController.generate_token(user.email, salt="email-verify")
        frontend_url = current_app.config.get("FRONTEND_URL", "http://localhost:3000")
        verify_link = f"{frontend_url}/verify-email?token={token}"

        msg = Message(
            subject="EduHome — Verify your email",
            recipients=[user.email],
            html=(
                f"<p>Hi,</p>"
                f"<p>Please verify your email by clicking the link below:</p>"
                f'<p><a href="{verify_link}">Click here to verify your email</a></p>'
                f"<p>This link expires in 24 hours.</p>"
                f"<p>— EduHome</p>"
            ),
        )
        mail.send(msg)
        AccountController._log_email(user.user_id, "verification", user.email, msg.subject)
        logger.info("Verification email sent to %s", user.email)

    @staticmethod
    def confirm_email(token):
        email = AccountController.verify_token(token, salt="email-verify", max_age=86400)
        if email is None:
            return None

        user = User.query.filter_by(email=email).first()
        if user is None:
            return None

        user.is_verified = True
        user.verified_at = datetime.now(timezone.utc)
        db.session.commit()
        logger.info("Email verified for %s", email)
        return user

    # ---- password reset ----

    @staticmethod
    def send_reset_email(email):
        from backend.app import mail

        user = User.query.filter_by(email=email).first()
        if user is None:
            return True  # prevent enumeration

        token = AccountController.generate_token(email, salt="password-reset")
        frontend_url = current_app.config.get("FRONTEND_URL", "http://localhost:3000")
        reset_link = f"{frontend_url}/reset-password?token={token}"

        msg = Message(
            subject="EduHome — Reset your password",
            recipients=[email],
            html=(
                f"<p>Hi,</p>"
                f"<p>Reset your password by clicking the link below:</p>"
                f'<p><a href="{reset_link}">Click here to reset your password</a></p>'
                f"<p>This link expires in 1 hour. If you didn't request this, ignore this email.</p>"
                f"<p>— EduHome</p>"
            ),
        )
        mail.send(msg)
        AccountController._log_email(user.user_id, "password_reset", email, msg.subject)
        logger.info("Password reset email sent to %s", email)
        return True

    @staticmethod
    def reset_password(token, new_password):
        email = AccountController.verify_token(token, salt="password-reset", max_age=3600)
        if email is None:
            return False

        user = User.query.filter_by(email=email).first()
        if user is None:
            return False

        user.set_password(new_password)
        db.session.commit()
        logger.info("Password reset for %s", email)
        return True

    # ---- account deletion ----

    @staticmethod
    def delete_account(user_id):
        user = User.query.get(user_id)
        if user is None:
            return False

        logout_user()
        db.session.delete(user)
        db.session.commit()
        logger.info("Account deleted: user_id=%s", user_id)
        return True
