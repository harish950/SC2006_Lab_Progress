#DONE: Tests for SearchController
# DONE: test_validate_school_name_valid — known school returns True
# DONE: test_validate_school_name_invalid — unknown school returns False
# DONE: test_search_returns_blocks_in_gold_zone — blocks within 1km returned
# DONE: test_search_returns_blocks_in_silver_zone — blocks within 2km returned
# DONE: test_filter_by_budget — blocks above maxPrice excluded
# DONE: test_filter_by_area — blocks below minArea excluded
# DONE: test_lease_decay_guard_flags_short_lease — blocks with < 6yr lease flagged


import pytest

from backend.control.search_controller import SearchController
from backend.app import create_app
from datetime import datetime
from backend.entity import db
from backend.entity.transaction import Transaction
from backend.entity.hdb_block import HDBBlock
from backend.entity.primary_school import PrimarySchool
from geoalchemy2.elements import WKTElement


@pytest.fixture
def app():
    app = create_app(testing = True)
    with app.app_context():
        yield app

# Auto-clean DB after each test to keep tests independent
@pytest.fixture(autouse=True)
def clean_db():
    yield
    db.session.rollback()

#1A: validate_school_name

def test_tc_s_01_known_school_returns_object(app):
    # TC-S-01: valid school (exists in DB), should return object
    result = SearchController.validate_school_name("Rosyth School")
    assert result is not None


def test_tc_s_02_unknown_school_returns_none(app):
    # TC-S-02: invalid school, should return None
    result = SearchController.validate_school_name("Nonexistent School XYZ")
    assert result is None


def test_tc_s_03_empty_string_returns_none(app):
    # TC-S-03: empty input, should return None
    result = SearchController.validate_school_name("")
    assert result is None


def test_tc_s_04_whitespace_returns_none(app):
    # TC-S-04: whitespace input, should return None
    result = SearchController.validate_school_name("   ")
    assert result is None


def test_tc_s_05_none_input_returns_none(app):
    # TC-S-05: None input, should return None
    result = SearchController.validate_school_name(None)
    assert result is None





# 1B: filter_by_budget_and_area
def test_tc_s_06_price_just_below_max_included(app):
    # Setup
    existing_block = HDBBlock.query.first()
    assert existing_block is not None

    transaction = Transaction(
        block_id=existing_block.block_id,
        resale_price=499999,   # just below 500000
        floor_area_sqm=100,    # valid area
        transaction_date=datetime.now()
    )
    db.session.add(transaction)
    db.session.commit()

    tx_map = SearchController._batch_transaction_data([existing_block.block_id])
    block = SearchController._block_to_dict(existing_block, "TEST", tx_map)

    # Test
    result = SearchController.filter_by_budget_and_area(
        [block],
        max_price=500000,
        min_area=None
    )

    # Assert
    assert len(result) == 1


def test_tc_s_07_price_at_max_included(app):
    # Setup
    existing_block = HDBBlock.query.offset(1).first()
    assert existing_block is not None

    transaction = Transaction(
        block_id=existing_block.block_id,
        resale_price=500000,   # exactly at max
        floor_area_sqm=100,
        transaction_date=datetime.now()
    )
    db.session.add(transaction)
    db.session.commit()

    tx_map = SearchController._batch_transaction_data([existing_block.block_id])
    block = SearchController._block_to_dict(existing_block, "TEST", tx_map)

    # Test
    result = SearchController.filter_by_budget_and_area(
        [block],
        max_price=500000,
        min_area=None
    )

    # Assert
    assert len(result) == 1

def test_tc_s_08_price_above_max_excluded(app):
    # Setup 
    existing_block = HDBBlock.query.offset(2).first()
    assert existing_block is not None

    block = {"block_id": existing_block.block_id}

    # create transaction just below max price
    transaction = Transaction(
        block_id=existing_block.block_id,
        resale_price=500001,   # just above 500000
        floor_area_sqm=100,   
        transaction_date=datetime.now()
    )
    db.session.add(transaction)
    db.session.commit()

    # Test 
    result = SearchController.filter_by_budget_and_area(
        [block],
        max_price=500000,
        min_area=None
    )

    # Assert 
    assert len(result) == 0

def test_tc_s_09_area_just_below_min_excluded(app):
    # Setup 
    existing_block = HDBBlock.query.offset(3).first()
    assert existing_block is not None

    block = {"block_id": existing_block.block_id}

    # create transaction just below max price
    transaction = Transaction(
        block_id=existing_block.block_id,
        resale_price=400000,   # safely below max
        floor_area_sqm=89,   
        transaction_date=datetime.now()
    )
    db.session.add(transaction)
    db.session.commit()

    # Test 
    result = SearchController.filter_by_budget_and_area(
        [block],
        max_price=500000,
        min_area=90
    )

    # Assert 
    assert len(result) == 0

def test_tc_s_10_area_at_min_included(app):
    # Setup
    existing_block = HDBBlock.query.offset(4).first()
    assert existing_block is not None

    transaction = Transaction(
        block_id=existing_block.block_id,
        resale_price=400000,   # safely below max
        floor_area_sqm=90,
        transaction_date=datetime.now()
    )
    db.session.add(transaction)
    db.session.commit()
    # Controller expects latest_price and latest_area in block dict
    # Fix: Populate block using transaction data helper
    tx_map = SearchController._batch_transaction_data([existing_block.block_id])
    block = SearchController._block_to_dict(existing_block, "TEST", tx_map)

    # Test
    result = SearchController.filter_by_budget_and_area(
        [block],
        max_price=500000,
        min_area=90
    )

    # Assert
    assert len(result) == 1


def test_tc_s_11_area_above_min_included(app):
    # Setup
    existing_block = HDBBlock.query.offset(5).first()
    assert existing_block is not None

    transaction = Transaction(
        block_id=existing_block.block_id,
        resale_price=400000,   # safely below max
        floor_area_sqm=91,
        transaction_date=datetime.now()
    )
    db.session.add(transaction)
    db.session.commit()

    tx_map = SearchController._batch_transaction_data([existing_block.block_id])
    block = SearchController._block_to_dict(existing_block, "TEST", tx_map)

    # Test
    result = SearchController.filter_by_budget_and_area(
        [block],
        max_price=500000,
        min_area=90
    )

    # Assert
    assert len(result) == 1
def test_tc_s_12_no_filters_returns_all(app):
    # Setup: create dummy blocks
    blocks = [
        {"block_id": 1},
        {"block_id": 2}
    ]

    # Test: no filters applied
    result = SearchController.filter_by_budget_and_area(
        blocks,
        max_price=None,
        min_area=None
    )

    # Assert: should return original list unchanged
    assert result == blocks

def test_tc_s_13_no_transaction_excluded(app):
    # Setup: use an existing block but DO NOT create transaction
    existing_block = HDBBlock.query.offset(6).first()
    assert existing_block is not None

    block = {"block_id": existing_block.block_id}

    # Test: apply price filter (requires transaction)
    result = SearchController.filter_by_budget_and_area(
        [block],
        max_price=500000,
        min_area=None
    )

    # Assert: block should be excluded because no transaction exists
    assert len(result) == 0


# 1C: lease_decay_guard_flags
def test_tc_s_14_sufficient_lease_not_flagged(app):
    # Setup: 70 years remaining, should be sufficient
    current_year = datetime.now().year
    blocks = [
        {"block_id": 1, "lease_start_year": current_year - 29}
    ]

    # Test
    result = SearchController.apply_lease_decay_guard(
        blocks,
        child_start_year=current_year
    )

    # Assert
    assert result[0]["lease_warning"] is False
    
def test_tc_s_15_insufficient_lease_flagged(app):
    # Setup: 3 years remaining, should be insufficient
    current_year = datetime.now().year
    blocks = [
        {"block_id": 2, "lease_start_year": current_year - 96}
    ]

    # Test
    result = SearchController.apply_lease_decay_guard(
        blocks,
        child_start_year=current_year
    )

    # Assert
    assert result[0]["lease_warning"] is True

def test_tc_s_16_remaining_equals_required_not_flagged(app):
    # Setup: remaining lease exactly equals required years (6)
    current_year = datetime.now().year
    blocks = [
        {"block_id": 3, "lease_start_year": current_year - 93}
    ]

    # Test
    result = SearchController.apply_lease_decay_guard(
        blocks,
        child_start_year=current_year
    )

    # Assert
    assert result[0]["lease_warning"] is False

def test_tc_s_17_remaining_required_minus_one_flagged(app):
    # Setup: remaining lease is one year less than required (5 < 6)
    current_year = datetime.now().year
    blocks = [
        {"block_id": 4, "lease_start_year": current_year - 94}
    ]

    # Test
    result = SearchController.apply_lease_decay_guard(
        blocks,
        child_start_year=current_year
    )

    # Assert
    assert result[0]["lease_warning"] is True

def test_tc_s_18_remaining_lease_value_correct(app):
    # Setup: 79 years remaining
    current_year = datetime.now().year
    blocks = [
        {"block_id": 5, "lease_start_year": current_year - 20}
    ]

    # Test
    result = SearchController.apply_lease_decay_guard(
        blocks,
        child_start_year=current_year
    )

    # Assert
    assert result[0]["remaining_lease"] == 79

def test_tc_s_19_search_priority_zones_spatial(app):
    # TC-S-19/20: test_search_returns_blocks_in_gold_zone & test_search_returns_blocks_in_silver_zone
    
    # 0. CLEANUP existing test records (if a previous run failed/committed)
    db.session.query(HDBBlock).filter(HDBBlock.block_id.in_([99901, 99902, 99903])).delete()
    db.session.query(PrimarySchool).filter(PrimarySchool.school_id == 9999).delete()
    db.session.commit()

    # 1. SETUP: Create a dummy school inside DB
    school = PrimarySchool(
        school_id=9999,
        official_name="Test Spatial School",
        postal_code="123456",
        # Define exact geographical point for the database
        location=WKTElement("POINT(103.800000 1.300000)", srid=4326),
        vacancies=100
    )
    db.session.add(school)
    
    # 0.0045 degrees of longitude = ~500 meters (GOLD ZONE)
    block_gold = HDBBlock(
        block_id=99901,
        location=WKTElement("POINT(103.804500 1.300000)", srid=4326),
        lease_start_year=2000
    )
    db.session.add(block_gold)

    # 0.0135 degrees of longitude = ~1.5 kilometers (SILVER ZONE)
    block_silver = HDBBlock(
        block_id=99902,
        location=WKTElement("POINT(103.813500 1.300000)", srid=4326),
        lease_start_year=2000
    )
    db.session.add(block_silver)

    # 0.0270 degrees of longitude = ~3.0 kilometers (OUTSIDE ZONES)
    block_outside = HDBBlock(
        block_id=99903,
        location=WKTElement("POINT(103.827000 1.300000)", srid=4326),
        lease_start_year=2000
    )
    db.session.add(block_outside)
    
    db.session.commit()
    
    result = SearchController.search_school_priority_zone("Test Spatial School")

    assert result is not None
    
    # The 500m block should be in the 'gold' array
    assert any(b["block_id"] == 99901 for b in result["gold"])
    
    # The 1.5km block should be in the 'silver' array
    assert any(b["block_id"] == 99902 for b in result["silver"])
    
    # The 3km block should NOT be in either array
    assert not any(b["block_id"] == 99903 for b in result["gold"])
    assert not any(b["block_id"] == 99903 for b in result["silver"])


# 2A: filter_by_budget_and_area (Basis Path)
def test_tc_sw_01_no_filters(app):
    # Path 1: both filters are None, early return
    blocks = [
        {"block_id": 101},
        {"block_id": 102}
    ]

    result = SearchController.filter_by_budget_and_area(
        blocks,
        max_price=None,
        min_area=None
    )

    assert result == blocks


def test_tc_sw_02_no_transaction(app):
    # Path 2: Uses a dummy block_id to simulate no transaction, 
    # ensuring the block is excluded when price filter is applied
    block = {"block_id": -999999}

    result = SearchController.filter_by_budget_and_area(
        [block],
        max_price=600000,
        min_area=None
    )

    assert len(result) == 0


def test_tc_sw_03_price_too_high(app):
    # Path 3: price > max_price, excluded
    existing_block = HDBBlock.query.offset(8).first()
    assert existing_block is not None

    block = {"block_id": existing_block.block_id}

    transaction = Transaction(
        block_id=existing_block.block_id,
        resale_price=700000,
        floor_area_sqm=100,
        transaction_date=datetime.now()
    )
    db.session.add(transaction)
    db.session.commit()

    result = SearchController.filter_by_budget_and_area(
        [block],
        max_price=600000,
        min_area=None
    )

    assert len(result) == 0


def test_tc_sw_04_area_too_small(app):
    # Path 4: price passes, but area < min_area, excluded
    existing_block = HDBBlock.query.offset(9).first()
    assert existing_block is not None

    block = {"block_id": existing_block.block_id}

    transaction = Transaction(
        block_id=existing_block.block_id,
        resale_price=500000,
        floor_area_sqm=70,
        transaction_date=datetime.now()
    )
    db.session.add(transaction)
    db.session.commit()

    result = SearchController.filter_by_budget_and_area(
        [block],
        max_price=600000,
        min_area=90
    )

    assert len(result) == 0


def test_tc_sw_05_all_checks_pass(app):
    # Path 5: price and area both pass, included
    existing_block = HDBBlock.query.offset(10).first()
    assert existing_block is not None

    transaction = Transaction(
        block_id=existing_block.block_id,
        resale_price=500000,
        floor_area_sqm=95,
        transaction_date=datetime.now()
    )
    db.session.add(transaction)
    db.session.commit()

    tx_map = SearchController._batch_transaction_data([existing_block.block_id])
    block = SearchController._block_to_dict(existing_block, "TEST", tx_map)

    result = SearchController.filter_by_budget_and_area(
        [block],
        max_price=600000,
        min_area=90
    )

    assert len(result) == 1


# 2B: apply_lease_decay_guard (Basis Path)
def test_tc_sw_06_empty_list_returns_empty(app):
    # TC-SW-06: Empty blocks list should return empty list
    blocks = []

    result = SearchController.apply_lease_decay_guard(
        blocks,
        child_start_year=datetime.now().year
    )

    assert result == []


def test_tc_sw_07_sufficient_lease_not_flagged(app):
    # TC-SW-07: Sufficient remaining lease should not be flagged
    current_year = datetime.now().year
    blocks = [
        {"block_id": 201, "lease_start_year": current_year - 10}  # 89 years remaining
    ]

    result = SearchController.apply_lease_decay_guard(
        blocks,
        child_start_year=current_year
    )

    assert result[0]["lease_warning"] is False


def test_tc_sw_08_lease_too_short_flagged(app):
    # TC-SW-08: Short remaining lease should be flagged
    current_year = datetime.now().year
    blocks = [
        {"block_id": 202, "lease_start_year": current_year - 96}  # 3 years remaining
    ]

    result = SearchController.apply_lease_decay_guard(
        blocks,
        child_start_year=current_year
    )

    assert result[0]["lease_warning"] is True


def test_tc_sw_09_mixed_blocks_flagged_independently(app):
    # TC-SW-09: Mixed blocks should be flagged independently
    current_year = datetime.now().year
    blocks = [
        {"block_id": 203, "lease_start_year": current_year - 10},  # 89 years remaining
        {"block_id": 204, "lease_start_year": current_year - 96},  # 3 years remaining
    ]

    result = SearchController.apply_lease_decay_guard(
        blocks,
        child_start_year=current_year
    )

    assert result[0]["lease_warning"] is False
    assert result[1]["lease_warning"] is True


def test_tc_sw_10_remaining_lease_annotated(app):
    # TC-SW-10: remaining_lease should be added correctly to each block
    current_year = datetime.now().year
    blocks = [
        {"block_id": 205, "lease_start_year": current_year - 20},
        {"block_id": 206, "lease_start_year": current_year - 20},
        {"block_id": 207, "lease_start_year": current_year - 20},
    ]

    result = SearchController.apply_lease_decay_guard(
        blocks,
        child_start_year=current_year
    )

    assert result[0]["remaining_lease"] == 79
    assert result[1]["remaining_lease"] == 79
    assert result[2]["remaining_lease"] == 79
