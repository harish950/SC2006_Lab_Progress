# TODO: Tests for AnalyticsController
# TODO: test_valuation_gap_identifies_hidden_gems — PSF below zone average flagged
# TODO: test_zone_average_psf_calculation — correct mean PSF computed
# TODO: test_market_trend_heating_up — rising moving average classified correctly
# TODO: test_market_trend_cooling_off — flat/declining average classified correctly
# TODO: test_affordability_heatmap_buckets — price buckets generated for zone
# TODO: test_balloting_risk_high — high unit density vs low vacancies = High risk
# TODO: test_balloting_risk_low — low density vs ample vacancies = Low risk



"""
Tests for AnalyticsController
Covers FR2 (Hidden Gems), FR3 (Market Trend), FR4 (Heatmap), FR5 (Ballot Risk)

Testing techniques:
  - Black Box: Equivalence Class + Boundary Value Analysis (Section 3.2.1)
  - White Box: Basis Path Testing on calculate_valuation_gap and
               generate_affordability_heatmap (Section 3.2.2)
"""

import pytest
from unittest.mock import MagicMock, patch


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _block_dict(block_id, avg_psf):
    return {"block_id": block_id, "street_name": "ANG MO KIO AVE 3",
            "block_num": str(block_id), "avg_psf": avg_psf}


# ---------------------------------------------------------------------------
# 1. BLACK BOX — calculate_valuation_gap  (Equivalence Class Testing)
# ---------------------------------------------------------------------------

class TestCalculateValuationGapBlackBox:
    """
    A block is a "Hidden Gem" if its avg_psf < zone_average * 0.90 (10% below avg).

    Equivalence Classes:
      EC1: block PSF >= 90% of zone average     -> NOT a hidden gem
      EC2: block PSF <  90% of zone average     -> IS a hidden gem
      EC3: no blocks have avg_psf data          -> returns empty list
      EC4: only one block (no meaningful avg)   -> cannot flag itself
    """

    def test_EC1_block_above_threshold_not_flagged(self):
        """EC1: Block PSF at 95% of zone avg -> not a hidden gem."""
        from backend.control.analytics_controller import AnalyticsController
        # zone avg = 600; threshold = 540; block at 570 (95%) -> not gem
        blocks = [_block_dict(1, 600), _block_dict(2, 600), _block_dict(3, 570)]
        gems = AnalyticsController.calculate_valuation_gap(blocks)
        gem_ids = [g["block_id"] for g in gems]
        assert 3 not in gem_ids

    def test_EC2_block_below_threshold_flagged(self):
        """EC2: Block PSF at 80% of zone avg -> is a hidden gem."""
        from backend.control.analytics_controller import AnalyticsController
        # zone avg = 600; threshold = 540; block at 480 (80%) -> gem
        blocks = [_block_dict(1, 600), _block_dict(2, 600), _block_dict(3, 480)]
        gems = AnalyticsController.calculate_valuation_gap(blocks)
        gem_ids = [g["block_id"] for g in gems]
        assert 3 in gem_ids

    def test_EC3_no_psf_data_returns_empty(self):
        """EC3: Blocks with no avg_psf -> nothing to compare, returns []."""
        from backend.control.analytics_controller import AnalyticsController
        blocks = [{"block_id": 1, "avg_psf": None}, {"block_id": 2, "avg_psf": None}]
        gems = AnalyticsController.calculate_valuation_gap(blocks)
        assert gems == []

    def test_EC4_single_block_not_flagged(self):
        """EC4: Single block is the only data point — it IS the average, not below it."""
        from backend.control.analytics_controller import AnalyticsController
        blocks = [_block_dict(1, 500)]
        gems = AnalyticsController.calculate_valuation_gap(blocks)
        assert gems == []

    def test_gem_includes_savings_psf_and_zone_avg(self):
        """Hidden gems should include zone_avg_psf and savings_psf fields."""
        from backend.control.analytics_controller import AnalyticsController
        blocks = [_block_dict(1, 600), _block_dict(2, 600), _block_dict(3, 400)]
        gems = AnalyticsController.calculate_valuation_gap(blocks)
        assert len(gems) == 1
        assert "zone_avg_psf" in gems[0]
        assert "savings_psf" in gems[0]
        assert gems[0]["savings_psf"] > 0


# ---------------------------------------------------------------------------
# 2. BLACK BOX — generate_affordability_heatmap  (Boundary Value Analysis)
# ---------------------------------------------------------------------------

class TestGenerateAffordabilityHeatmapBlackBox:
    """
    Heatmap colour buckets:
      < 400   -> green  (#16a34a)
      400-500 -> lime   (#65a30d)
      500-600 -> amber  (#d97706)
      600-700 -> orange (#ea580c)
      > 700   -> red    (#dc2626)
      None    -> grey   (#9ca3af)

    Boundary values tested at each bucket boundary:
      BV1: psf = 399 -> green
      BV2: psf = 400 -> lime  (at boundary, not < 400)
      BV3: psf = 500 -> amber
      BV4: psf = 600 -> orange
      BV5: psf = 700 -> red
      BV6: psf = None -> grey
    """

    def _heatmap(self, psf):
        from backend.control.analytics_controller import AnalyticsController
        blocks = [{"block_id": 1, "avg_psf": psf}]
        return AnalyticsController.generate_affordability_heatmap(blocks)[0]["heatmap_color"]

    def test_BV1_psf_399_green(self):
        """BV1: PSF just below 400 -> green."""
        assert self._heatmap(399) == "#16a34a"

    def test_BV2_psf_400_lime(self):
        """BV2: PSF at 400 boundary -> lime (not green)."""
        assert self._heatmap(400) == "#65a30d"

    def test_BV3_psf_500_amber(self):
        """BV3: PSF at 500 boundary -> amber."""
        assert self._heatmap(500) == "#d97706"

    def test_BV4_psf_600_orange(self):
        """BV4: PSF at 600 boundary -> orange."""
        assert self._heatmap(600) == "#ea580c"

    def test_BV5_psf_700_red(self):
        """BV5: PSF at 700 boundary -> red."""
        assert self._heatmap(700) == "#dc2626"

    def test_BV6_psf_none_grey(self):
        """BV6: No PSF data -> grey default."""
        assert self._heatmap(None) == "#9ca3af"


# ---------------------------------------------------------------------------
# 3. BLACK BOX — calculate_balloting_risk  (Equivalence Class Testing)
# ---------------------------------------------------------------------------

class TestCalculateBallotingRiskBlackBox:
    """
    Risk classification based on ratio = total_units_1km / vacancies:
      ratio >= 30 -> High
      15 <= ratio < 30 -> Medium
      ratio < 15  -> Low

    Equivalence Classes:
      EC1: ratio < 15   -> Low
      EC2: 15 <= r < 30 -> Medium
      EC3: ratio >= 30  -> High
      EC4: school not found -> returns None
    """

    def _mock_school_and_blocks(self, vacancies, units_1km):
        mock_school = MagicMock()
        mock_school.vacancies = vacancies
        mock_block = MagicMock()
        mock_block.total_units = units_1km
        return mock_school, [mock_block]

    def test_EC1_low_risk(self):
        """EC1: ratio = 5 (50 units / 10 vacancies) -> Low."""
        from backend.control.analytics_controller import AnalyticsController
        school, blocks = self._mock_school_and_blocks(vacancies=10, units_1km=50)
        with patch("backend.control.analytics_controller.PrimarySchool") as MockPS, \
             patch("backend.control.analytics_controller.HDBBlock") as MockHDB, \
             patch("backend.control.analytics_controller.func"):
            MockPS.query.get.return_value = school
            MockHDB.query.filter.return_value.all.return_value = blocks
            result = AnalyticsController.calculate_balloting_risk(school_id=1)
        assert result["risk"] == "Low"

    def test_EC2_medium_risk(self):
        """EC2: ratio = 20 (200 units / 10 vacancies) -> Medium."""
        from backend.control.analytics_controller import AnalyticsController
        school, _ = self._mock_school_and_blocks(vacancies=10, units_1km=200)
        mock_block = MagicMock()
        mock_block.total_units = 200
        with patch("backend.control.analytics_controller.PrimarySchool") as MockPS, \
             patch("backend.control.analytics_controller.HDBBlock") as MockHDB, \
             patch("backend.control.analytics_controller.func"):
            MockPS.query.get.return_value = school
            MockHDB.query.filter.return_value.all.return_value = [mock_block]
            result = AnalyticsController.calculate_balloting_risk(school_id=1)
        assert result["risk"] == "Medium"

    def test_EC3_high_risk(self):
        """EC3: ratio = 40 (400 units / 10 vacancies) -> High."""
        from backend.control.analytics_controller import AnalyticsController
        school, _ = self._mock_school_and_blocks(vacancies=10, units_1km=400)
        mock_block = MagicMock()
        mock_block.total_units = 400
        with patch("backend.control.analytics_controller.PrimarySchool") as MockPS, \
             patch("backend.control.analytics_controller.HDBBlock") as MockHDB, \
             patch("backend.control.analytics_controller.func"):
            MockPS.query.get.return_value = school
            MockHDB.query.filter.return_value.all.return_value = [mock_block]
            result = AnalyticsController.calculate_balloting_risk(school_id=1)
        assert result["risk"] == "High"

    def test_EC4_school_not_found_returns_none(self):
        """EC4: Invalid school_id -> returns None."""
        from backend.control.analytics_controller import AnalyticsController
        with patch("backend.control.analytics_controller.PrimarySchool") as MockPS:
            MockPS.query.get.return_value = None
            result = AnalyticsController.calculate_balloting_risk(school_id=9999)
        assert result is None


# ---------------------------------------------------------------------------
# 4. WHITE BOX — calculate_valuation_gap  (Basis Path Testing)
# ---------------------------------------------------------------------------

class TestCalculateValuationGapWhiteBox:
    """
    Basis Path Analysis:
      D1: no blocks have avg_psf     -> return []
      D2: loop blocks
      D3: block.avg_psf < threshold  -> add to gems list
      else: skip block

    Independent Paths:
      Path 1: D1=True  -> []
      Path 2: D1=False, D3=False for all -> no gems
      Path 3: D1=False, D3=True for some -> gems returned
      Path 4: all blocks below threshold  -> all are gems
    """

    def test_path1_empty_psf_returns_empty(self):
        """Path 1: No PSF values at all -> []."""
        from backend.control.analytics_controller import AnalyticsController
        blocks = [{"block_id": 1, "avg_psf": None}]
        assert AnalyticsController.calculate_valuation_gap(blocks) == []

    def test_path2_all_above_threshold_no_gems(self):
        """Path 2: All blocks PSF >= 90% of avg -> no gems."""
        from backend.control.analytics_controller import AnalyticsController
        # avg = 600, threshold = 540; all at 560 (above threshold)
        blocks = [_block_dict(i, 600) for i in range(5)]
        gems = AnalyticsController.calculate_valuation_gap(blocks)
        assert len(gems) == 0

    def test_path3_some_below_threshold_returned(self):
        """Path 3: One block below threshold -> returned as gem."""
        from backend.control.analytics_controller import AnalyticsController
        blocks = [_block_dict(1, 600), _block_dict(2, 600), _block_dict(3, 400)]
        gems = AnalyticsController.calculate_valuation_gap(blocks)
        assert len(gems) == 1
        assert gems[0]["block_id"] == 3

    def test_path4_all_below_threshold_all_are_gems(self):
        """Path 4: When avg is pulled up by one outlier, all others are gems."""
        from backend.control.analytics_controller import AnalyticsController
        # One very expensive block makes the average high, others are gems
        blocks = [_block_dict(1, 1000), _block_dict(2, 300), _block_dict(3, 300)]
        gems = AnalyticsController.calculate_valuation_gap(blocks)
        gem_ids = [g["block_id"] for g in gems]
        assert 2 in gem_ids
        assert 3 in gem_ids


# ---------------------------------------------------------------------------
# 5. WHITE BOX — generate_affordability_heatmap  (Basis Path Testing)
# ---------------------------------------------------------------------------

class TestGenerateAffordabilityHeatmapWhiteBox:
    """
    Basis Path Analysis:
      D1: loop over blocks
      D2: psf is None            -> grey
      D3: psf < 400              -> green
      D4: psf < 500              -> lime
      D5: psf < 600              -> amber
      D6: psf < 700              -> orange
      else                       -> red

    Independent Paths (one per branch):
      Path 1: psf = None   -> grey
      Path 2: psf = 300    -> green
      Path 3: psf = 450    -> lime
      Path 4: psf = 550    -> amber
      Path 5: psf = 650    -> orange
      Path 6: psf = 800    -> red
      Path 7: multiple blocks, each coloured correctly
    """

    def _color(self, psf):
        from backend.control.analytics_controller import AnalyticsController
        return AnalyticsController.generate_affordability_heatmap(
            [{"block_id": 1, "avg_psf": psf}]
        )[0]["heatmap_color"]

    def test_path1_none_grey(self):
        assert self._color(None) == "#9ca3af"

    def test_path2_300_green(self):
        assert self._color(300) == "#16a34a"

    def test_path3_450_lime(self):
        assert self._color(450) == "#65a30d"

    def test_path4_550_amber(self):
        assert self._color(550) == "#d97706"

    def test_path5_650_orange(self):
        assert self._color(650) == "#ea580c"

    def test_path6_800_red(self):
        assert self._color(800) == "#dc2626"

    def test_path7_multiple_blocks_all_coloured(self):
        """All blocks in a list get heatmap_color regardless of value."""
        from backend.control.analytics_controller import AnalyticsController
        blocks = [
            {"block_id": 1, "avg_psf": 300},
            {"block_id": 2, "avg_psf": 550},
            {"block_id": 3, "avg_psf": None},
        ]
        result = AnalyticsController.generate_affordability_heatmap(blocks)
        assert result[0]["heatmap_color"] == "#16a34a"
        assert result[1]["heatmap_color"] == "#d97706"
        assert result[2]["heatmap_color"] == "#9ca3af"