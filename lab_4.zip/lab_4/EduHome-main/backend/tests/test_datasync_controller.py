# TODO: Tests for DataSyncController
# TODO: test_daily_update_persists_new_transactions — new records written to DB
# TODO: test_invalid_data_rejected — corrupt/malformed data not persisted
# TODO: test_watchlist_check_triggered_after_sync — alerts evaluated after data update



"""
Tests for DataSyncController
Covers UC5 — Daily Data Sync (_validate_records method)

Testing technique:
  - Black Box: Equivalence Class Testing on _validate_records
  - White Box: Basis Path Testing on _validate_records
"""

import pytest
from backend.control.datasync_controller import DataSyncController


# ---------------------------------------------------------------------------
# 1. BLACK BOX — _validate_records  (Equivalence Class Testing)
# ---------------------------------------------------------------------------

class TestValidateRecordsBlackBox:
    """
    Equivalence Classes:
      EC1: well-formed records with all required fields and valid data -> returned
      EC2: record missing a required field (schema mismatch)           -> returns None
      EC3: record has price <= 0                                       -> skipped
      EC4: record has area <= 0                                        -> skipped
      EC5: record has malformed month string                           -> skipped
      EC6: empty input list                                            -> returns []
    """

    def _valid_record(self, price=500000, area=90, month="2024-06"):
        return {
            "month": month,
            "town": "TAMPINES",
            "flat_type": "4 ROOM",
            "block": "123",
            "street_name": "TAMPINES ST 11",
            "floor_area_sqm": str(area),
            "resale_price": str(price),
        }

    def setup_method(self):
        self.ctrl = DataSyncController()

    def test_EC1_valid_record_returned(self):
        """EC1: Complete valid record passes validation."""
        result = self.ctrl._validate_records([self._valid_record()])
        assert len(result) == 1

    def test_EC2_missing_required_field_returns_none(self):
        """EC2: Record missing 'resale_price' -> schema check fails -> None."""
        bad = {"month": "2024-06", "town": "TAMPINES", "flat_type": "4 ROOM",
               "block": "123", "street_name": "ST 11", "floor_area_sqm": "90"}
        result = self.ctrl._validate_records([bad])
        assert result is None

    def test_EC3_zero_price_skipped(self):
        """EC3: resale_price = 0 -> skipped (not included in result)."""
        result = self.ctrl._validate_records([self._valid_record(price=0)])
        assert result == []

    def test_EC3_negative_price_skipped(self):
        """EC3 (boundary): negative price -> skipped."""
        result = self.ctrl._validate_records([self._valid_record(price=-1)])
        assert result == []

    def test_EC4_zero_area_skipped(self):
        """EC4: floor_area_sqm = 0 -> skipped."""
        result = self.ctrl._validate_records([self._valid_record(area=0)])
        assert result == []

    def test_EC5_bad_month_format_skipped(self):
        """EC5: month = '2024/06' (wrong format) -> skipped."""
        result = self.ctrl._validate_records([self._valid_record(month="2024/06")])
        assert result == []

    def test_EC6_empty_input_returns_empty_list(self):
        """EC6: Empty list in -> empty list out (not None)."""
        result = self.ctrl._validate_records([])
        assert result == []

    def test_mixed_valid_and_invalid_only_valid_returned(self):
        """Mix of valid + invalid records -> only valid ones returned."""
        records = [
            self._valid_record(price=500000),   # valid
            self._valid_record(price=0),         # invalid
            self._valid_record(area=0),          # invalid
            self._valid_record(price=600000),    # valid
        ]
        result = self.ctrl._validate_records(records)
        assert len(result) == 2


# ---------------------------------------------------------------------------
# 2. WHITE BOX — _validate_records  (Basis Path Testing)
# ---------------------------------------------------------------------------

class TestValidateRecordsWhiteBox:
    """
    Basis Path Analysis for _validate_records:
      D1: raw_records is empty            -> return []
      D2: schema check fails (missing fields) -> return None
      D3: loop each record
      D4: price <= 0 or area <= 0         -> skip (skipped += 1)
      D5: month format invalid            -> skip (ValueError)
      else: append to valid list

    Independent Paths:
      Path 1: D1=True                          -> []
      Path 2: D1=False, D2=True                -> None
      Path 3: D1=False, D2=False, D4=True      -> record skipped
      Path 4: D1=False, D2=False, D5=True      -> record skipped (ValueError)
      Path 5: D1=False, D2=False, all pass     -> record included
    """

    def setup_method(self):
        self.ctrl = DataSyncController()

    def _rec(self, price=500000, area=90, month="2024-06"):
        return {
            "month": month, "town": "T", "flat_type": "4R",
            "block": "1", "street_name": "S", "floor_area_sqm": area,
            "resale_price": price,
        }

    def test_path1_empty_list(self):
        """Path 1: Empty input -> []."""
        assert self.ctrl._validate_records([]) == []

    def test_path2_schema_failure_returns_none(self):
        """Path 2: Missing required key -> None."""
        assert self.ctrl._validate_records([{"month": "2024-06"}]) is None

    def test_path3_bad_values_skipped(self):
        """Path 3: price=0 -> skipped, result empty."""
        assert self.ctrl._validate_records([self._rec(price=0)]) == []

    def test_path4_bad_month_format_skipped(self):
        """Path 4: Bad month string -> ValueError caught, record skipped."""
        assert self.ctrl._validate_records([self._rec(month="Jan-2024")]) == []

    def test_path5_valid_record_included(self):
        """Path 5: All valid -> record in result list."""
        result = self.ctrl._validate_records([self._rec()])
        assert len(result) == 1