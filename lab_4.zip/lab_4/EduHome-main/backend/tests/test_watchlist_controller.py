# TODO: Tests for WatchlistController
# TODO: test_add_watchlist_item — item persisted for user + school
# TODO: test_remove_watchlist_item — item deleted by watchID
# TODO: test_alert_triggered_on_matching_transaction — email sent when new txn matches zone + budget
# TODO: test_no_alert_when_no_match — no email when txn outside subscribed zones



"""
Tests for WatchlistController
Covers UC4 watchlist management and FR7 alert triggering

Testing technique: Black Box — Equivalence Class Testing
"""

import pytest
from unittest.mock import MagicMock, patch, call


class TestAddWatchlistItem:
    """
    Equivalence Classes:
      EC1: valid user, school -> WatchlistItem created and returned
      EC2: user not found     -> returns None
    """

    def test_EC1_valid_user_item_added(self):
        """EC1: Valid user_id -> watchlist item created."""
        mock_user = MagicMock()
        mock_user.contact_no = "91234567"
        mock_watchlist = MagicMock()
        mock_item = MagicMock()

        with patch("backend.control.watchlist_controller.User") as MockUser, \
             patch("backend.control.watchlist_controller.Watchlist") as MockWL, \
             patch("backend.control.watchlist_controller.WatchlistItem") as MockWLI, \
             patch("backend.control.watchlist_controller.db") as mock_db:
            MockUser.query.get.return_value = mock_user
            MockWL.query.filter_by.return_value.first.return_value = mock_watchlist
            MockWLI.return_value = mock_item
            from backend.control.watchlist_controller import WatchlistController
            result = WatchlistController.add_watchlist_item(1, 10, 400000, 600000)

        assert result is mock_item
        mock_db.session.add.assert_called()
        mock_db.session.commit.assert_called()

    def test_EC2_user_not_found_returns_none(self):
        """EC2: User not found -> None returned."""
        with patch("backend.control.watchlist_controller.User") as MockUser:
            MockUser.query.get.return_value = None
            from backend.control.watchlist_controller import WatchlistController
            result = WatchlistController.add_watchlist_item(999, 10, 400000, 600000)
        assert result is None


class TestRemoveWatchlistItem:
    """
    Equivalence Classes:
      EC1: item exists and belongs to user -> deleted, returns True
      EC2: item not found                  -> returns False
      EC3: item belongs to different user  -> returns False
    """

    def test_EC1_owned_item_removed(self):
        """EC1: Item exists and user owns it -> True."""
        mock_item = MagicMock()
        mock_item.watchlist_id = 1
        mock_watchlist = MagicMock()
        mock_watchlist.user_id = 42

        with patch("backend.control.watchlist_controller.WatchlistItem") as MockWLI, \
             patch("backend.control.watchlist_controller.Watchlist") as MockWL, \
             patch("backend.control.watchlist_controller.db") as mock_db:
            MockWLI.query.get.return_value = mock_item
            MockWL.query.get.return_value = mock_watchlist
            from backend.control.watchlist_controller import WatchlistController
            result = WatchlistController.remove_watchlist_item(watch_id=5, user_id=42)

        assert result is True
        mock_db.session.delete.assert_called_once_with(mock_item)

    def test_EC2_item_not_found_returns_false(self):
        """EC2: watch_id not in DB -> False."""
        with patch("backend.control.watchlist_controller.WatchlistItem") as MockWLI:
            MockWLI.query.get.return_value = None
            from backend.control.watchlist_controller import WatchlistController
            result = WatchlistController.remove_watchlist_item(watch_id=999, user_id=1)
        assert result is False

    def test_EC3_item_belongs_to_other_user_returns_false(self):
        """EC3: Item exists but owned by different user -> False."""
        mock_item = MagicMock()
        mock_item.watchlist_id = 1
        mock_watchlist = MagicMock()
        mock_watchlist.user_id = 99  # different from requesting user 42

        with patch("backend.control.watchlist_controller.WatchlistItem") as MockWLI, \
             patch("backend.control.watchlist_controller.Watchlist") as MockWL:
            MockWLI.query.get.return_value = mock_item
            MockWL.query.get.return_value = mock_watchlist
            from backend.control.watchlist_controller import WatchlistController
            result = WatchlistController.remove_watchlist_item(watch_id=5, user_id=42)
        assert result is False


class TestCheckTriggersAndSendAlerts:
    """
    Equivalence Classes:
      EC1: transaction matches zone and budget -> alert sent
      EC2: transaction outside zone            -> no alert
      EC3: no recent transactions              -> no alerts, returns early
    """

    def test_EC3_no_recent_transactions_returns_early(self):
        """EC3: No transactions in last 7 days -> function exits without alerting."""
        with patch("backend.control.watchlist_controller.Transaction") as MockTx, \
             patch("backend.control.watchlist_controller.WatchlistItem"):
            MockTx.query.filter.return_value.all.return_value = []
            from backend.control.watchlist_controller import WatchlistController
            # Should complete without error
            WatchlistController.check_triggers_and_send_alerts()
            # WatchlistItem.query was not called because we returned early