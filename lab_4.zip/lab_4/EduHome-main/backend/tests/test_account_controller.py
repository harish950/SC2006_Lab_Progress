# TODO: Tests for AccountController
# TODO: test_valid_credentials_login — correct email + password creates session
# TODO: test_invalid_credentials_rejected — wrong password returns failure
# TODO: test_session_destroyed_on_logout — session token invalidated



"""
Tests for AccountController
Covers UC4 login, logout, and registration

Testing technique: Black Box — Equivalence Class Testing
"""

import pytest
from unittest.mock import MagicMock, patch


class TestVerifyCredentialsBlackBox:
    """
    Equivalence Classes:
      EC1: valid email + correct password   -> returns User object
      EC2: valid email + wrong password     -> returns None
      EC3: email not found in DB            -> returns None
      EC4: empty email or empty password    -> returns None
    """

    def test_EC1_valid_credentials_returns_user(self):
        """EC1: Correct email and password -> User object returned."""
        mock_user = MagicMock()
        mock_user.authenticate.return_value = True
        with patch("backend.control.account_controller.User") as MockUser:
            MockUser.query.filter_by.return_value.first.return_value = mock_user
            from backend.control.account_controller import AccountController
            result = AccountController.verify_credentials("test@example.com", "correct_pw")
        assert result is mock_user

    def test_EC2_wrong_password_returns_none(self):
        """EC2: Correct email but wrong password -> None."""
        mock_user = MagicMock()
        mock_user.authenticate.return_value = False
        with patch("backend.control.account_controller.User") as MockUser:
            MockUser.query.filter_by.return_value.first.return_value = mock_user
            from backend.control.account_controller import AccountController
            result = AccountController.verify_credentials("test@example.com", "wrong_pw")
        assert result is None

    def test_EC3_email_not_found_returns_none(self):
        """EC3: Email not in DB -> None."""
        with patch("backend.control.account_controller.User") as MockUser:
            MockUser.query.filter_by.return_value.first.return_value = None
            from backend.control.account_controller import AccountController
            result = AccountController.verify_credentials("ghost@example.com", "anypassword")
        assert result is None

    def test_EC4_empty_email_returns_none(self):
        """EC4: Empty email short-circuits to None."""
        from backend.control.account_controller import AccountController
        assert AccountController.verify_credentials("", "password") is None

    def test_EC4_empty_password_returns_none(self):
        """EC4: Empty password short-circuits to None."""
        from backend.control.account_controller import AccountController
        assert AccountController.verify_credentials("test@example.com", "") is None

    def test_EC4_both_empty_returns_none(self):
        """EC4: Both fields empty -> None."""
        from backend.control.account_controller import AccountController
        assert AccountController.verify_credentials("", "") is None


class TestSessionManagement:
    """Tests for create_session and destroy_session."""

    def test_create_session_calls_login_user(self):
        """create_session should call Flask-Login login_user and return True."""
        mock_user = MagicMock()
        with patch("backend.control.account_controller.login_user") as mock_login:
            from backend.control.account_controller import AccountController
            result = AccountController.create_session(mock_user)
        mock_login.assert_called_once_with(mock_user)
        assert result is True

    def test_destroy_session_calls_logout_user(self):
        """destroy_session should call Flask-Login logout_user and return True."""
        with patch("backend.control.account_controller.logout_user") as mock_logout:
            from backend.control.account_controller import AccountController
            result = AccountController.destroy_session()
        mock_logout.assert_called_once()
        assert result is True


class TestRegisterUser:
    """
    Equivalence Classes:
      EC1: new unique email -> User created and returned
      EC2: duplicate email  -> returns None
    """

    def test_EC1_new_email_creates_user(self):
        """EC1: Unique email -> user created."""
        with patch("backend.control.account_controller.User") as MockUser, \
             patch("backend.control.account_controller.db") as mock_db:
            MockUser.query.filter_by.return_value.first.return_value = None
            new_user = MagicMock()
            MockUser.return_value = new_user
            from backend.control.account_controller import AccountController
            result = AccountController.register_user("new@example.com", "securepass")
        assert result is new_user
        mock_db.session.add.assert_called_once()
        mock_db.session.commit.assert_called_once()

    def test_EC2_duplicate_email_returns_none(self):
        """EC2: Email already registered -> None."""
        existing = MagicMock()
        with patch("backend.control.account_controller.User") as MockUser:
            MockUser.query.filter_by.return_value.first.return_value = existing
            from backend.control.account_controller import AccountController
            result = AccountController.register_user("existing@example.com", "pass")
        assert result is None