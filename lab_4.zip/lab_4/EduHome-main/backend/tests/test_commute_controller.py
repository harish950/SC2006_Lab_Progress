# TODO: Tests for CommuteController
# TODO: test_commute_time_returned — valid origin + school returns travel minutes
# TODO: test_best_alternative_block — block with shortest bus time ranked first
# TODO: test_routing_service_unavailable — graceful error when OneMap is down



"""
Tests for CommuteController
Covers UC10, FR8 — Commute Optimizer

Testing technique: Black Box — Equivalence Class Testing
"""

import pytest
from unittest.mock import MagicMock, patch


class TestGetCommuteTime:
    """
    Equivalence Classes:
      EC1: valid school_id and block_id          -> returns travel time (int)
      EC2: school_id not found                   -> returns None
      EC3: block_id not found                    -> returns None
      EC4: OneMap API unavailable / returns None -> returns None
    """

    def test_EC1_valid_ids_returns_travel_time(self):
        """EC1: Valid school and block -> returns travel minutes from OneMap."""
        mock_school = MagicMock()
        mock_school.latitude, mock_school.longitude = 1.350, 103.949
        mock_block  = MagicMock()
        mock_block.latitude, mock_block.longitude  = 1.354, 103.945

        with patch("backend.control.commute_controller.PrimarySchool") as MockPS, \
             patch("backend.control.commute_controller.HDBBlock") as MockHDB, \
             patch("backend.control.commute_controller.ExternalOneMapAPI") as MockAPI:
            MockPS.query.get.return_value = mock_school
            MockHDB.query.get.return_value = mock_block
            MockAPI.request_commute_time.return_value = 18
            from backend.control.commute_controller import CommuteController
            result = CommuteController.get_commute_time(school_id=1, block_id=5)

        assert result == 18

    def test_EC2_school_not_found_returns_none(self):
        """EC2: Invalid school_id -> None."""
        with patch("backend.control.commute_controller.PrimarySchool") as MockPS, \
             patch("backend.control.commute_controller.HDBBlock") as MockHDB:
            MockPS.query.get.return_value = None
            MockHDB.query.get.return_value = MagicMock()
            from backend.control.commute_controller import CommuteController
            result = CommuteController.get_commute_time(school_id=999, block_id=5)
        assert result is None

    def test_EC3_block_not_found_returns_none(self):
        """EC3: Invalid block_id -> None."""
        with patch("backend.control.commute_controller.PrimarySchool") as MockPS, \
             patch("backend.control.commute_controller.HDBBlock") as MockHDB:
            MockPS.query.get.return_value = MagicMock()
            MockHDB.query.get.return_value = None
            from backend.control.commute_controller import CommuteController
            result = CommuteController.get_commute_time(school_id=1, block_id=999)
        assert result is None

    def test_EC4_routing_api_unavailable_returns_none(self):
        """EC4: OneMap returns None (service down) -> None propagated."""
        with patch("backend.control.commute_controller.PrimarySchool") as MockPS, \
             patch("backend.control.commute_controller.HDBBlock") as MockHDB, \
             patch("backend.control.commute_controller.ExternalOneMapAPI") as MockAPI:
            MockPS.query.get.return_value = MagicMock()
            MockHDB.query.get.return_value = MagicMock()
            MockAPI.request_commute_time.return_value = None
            from backend.control.commute_controller import CommuteController
            result = CommuteController.get_commute_time(school_id=1, block_id=5)
        assert result is None


class TestFindBestAlternativeBlocks:
    """
    Equivalence Classes:
      EC1: silver-zone blocks exist and API responds -> sorted list returned
      EC2: no silver-zone blocks                     -> []
      EC3: school not found                          -> []
    """

    def test_EC3_school_not_found_returns_empty(self):
        """EC3: Invalid school_id -> []."""
        with patch("backend.control.commute_controller.PrimarySchool") as MockPS:
            MockPS.query.get.return_value = None
            from backend.control.commute_controller import CommuteController
            result = CommuteController.find_best_alternative_blocks(school_id=999)
        assert result == []

    def test_EC2_no_silver_blocks_returns_empty(self):
        """EC2: School found but no blocks in silver zone -> []."""
        with patch("backend.control.commute_controller.PrimarySchool") as MockPS, \
             patch("backend.control.commute_controller.HDBBlock") as MockHDB, \
             patch("backend.control.commute_controller.func"):
            MockPS.query.get.return_value = MagicMock()
            MockHDB.query.filter.return_value.all.return_value = []
            from backend.control.commute_controller import CommuteController
            result = CommuteController.find_best_alternative_blocks(school_id=1)
        assert result == []

    def test_EC1_blocks_sorted_by_shortest_commute(self):
        """EC1: Multiple silver blocks -> returned sorted by travel_time_min asc."""
        mock_school = MagicMock()
        b1 = MagicMock(); b1.block_id=1; b1.street_name="A ST"; b1.block_num="10"
        b2 = MagicMock(); b2.block_id=2; b2.street_name="B ST"; b2.block_num="20"

        # b1 takes 25 min, b2 takes 12 min -> b2 should come first
        commute_times = {(b1.latitude, b1.longitude): 25,
                         (b2.latitude, b2.longitude): 12}

        with patch("backend.control.commute_controller.PrimarySchool") as MockPS, \
             patch("backend.control.commute_controller.HDBBlock") as MockHDB, \
             patch("backend.control.commute_controller.ExternalOneMapAPI") as MockAPI, \
             patch("backend.control.commute_controller.db") as mock_db, \
             patch("backend.control.commute_controller.func"):
            MockPS.query.get.return_value = mock_school
            MockHDB.query.filter.return_value.all.return_value = [b1, b2]
            MockAPI.request_commute_time.side_effect = lambda start_lat, start_lng, **kw: \
                25 if start_lat == b1.latitude else 12
            mock_db.session.query.return_value.scalar.return_value = 1500

            from backend.control.commute_controller import CommuteController
            result = CommuteController.find_best_alternative_blocks(school_id=1, top_n=2)

        assert result[0]["travel_time_min"] <= result[1]["travel_time_min"]