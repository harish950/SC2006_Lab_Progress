#!/usr/bin/env bash
# =============================================================================
# EduHome — Full-Stack Startup Script
# Starts PostgreSQL (if needed), initialises the database, and launches
# both the Flask backend and React frontend.
#
# Usage:
#   ./start.sh            — start everything (db + backend + frontend)
#   ./start.sh --backend  — start backend only
#   ./start.sh --frontend — start frontend only
#   ./start.sh --db-only  — initialise/seed database, then exit
#   ./start.sh --stop     — stop background services started by this script
# =============================================================================

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="${ROOT_DIR}/backend"
FRONTEND_DIR="${ROOT_DIR}/frontend"
DATABASE_DIR="${ROOT_DIR}/database"
VENV_DIR="${BACKEND_DIR}/venv"
PID_DIR="${ROOT_DIR}/.pids"

# Database config (override via environment)
DB_NAME="${EDUHOME_DB:-eduhome}"
DB_USER="${EDUHOME_DB_USER:-${USER}}"
DB_HOST="${EDUHOME_DB_HOST:-localhost}"
DB_PORT="${EDUHOME_DB_PORT:-5432}"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Colour

log()  { echo -e "${GREEN}[EduHome]${NC} $*"; }
warn() { echo -e "${YELLOW}[EduHome]${NC} $*"; }
err()  { echo -e "${RED}[EduHome]${NC} $*" >&2; }

# ─── Prerequisite checks ─────────────────────────────────────────────────────

check_prereqs() {
    local missing=()

    command -v node   >/dev/null 2>&1 || missing+=("node (Node.js 18+)")
    command -v npm    >/dev/null 2>&1 || missing+=("npm")
    command -v python3 >/dev/null 2>&1 || missing+=("python3 (3.10+)")
    command -v psql   >/dev/null 2>&1 || missing+=("psql (PostgreSQL 14+ with PostGIS)")

    if [ ${#missing[@]} -gt 0 ]; then
        err "Missing prerequisites:"
        for m in "${missing[@]}"; do
            err "  • $m"
        done
        exit 1
    fi
}

# ─── PostgreSQL ───────────────────────────────────────────────────────────────

ensure_postgres() {
    if pg_isready -h "$DB_HOST" -p "$DB_PORT" >/dev/null 2>&1; then
        log "PostgreSQL is running on ${DB_HOST}:${DB_PORT}"
        return 0
    fi

    warn "PostgreSQL is not running."

    # macOS: try Homebrew services
    if command -v brew >/dev/null 2>&1 && brew services list 2>/dev/null | grep -q postgresql; then
        log "Starting PostgreSQL via Homebrew..."
        brew services start postgresql@14 2>/dev/null || brew services start postgresql 2>/dev/null || true
        sleep 2
        if pg_isready -h "$DB_HOST" -p "$DB_PORT" >/dev/null 2>&1; then
            log "PostgreSQL started successfully."
            return 0
        fi
    fi

    err "Could not start PostgreSQL automatically."
    err "Please start it manually and re-run this script."
    exit 1
}

# ─── Database init & seed ─────────────────────────────────────────────────────

setup_database() {
    log "Setting up database '${DB_NAME}'..."

    # Create database if it doesn't exist
    if psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -lqt 2>/dev/null | cut -d \| -f 1 | grep -qw "$DB_NAME"; then
        log "Database '${DB_NAME}' already exists."
    else
        log "Creating database '${DB_NAME}'..."
        createdb -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" "$DB_NAME" 2>/dev/null || true
        log "Database created."
    fi

    # Enable PostGIS
    psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
        -c "CREATE EXTENSION IF NOT EXISTS postgis;" >/dev/null 2>&1
    log "PostGIS extension enabled."

    # Apply schema
    log "Applying schema..."
    psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
        -f "${DATABASE_DIR}/schema.sql" >/dev/null 2>&1
    log "Schema applied."

    # Seed data (only if schools table is empty)
    local count
    count=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
        -tAc "SELECT COUNT(*) FROM primary_schools;" 2>/dev/null || echo "0")

    if [ "$count" -eq 0 ]; then
        log "Seeding initial data..."
        psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
            -f "${DATABASE_DIR}/seed_data.sql" >/dev/null 2>&1
        log "Seed data loaded."
    else
        log "Database already has data (${count} schools) — skipping seed_data.sql."
    fi

    # Seed additional schools (idempotent — skips existing via WHERE NOT EXISTS)
    log "Seeding new schools..."
    psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
        -f "${DATABASE_DIR}/seed_new_schools.sql" >/dev/null 2>&1
    log "New schools seeded."

    # Seed market data (HDB blocks + transactions) if hdb_blocks is empty
    local block_count
    block_count=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
        -tAc "SELECT COUNT(*) FROM hdb_blocks;" 2>/dev/null || echo "0")

    if [ "$block_count" -eq 0 ]; then
        log "Seeding market data (HDB blocks & transactions)..."
        psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
            -f "${DATABASE_DIR}/seed_market_data.sql" >/dev/null 2>&1
        log "Market data loaded."
    else
        log "HDB blocks already populated (${block_count} blocks) — skipping seed_market_data.sql."
    fi
}

# ─── Python virtual environment & dependencies ────────────────────────────────

find_python() {
    # Prefer Homebrew Python over macOS system Python (3.9/Xcode)
    for candidate in \
        /opt/homebrew/opt/python@3.13/bin/python3 \
        /opt/homebrew/opt/python@3.14/bin/python3 \
        /opt/homebrew/opt/python@3.12/bin/python3 \
        /opt/homebrew/opt/python@3.11/bin/python3 \
        /opt/homebrew/opt/python@3.10/bin/python3 \
        /opt/homebrew/bin/python3; do
        if [ -x "$candidate" ]; then
            echo "$candidate"
            return
        fi
    done
    # Fallback to whatever is on PATH
    command -v python3
}

setup_backend() {
    log "Setting up Python backend..."

    local PYTHON
    PYTHON="$(find_python)"
    log "Using Python: ${PYTHON} ($($PYTHON --version 2>&1))"

    # Recreate venv if it was built with a different Python
    if [ -d "$VENV_DIR" ]; then
        local venv_python
        venv_python="$("${VENV_DIR}/bin/python3" --version 2>&1 || echo "unknown")"
        local target_python
        target_python="$($PYTHON --version 2>&1)"
        if [ "$venv_python" != "$target_python" ]; then
            warn "Venv has ${venv_python}, but system has ${target_python}. Recreating..."
            rm -rf "$VENV_DIR"
        fi
    fi

    if [ ! -d "$VENV_DIR" ]; then
        log "Creating virtual environment..."
        "$PYTHON" -m venv "$VENV_DIR"
    fi

    source "${VENV_DIR}/bin/activate"

    log "Installing Python dependencies..."
    pip install -q --upgrade pip
    pip install -q -r "${BACKEND_DIR}/requirements.pip"

    log "Backend dependencies ready."
}

# ─── Frontend dependencies ────────────────────────────────────────────────────

setup_frontend() {
    log "Setting up React frontend..."

    if [ ! -d "${FRONTEND_DIR}/node_modules" ]; then
        log "Installing npm dependencies..."
        (cd "$FRONTEND_DIR" && npm install --silent)
    else
        log "node_modules exists — skipping npm install."
    fi

    log "Frontend dependencies ready."
}

# ─── Start services ──────────────────────────────────────────────────────────

mkdir -p "$PID_DIR"

start_backend() {
    setup_backend
    source "${VENV_DIR}/bin/activate"

    log "Starting Flask backend on http://localhost:5001 ..."

    cd "$ROOT_DIR"
    FLASK_APP=backend.app:create_app \
    FLASK_ENV=development \
    python3 -m flask run --port 5001 &
    local pid=$!
    echo "$pid" > "${PID_DIR}/backend.pid"

    log "Backend started (PID: ${pid})"
}

start_frontend() {
    setup_frontend

    log "Starting React dev server on http://localhost:3000 ..."

    (cd "$FRONTEND_DIR" && BROWSER=none npm start) &
    local pid=$!
    echo "$pid" > "${PID_DIR}/frontend.pid"

    log "Frontend started (PID: ${pid})"
}

# ─── Stop services ───────────────────────────────────────────────────────────

stop_services() {
    log "Stopping EduHome services..."
    local stopped=0

    for svc in backend frontend; do
        local pidfile="${PID_DIR}/${svc}.pid"
        if [ -f "$pidfile" ]; then
            local pid
            pid=$(cat "$pidfile")
            if kill -0 "$pid" 2>/dev/null; then
                kill "$pid" 2>/dev/null
                log "Stopped ${svc} (PID: ${pid})"
                stopped=$((stopped + 1))
            else
                warn "${svc} (PID: ${pid}) was not running."
            fi
            rm -f "$pidfile"
        fi
    done

    if [ "$stopped" -eq 0 ]; then
        warn "No running services found."
    else
        log "All services stopped."
    fi
}

# ─── Main ─────────────────────────────────────────────────────────────────────

print_banner() {
    echo -e "${CYAN}"
    echo "  ╔═══════════════════════════════════════════════╗"
    echo "  ║   EduHome: P1 Registration Strategist         ║"
    echo "  ╚═══════════════════════════════════════════════╝"
    echo -e "${NC}"
}

print_status() {
    echo ""
    log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    log "  Frontend : http://localhost:3000"
    log "  Backend  : http://localhost:5001"
    log "  Database : postgresql://${DB_HOST}:${DB_PORT}/${DB_NAME}"
    log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    log ""
    log "Press Ctrl+C to stop all services."
    echo ""
}

cleanup() {
    echo ""
    log "Shutting down..."
    stop_services
    exit 0
}

main() {
    print_banner
    check_prereqs

    case "${1:-}" in
        --stop)
            stop_services
            exit 0
            ;;
        --db-only)
            ensure_postgres
            setup_database
            log "Database is ready. Exiting."
            exit 0
            ;;
        --backend)
            ensure_postgres
            setup_database
            start_backend
            trap cleanup SIGINT SIGTERM
            wait
            ;;
        --frontend)
            start_frontend
            trap cleanup SIGINT SIGTERM
            wait
            ;;
        "")
            # Full startup
            ensure_postgres
            setup_database
            start_backend
            start_frontend
            print_status
            trap cleanup SIGINT SIGTERM
            wait
            ;;
        *)
            echo "Usage: $0 [--backend | --frontend | --db-only | --stop]"
            exit 1
            ;;
    esac
}

main "$@"
