-- =============================================================================
-- EduHome: Insert 10 additional primary schools + priority zones
--
-- Run AFTER seed_data.sql. Safe to re-run — skips schools that already exist.
-- =============================================================================

INSERT INTO primary_schools (official_name, postal_code, location, vacancies)
SELECT v.official_name, v.postal_code::integer, v.location, v.vacancies
FROM (VALUES
    ('Anglo-Chinese School (Primary)',        NULL, ST_SetSRID(ST_MakePoint(103.8230, 1.3050), 4326)::geography, 28),
    ('Methodist Girls'' School (Primary)',     NULL, ST_SetSRID(ST_MakePoint(103.8270, 1.3070), 4326)::geography, 33),
    ('St. Hilda''s Primary School',            NULL, ST_SetSRID(ST_MakePoint(103.9300, 1.3380), 4326)::geography, 52),
    ('Kong Hwa School',                        NULL, ST_SetSRID(ST_MakePoint(103.8920, 1.3090), 4326)::geography, 47),
    ('Chongfu School',                         NULL, ST_SetSRID(ST_MakePoint(103.8760, 1.3690), 4326)::geography, 58),
    ('Rulang Primary School',                  NULL, ST_SetSRID(ST_MakePoint(103.7330, 1.3460), 4326)::geography, 44),
    ('Nan Hua Primary School',                 NULL, ST_SetSRID(ST_MakePoint(103.8010, 1.3180), 4326)::geography, 36),
    ('Maris Stella High School (Primary)',     NULL, ST_SetSRID(ST_MakePoint(103.8660, 1.3510), 4326)::geography, 41),
    ('River Valley Primary School',            NULL, ST_SetSRID(ST_MakePoint(103.8260, 1.2930), 4326)::geography, 39),
    ('Beacon Primary School',                  NULL, ST_SetSRID(ST_MakePoint(103.7470, 1.3950), 4326)::geography, 65)
) AS v(official_name, postal_code, location, vacancies)
WHERE NOT EXISTS (
    SELECT 1 FROM primary_schools ps
    WHERE UPPER(ps.official_name) = UPPER(v.official_name)
);

-- Priority zones for newly inserted schools (only for schools without zones)
INSERT INTO priority_zones (school_id, radius_tier, boundary)
SELECT ps.school_id, 'GOLD_1KM', ST_Buffer(ps.location, 1000)::geography
FROM primary_schools ps
WHERE NOT EXISTS (
    SELECT 1 FROM priority_zones pz
    WHERE pz.school_id = ps.school_id AND pz.radius_tier = 'GOLD_1KM'
);

INSERT INTO priority_zones (school_id, radius_tier, boundary)
SELECT ps.school_id, 'SILVER_2KM', ST_Buffer(ps.location, 2000)::geography
FROM primary_schools ps
WHERE NOT EXISTS (
    SELECT 1 FROM priority_zones pz
    WHERE pz.school_id = ps.school_id AND pz.radius_tier = 'SILVER_2KM'
);
